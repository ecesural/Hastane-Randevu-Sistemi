﻿namespace Randevu_Sistemi
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form5));
            this.btnRandevularım = new System.Windows.Forms.Button();
            this.btnCikis = new System.Windows.Forms.Button();
            this.lblHosgeldinizAciklama = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.picBoxGeri = new System.Windows.Forms.PictureBox();
            this.lblTarihveSonrasiniAciklama2 = new System.Windows.Forms.Label();
            this.lblNormalAciklama1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblBransAdi2 = new System.Windows.Forms.Label();
            this.picBoxSaatDokuz = new System.Windows.Forms.PictureBox();
            this.lblTarih1 = new System.Windows.Forms.Label();
            this.lblBransAdi1 = new System.Windows.Forms.Label();
            this.lblBransAdiAciklama = new System.Windows.Forms.Label();
            this.llblTarihAciklama = new System.Windows.Forms.Label();
            this.lblTarihveSonrasiniAciklama3 = new System.Windows.Forms.Label();
            this.lblTarihveSonrasiniAciklama1 = new System.Windows.Forms.Label();
            this.lblTarih2 = new System.Windows.Forms.Label();
            this.picBoxTarihAciklama = new System.Windows.Forms.PictureBox();
            this.picBoxBransListesi = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.monthCalendar_randevuTarihleri = new System.Windows.Forms.MonthCalendar();
            this.picBoxSaatDokuzBucuk = new System.Windows.Forms.PictureBox();
            this.picBoxSaatOn = new System.Windows.Forms.PictureBox();
            this.picBoxSaatOnBucuk = new System.Windows.Forms.PictureBox();
            this.picBoxSaatOnBir = new System.Windows.Forms.PictureBox();
            this.picBoxSaatOnUcOtuz = new System.Windows.Forms.PictureBox();
            this.picBoxSaatOnUc = new System.Windows.Forms.PictureBox();
            this.picBoxSaatOnİkiOtuz = new System.Windows.Forms.PictureBox();
            this.picBoxSaatOnİki = new System.Windows.Forms.PictureBox();
            this.picBoxSaatOnBirBucuk = new System.Windows.Forms.PictureBox();
            this.picBoxSaatOnAltı = new System.Windows.Forms.PictureBox();
            this.picBoxSaatOnBesOtuz = new System.Windows.Forms.PictureBox();
            this.picBoxSaatOnBes = new System.Windows.Forms.PictureBox();
            this.picBoxSaatOnDörtOtuz = new System.Windows.Forms.PictureBox();
            this.picBoxSaatOnDört = new System.Windows.Forms.PictureBox();
            this.lblSaatDokuz = new System.Windows.Forms.Label();
            this.lblSaatDokuzBucuk = new System.Windows.Forms.Label();
            this.lblSaatOn = new System.Windows.Forms.Label();
            this.lblSaatOnBucuk = new System.Windows.Forms.Label();
            this.lblSaatOnBir = new System.Windows.Forms.Label();
            this.lblSaatOnBirBucuk = new System.Windows.Forms.Label();
            this.lblSaatOnİki = new System.Windows.Forms.Label();
            this.lblSaatOnİkiBucuk = new System.Windows.Forms.Label();
            this.lblSaatOnUc = new System.Windows.Forms.Label();
            this.lblSaatOnUcOtuz = new System.Windows.Forms.Label();
            this.lblSaatOnDört = new System.Windows.Forms.Label();
            this.lblSaatOnDörtOtuz = new System.Windows.Forms.Label();
            this.lblSaatOnBes = new System.Windows.Forms.Label();
            this.lblSaatOnBesOtuz = new System.Windows.Forms.Label();
            this.lblSaatOnAltı = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxGeri)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSaatDokuz)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxTarihAciklama)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxBransListesi)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSaatDokuzBucuk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSaatOn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSaatOnBucuk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSaatOnBir)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSaatOnUcOtuz)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSaatOnUc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSaatOnİkiOtuz)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSaatOnİki)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSaatOnBirBucuk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSaatOnAltı)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSaatOnBesOtuz)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSaatOnBes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSaatOnDörtOtuz)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSaatOnDört)).BeginInit();
            this.SuspendLayout();
            // 
            // btnRandevularım
            // 
            this.btnRandevularım.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnRandevularım.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnRandevularım.BackColor = System.Drawing.Color.Orange;
            this.btnRandevularım.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRandevularım.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnRandevularım.ForeColor = System.Drawing.Color.White;
            this.btnRandevularım.Location = new System.Drawing.Point(842, 38);
            this.btnRandevularım.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnRandevularım.Name = "btnRandevularım";
            this.btnRandevularım.Size = new System.Drawing.Size(101, 31);
            this.btnRandevularım.TabIndex = 56;
            this.btnRandevularım.Text = "Randevularım";
            this.btnRandevularım.UseVisualStyleBackColor = false;
            this.btnRandevularım.Click += new System.EventHandler(this.btnRandevularım_Click);
            this.btnRandevularım.MouseLeave += new System.EventHandler(this.btnRandevularım_MouseLeave);
            this.btnRandevularım.MouseMove += new System.Windows.Forms.MouseEventHandler(this.btnRandevularım_MouseMove);
            // 
            // btnCikis
            // 
            this.btnCikis.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnCikis.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnCikis.BackColor = System.Drawing.Color.Orange;
            this.btnCikis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCikis.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnCikis.ForeColor = System.Drawing.Color.White;
            this.btnCikis.Location = new System.Drawing.Point(947, 38);
            this.btnCikis.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnCikis.Name = "btnCikis";
            this.btnCikis.Size = new System.Drawing.Size(66, 31);
            this.btnCikis.TabIndex = 55;
            this.btnCikis.Text = "Çıkış";
            this.btnCikis.UseVisualStyleBackColor = false;
            this.btnCikis.Click += new System.EventHandler(this.btnCikis_Click);
            this.btnCikis.MouseLeave += new System.EventHandler(this.btnCikis_MouseLeave);
            this.btnCikis.MouseMove += new System.Windows.Forms.MouseEventHandler(this.btnCikis_MouseMove);
            // 
            // lblHosgeldinizAciklama
            // 
            this.lblHosgeldinizAciklama.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblHosgeldinizAciklama.AutoSize = true;
            this.lblHosgeldinizAciklama.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblHosgeldinizAciklama.ForeColor = System.Drawing.Color.Black;
            this.lblHosgeldinizAciklama.Location = new System.Drawing.Point(632, 12);
            this.lblHosgeldinizAciklama.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblHosgeldinizAciklama.Name = "lblHosgeldinizAciklama";
            this.lblHosgeldinizAciklama.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblHosgeldinizAciklama.Size = new System.Drawing.Size(135, 15);
            this.lblHosgeldinizAciklama.TabIndex = 54;
            this.lblHosgeldinizAciklama.Text = "lblHosgeldinizAciklama";
            this.lblHosgeldinizAciklama.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(2, 77);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1011, 110);
            this.panel1.TabIndex = 53;
            // 
            // picBoxGeri
            // 
            this.picBoxGeri.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxGeri.BackgroundImage")));
            this.picBoxGeri.Location = new System.Drawing.Point(317, 242);
            this.picBoxGeri.Name = "picBoxGeri";
            this.picBoxGeri.Size = new System.Drawing.Size(87, 33);
            this.picBoxGeri.TabIndex = 139;
            this.picBoxGeri.TabStop = false;
            this.picBoxGeri.Click += new System.EventHandler(this.picBoxGeri_Click);
            // 
            // lblTarihveSonrasiniAciklama2
            // 
            this.lblTarihveSonrasiniAciklama2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTarihveSonrasiniAciklama2.AutoSize = true;
            this.lblTarihveSonrasiniAciklama2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTarihveSonrasiniAciklama2.ForeColor = System.Drawing.Color.Black;
            this.lblTarihveSonrasiniAciklama2.Location = new System.Drawing.Point(780, 354);
            this.lblTarihveSonrasiniAciklama2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTarihveSonrasiniAciklama2.Name = "lblTarihveSonrasiniAciklama2";
            this.lblTarihveSonrasiniAciklama2.Size = new System.Drawing.Size(219, 15);
            this.lblTarihveSonrasiniAciklama2.TabIndex = 138;
            this.lblTarihveSonrasiniAciklama2.Text = "randevu saatleri aşağıda listelenmiştir.";
            // 
            // lblNormalAciklama1
            // 
            this.lblNormalAciklama1.AutoSize = true;
            this.lblNormalAciklama1.BackColor = System.Drawing.Color.White;
            this.lblNormalAciklama1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblNormalAciklama1.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblNormalAciklama1.Location = new System.Drawing.Point(724, 354);
            this.lblNormalAciklama1.Name = "lblNormalAciklama1";
            this.lblNormalAciklama1.Size = new System.Drawing.Size(58, 15);
            this.lblNormalAciklama1.TabIndex = 137;
            this.lblNormalAciklama1.Text = "Poliklinik";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(655, 354);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 15);
            this.label1.TabIndex = 136;
            this.label1.Text = "branşındaki";
            // 
            // lblBransAdi2
            // 
            this.lblBransAdi2.AutoSize = true;
            this.lblBransAdi2.BackColor = System.Drawing.Color.White;
            this.lblBransAdi2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBransAdi2.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblBransAdi2.Location = new System.Drawing.Point(518, 354);
            this.lblBransAdi2.Name = "lblBransAdi2";
            this.lblBransAdi2.Size = new System.Drawing.Size(62, 15);
            this.lblBransAdi2.TabIndex = 135;
            this.lblBransAdi2.Text = "Branş Adı";
            // 
            // picBoxSaatDokuz
            // 
            this.picBoxSaatDokuz.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxSaatDokuz.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxSaatDokuz.BackgroundImage")));
            this.picBoxSaatDokuz.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxSaatDokuz.Location = new System.Drawing.Point(336, 406);
            this.picBoxSaatDokuz.Name = "picBoxSaatDokuz";
            this.picBoxSaatDokuz.Size = new System.Drawing.Size(129, 70);
            this.picBoxSaatDokuz.TabIndex = 131;
            this.picBoxSaatDokuz.TabStop = false;
            this.picBoxSaatDokuz.Click += new System.EventHandler(this.picBoxSaatDokuz_Click);
            // 
            // lblTarih1
            // 
            this.lblTarih1.AutoSize = true;
            this.lblTarih1.BackColor = System.Drawing.SystemColors.Control;
            this.lblTarih1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTarih1.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblTarih1.Image = ((System.Drawing.Image)(resources.GetObject("lblTarih1.Image")));
            this.lblTarih1.Location = new System.Drawing.Point(415, 287);
            this.lblTarih1.Name = "lblTarih1";
            this.lblTarih1.Size = new System.Drawing.Size(114, 15);
            this.lblTarih1.TabIndex = 130;
            this.lblTarih1.Text = "ToLongDateString()";
            // 
            // lblBransAdi1
            // 
            this.lblBransAdi1.AutoSize = true;
            this.lblBransAdi1.BackColor = System.Drawing.SystemColors.Control;
            this.lblBransAdi1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBransAdi1.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblBransAdi1.Image = ((System.Drawing.Image)(resources.GetObject("lblBransAdi1.Image")));
            this.lblBransAdi1.Location = new System.Drawing.Point(415, 310);
            this.lblBransAdi1.Name = "lblBransAdi1";
            this.lblBransAdi1.Size = new System.Drawing.Size(59, 15);
            this.lblBransAdi1.TabIndex = 129;
            this.lblBransAdi1.Text = "Branş Adı";
            // 
            // lblBransAdiAciklama
            // 
            this.lblBransAdiAciklama.AutoSize = true;
            this.lblBransAdiAciklama.BackColor = System.Drawing.SystemColors.Control;
            this.lblBransAdiAciklama.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBransAdiAciklama.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblBransAdiAciklama.Image = ((System.Drawing.Image)(resources.GetObject("lblBransAdiAciklama.Image")));
            this.lblBransAdiAciklama.Location = new System.Drawing.Point(323, 310);
            this.lblBransAdiAciklama.Name = "lblBransAdiAciklama";
            this.lblBransAdiAciklama.Size = new System.Drawing.Size(95, 15);
            this.lblBransAdiAciklama.TabIndex = 128;
            this.lblBransAdiAciklama.Text = "Branş Adı          :";
            // 
            // llblTarihAciklama
            // 
            this.llblTarihAciklama.AutoSize = true;
            this.llblTarihAciklama.BackColor = System.Drawing.SystemColors.Control;
            this.llblTarihAciklama.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.llblTarihAciklama.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.llblTarihAciklama.Image = ((System.Drawing.Image)(resources.GetObject("llblTarihAciklama.Image")));
            this.llblTarihAciklama.Location = new System.Drawing.Point(323, 287);
            this.llblTarihAciklama.Name = "llblTarihAciklama";
            this.llblTarihAciklama.Size = new System.Drawing.Size(95, 15);
            this.llblTarihAciklama.TabIndex = 127;
            this.llblTarihAciklama.Text = "Tarih                   :";
            // 
            // lblTarihveSonrasiniAciklama3
            // 
            this.lblTarihveSonrasiniAciklama3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTarihveSonrasiniAciklama3.AutoSize = true;
            this.lblTarihveSonrasiniAciklama3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTarihveSonrasiniAciklama3.ForeColor = System.Drawing.Color.Black;
            this.lblTarihveSonrasiniAciklama3.Location = new System.Drawing.Point(318, 369);
            this.lblTarihveSonrasiniAciklama3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTarihveSonrasiniAciklama3.Name = "lblTarihveSonrasiniAciklama3";
            this.lblTarihveSonrasiniAciklama3.Size = new System.Drawing.Size(369, 15);
            this.lblTarihveSonrasiniAciklama3.TabIndex = 126;
            this.lblTarihveSonrasiniAciklama3.Text = "Lütfen istediğiniz saatin yanındaki \"Randevu Al\" butonuna tıklayınız.";
            // 
            // lblTarihveSonrasiniAciklama1
            // 
            this.lblTarihveSonrasiniAciklama1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTarihveSonrasiniAciklama1.AutoSize = true;
            this.lblTarihveSonrasiniAciklama1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTarihveSonrasiniAciklama1.ForeColor = System.Drawing.Color.Black;
            this.lblTarihveSonrasiniAciklama1.Location = new System.Drawing.Point(468, 354);
            this.lblTarihveSonrasiniAciklama1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTarihveSonrasiniAciklama1.Name = "lblTarihveSonrasiniAciklama1";
            this.lblTarihveSonrasiniAciklama1.Size = new System.Drawing.Size(55, 15);
            this.lblTarihveSonrasiniAciklama1.TabIndex = 125;
            this.lblTarihveSonrasiniAciklama1.Text = "tarihinde";
            // 
            // lblTarih2
            // 
            this.lblTarih2.AutoSize = true;
            this.lblTarih2.BackColor = System.Drawing.Color.White;
            this.lblTarih2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTarih2.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblTarih2.Location = new System.Drawing.Point(318, 354);
            this.lblTarih2.Name = "lblTarih2";
            this.lblTarih2.Size = new System.Drawing.Size(116, 15);
            this.lblTarih2.TabIndex = 124;
            this.lblTarih2.Text = "ToLongDateString()";
            // 
            // picBoxTarihAciklama
            // 
            this.picBoxTarihAciklama.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxTarihAciklama.BackgroundImage")));
            this.picBoxTarihAciklama.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picBoxTarihAciklama.Location = new System.Drawing.Point(317, 279);
            this.picBoxTarihAciklama.Name = "picBoxTarihAciklama";
            this.picBoxTarihAciklama.Size = new System.Drawing.Size(690, 57);
            this.picBoxTarihAciklama.TabIndex = 123;
            this.picBoxTarihAciklama.TabStop = false;
            // 
            // picBoxBransListesi
            // 
            this.picBoxBransListesi.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picBoxBransListesi.Image = ((System.Drawing.Image)(resources.GetObject("picBoxBransListesi.Image")));
            this.picBoxBransListesi.Location = new System.Drawing.Point(317, 201);
            this.picBoxBransListesi.Name = "picBoxBransListesi";
            this.picBoxBransListesi.Size = new System.Drawing.Size(690, 35);
            this.picBoxBransListesi.TabIndex = 122;
            this.picBoxBransListesi.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.monthCalendar_randevuTarihleri);
            this.panel2.Location = new System.Drawing.Point(6, 201);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(290, 234);
            this.panel2.TabIndex = 121;
            // 
            // monthCalendar_randevuTarihleri
            // 
            this.monthCalendar_randevuTarihleri.BackColor = System.Drawing.Color.Gold;
            this.monthCalendar_randevuTarihleri.Enabled = false;
            this.monthCalendar_randevuTarihleri.FirstDayOfWeek = System.Windows.Forms.Day.Monday;
            this.monthCalendar_randevuTarihleri.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.monthCalendar_randevuTarihleri.ForeColor = System.Drawing.Color.White;
            this.monthCalendar_randevuTarihleri.Location = new System.Drawing.Point(9, 9);
            this.monthCalendar_randevuTarihleri.MaxSelectionCount = 1;
            this.monthCalendar_randevuTarihleri.Name = "monthCalendar_randevuTarihleri";
            this.monthCalendar_randevuTarihleri.TabIndex = 21;
            this.monthCalendar_randevuTarihleri.TitleBackColor = System.Drawing.Color.Red;
            this.monthCalendar_randevuTarihleri.TitleForeColor = System.Drawing.Color.White;
            this.monthCalendar_randevuTarihleri.TrailingForeColor = System.Drawing.SystemColors.WindowFrame;
            // 
            // picBoxSaatDokuzBucuk
            // 
            this.picBoxSaatDokuzBucuk.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxSaatDokuzBucuk.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxSaatDokuzBucuk.BackgroundImage")));
            this.picBoxSaatDokuzBucuk.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxSaatDokuzBucuk.Location = new System.Drawing.Point(471, 406);
            this.picBoxSaatDokuzBucuk.Name = "picBoxSaatDokuzBucuk";
            this.picBoxSaatDokuzBucuk.Size = new System.Drawing.Size(129, 70);
            this.picBoxSaatDokuzBucuk.TabIndex = 140;
            this.picBoxSaatDokuzBucuk.TabStop = false;
            this.picBoxSaatDokuzBucuk.Click += new System.EventHandler(this.picBoxSaatDokuzBucuk_Click);
            // 
            // picBoxSaatOn
            // 
            this.picBoxSaatOn.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxSaatOn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxSaatOn.BackgroundImage")));
            this.picBoxSaatOn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxSaatOn.Location = new System.Drawing.Point(608, 406);
            this.picBoxSaatOn.Name = "picBoxSaatOn";
            this.picBoxSaatOn.Size = new System.Drawing.Size(129, 70);
            this.picBoxSaatOn.TabIndex = 141;
            this.picBoxSaatOn.TabStop = false;
            this.picBoxSaatOn.Click += new System.EventHandler(this.picBoxSaatOn_Click);
            // 
            // picBoxSaatOnBucuk
            // 
            this.picBoxSaatOnBucuk.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxSaatOnBucuk.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxSaatOnBucuk.BackgroundImage")));
            this.picBoxSaatOnBucuk.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxSaatOnBucuk.Location = new System.Drawing.Point(743, 406);
            this.picBoxSaatOnBucuk.Name = "picBoxSaatOnBucuk";
            this.picBoxSaatOnBucuk.Size = new System.Drawing.Size(129, 70);
            this.picBoxSaatOnBucuk.TabIndex = 142;
            this.picBoxSaatOnBucuk.TabStop = false;
            this.picBoxSaatOnBucuk.Click += new System.EventHandler(this.picBoxSaatOnBucuk_Click);
            // 
            // picBoxSaatOnBir
            // 
            this.picBoxSaatOnBir.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxSaatOnBir.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxSaatOnBir.BackgroundImage")));
            this.picBoxSaatOnBir.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxSaatOnBir.Location = new System.Drawing.Point(878, 406);
            this.picBoxSaatOnBir.Name = "picBoxSaatOnBir";
            this.picBoxSaatOnBir.Size = new System.Drawing.Size(129, 70);
            this.picBoxSaatOnBir.TabIndex = 143;
            this.picBoxSaatOnBir.TabStop = false;
            this.picBoxSaatOnBir.Click += new System.EventHandler(this.picBoxSaatSaatOnBir_Click);
            // 
            // picBoxSaatOnUcOtuz
            // 
            this.picBoxSaatOnUcOtuz.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxSaatOnUcOtuz.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxSaatOnUcOtuz.BackgroundImage")));
            this.picBoxSaatOnUcOtuz.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxSaatOnUcOtuz.Location = new System.Drawing.Point(878, 482);
            this.picBoxSaatOnUcOtuz.Name = "picBoxSaatOnUcOtuz";
            this.picBoxSaatOnUcOtuz.Size = new System.Drawing.Size(129, 70);
            this.picBoxSaatOnUcOtuz.TabIndex = 148;
            this.picBoxSaatOnUcOtuz.TabStop = false;
            this.picBoxSaatOnUcOtuz.Click += new System.EventHandler(this.picBoxSaatOnUcOtuz_Click);
            // 
            // picBoxSaatOnUc
            // 
            this.picBoxSaatOnUc.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxSaatOnUc.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxSaatOnUc.BackgroundImage")));
            this.picBoxSaatOnUc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxSaatOnUc.Location = new System.Drawing.Point(743, 482);
            this.picBoxSaatOnUc.Name = "picBoxSaatOnUc";
            this.picBoxSaatOnUc.Size = new System.Drawing.Size(129, 70);
            this.picBoxSaatOnUc.TabIndex = 147;
            this.picBoxSaatOnUc.TabStop = false;
            this.picBoxSaatOnUc.Click += new System.EventHandler(this.picBoxSaatOnUc_Click);
            // 
            // picBoxSaatOnİkiOtuz
            // 
            this.picBoxSaatOnİkiOtuz.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxSaatOnİkiOtuz.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxSaatOnİkiOtuz.BackgroundImage")));
            this.picBoxSaatOnİkiOtuz.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxSaatOnİkiOtuz.Location = new System.Drawing.Point(608, 482);
            this.picBoxSaatOnİkiOtuz.Name = "picBoxSaatOnİkiOtuz";
            this.picBoxSaatOnİkiOtuz.Size = new System.Drawing.Size(129, 70);
            this.picBoxSaatOnİkiOtuz.TabIndex = 146;
            this.picBoxSaatOnİkiOtuz.TabStop = false;
            this.picBoxSaatOnİkiOtuz.Click += new System.EventHandler(this.picBoxSaatOnİkiOtuz_Click);
            // 
            // picBoxSaatOnİki
            // 
            this.picBoxSaatOnİki.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxSaatOnİki.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxSaatOnİki.BackgroundImage")));
            this.picBoxSaatOnİki.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxSaatOnİki.Location = new System.Drawing.Point(471, 482);
            this.picBoxSaatOnİki.Name = "picBoxSaatOnİki";
            this.picBoxSaatOnİki.Size = new System.Drawing.Size(129, 70);
            this.picBoxSaatOnİki.TabIndex = 145;
            this.picBoxSaatOnİki.TabStop = false;
            this.picBoxSaatOnİki.Click += new System.EventHandler(this.picBoxSaatOnİki_Click);
            // 
            // picBoxSaatOnBirBucuk
            // 
            this.picBoxSaatOnBirBucuk.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxSaatOnBirBucuk.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxSaatOnBirBucuk.BackgroundImage")));
            this.picBoxSaatOnBirBucuk.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxSaatOnBirBucuk.Location = new System.Drawing.Point(336, 482);
            this.picBoxSaatOnBirBucuk.Name = "picBoxSaatOnBirBucuk";
            this.picBoxSaatOnBirBucuk.Size = new System.Drawing.Size(129, 70);
            this.picBoxSaatOnBirBucuk.TabIndex = 144;
            this.picBoxSaatOnBirBucuk.TabStop = false;
            this.picBoxSaatOnBirBucuk.Click += new System.EventHandler(this.picBoxSaatOnBirBucuk_Click);
            // 
            // picBoxSaatOnAltı
            // 
            this.picBoxSaatOnAltı.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxSaatOnAltı.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxSaatOnAltı.BackgroundImage")));
            this.picBoxSaatOnAltı.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxSaatOnAltı.Location = new System.Drawing.Point(878, 558);
            this.picBoxSaatOnAltı.Name = "picBoxSaatOnAltı";
            this.picBoxSaatOnAltı.Size = new System.Drawing.Size(129, 70);
            this.picBoxSaatOnAltı.TabIndex = 153;
            this.picBoxSaatOnAltı.TabStop = false;
            this.picBoxSaatOnAltı.Click += new System.EventHandler(this.picBoxSaatOnAltı_Click);
            // 
            // picBoxSaatOnBesOtuz
            // 
            this.picBoxSaatOnBesOtuz.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxSaatOnBesOtuz.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxSaatOnBesOtuz.BackgroundImage")));
            this.picBoxSaatOnBesOtuz.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxSaatOnBesOtuz.Location = new System.Drawing.Point(743, 558);
            this.picBoxSaatOnBesOtuz.Name = "picBoxSaatOnBesOtuz";
            this.picBoxSaatOnBesOtuz.Size = new System.Drawing.Size(129, 70);
            this.picBoxSaatOnBesOtuz.TabIndex = 152;
            this.picBoxSaatOnBesOtuz.TabStop = false;
            this.picBoxSaatOnBesOtuz.Click += new System.EventHandler(this.picBoxSaatOnBesOtuz_Click);
            // 
            // picBoxSaatOnBes
            // 
            this.picBoxSaatOnBes.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxSaatOnBes.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxSaatOnBes.BackgroundImage")));
            this.picBoxSaatOnBes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxSaatOnBes.Location = new System.Drawing.Point(608, 558);
            this.picBoxSaatOnBes.Name = "picBoxSaatOnBes";
            this.picBoxSaatOnBes.Size = new System.Drawing.Size(129, 70);
            this.picBoxSaatOnBes.TabIndex = 151;
            this.picBoxSaatOnBes.TabStop = false;
            this.picBoxSaatOnBes.Click += new System.EventHandler(this.picBoxSaatOnBes_Click);
            // 
            // picBoxSaatOnDörtOtuz
            // 
            this.picBoxSaatOnDörtOtuz.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxSaatOnDörtOtuz.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxSaatOnDörtOtuz.BackgroundImage")));
            this.picBoxSaatOnDörtOtuz.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxSaatOnDörtOtuz.Location = new System.Drawing.Point(471, 558);
            this.picBoxSaatOnDörtOtuz.Name = "picBoxSaatOnDörtOtuz";
            this.picBoxSaatOnDörtOtuz.Size = new System.Drawing.Size(129, 70);
            this.picBoxSaatOnDörtOtuz.TabIndex = 150;
            this.picBoxSaatOnDörtOtuz.TabStop = false;
            this.picBoxSaatOnDörtOtuz.Click += new System.EventHandler(this.picBoxSaatOnDörtOtuz_Click);
            // 
            // picBoxSaatOnDört
            // 
            this.picBoxSaatOnDört.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxSaatOnDört.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxSaatOnDört.BackgroundImage")));
            this.picBoxSaatOnDört.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxSaatOnDört.Location = new System.Drawing.Point(336, 558);
            this.picBoxSaatOnDört.Name = "picBoxSaatOnDört";
            this.picBoxSaatOnDört.Size = new System.Drawing.Size(129, 70);
            this.picBoxSaatOnDört.TabIndex = 149;
            this.picBoxSaatOnDört.TabStop = false;
            this.picBoxSaatOnDört.Click += new System.EventHandler(this.picBoxSaatOnDört_Click);
            // 
            // lblSaatDokuz
            // 
            this.lblSaatDokuz.AutoSize = true;
            this.lblSaatDokuz.BackColor = System.Drawing.Color.White;
            this.lblSaatDokuz.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSaatDokuz.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblSaatDokuz.Image = ((System.Drawing.Image)(resources.GetObject("lblSaatDokuz.Image")));
            this.lblSaatDokuz.Location = new System.Drawing.Point(389, 417);
            this.lblSaatDokuz.Name = "lblSaatDokuz";
            this.lblSaatDokuz.Size = new System.Drawing.Size(65, 24);
            this.lblSaatDokuz.TabIndex = 154;
            this.lblSaatDokuz.Text = "09:00";
            // 
            // lblSaatDokuzBucuk
            // 
            this.lblSaatDokuzBucuk.AutoSize = true;
            this.lblSaatDokuzBucuk.BackColor = System.Drawing.Color.White;
            this.lblSaatDokuzBucuk.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSaatDokuzBucuk.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblSaatDokuzBucuk.Image = ((System.Drawing.Image)(resources.GetObject("lblSaatDokuzBucuk.Image")));
            this.lblSaatDokuzBucuk.Location = new System.Drawing.Point(520, 417);
            this.lblSaatDokuzBucuk.Name = "lblSaatDokuzBucuk";
            this.lblSaatDokuzBucuk.Size = new System.Drawing.Size(65, 24);
            this.lblSaatDokuzBucuk.TabIndex = 155;
            this.lblSaatDokuzBucuk.Text = "09:30";
            // 
            // lblSaatOn
            // 
            this.lblSaatOn.AutoSize = true;
            this.lblSaatOn.BackColor = System.Drawing.Color.White;
            this.lblSaatOn.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSaatOn.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblSaatOn.Image = ((System.Drawing.Image)(resources.GetObject("lblSaatOn.Image")));
            this.lblSaatOn.Location = new System.Drawing.Point(662, 417);
            this.lblSaatOn.Name = "lblSaatOn";
            this.lblSaatOn.Size = new System.Drawing.Size(65, 24);
            this.lblSaatOn.TabIndex = 156;
            this.lblSaatOn.Text = "10:00";
            // 
            // lblSaatOnBucuk
            // 
            this.lblSaatOnBucuk.AutoSize = true;
            this.lblSaatOnBucuk.BackColor = System.Drawing.Color.White;
            this.lblSaatOnBucuk.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSaatOnBucuk.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblSaatOnBucuk.Image = ((System.Drawing.Image)(resources.GetObject("lblSaatOnBucuk.Image")));
            this.lblSaatOnBucuk.Location = new System.Drawing.Point(796, 417);
            this.lblSaatOnBucuk.Name = "lblSaatOnBucuk";
            this.lblSaatOnBucuk.Size = new System.Drawing.Size(65, 24);
            this.lblSaatOnBucuk.TabIndex = 157;
            this.lblSaatOnBucuk.Text = "10:30";
            // 
            // lblSaatOnBir
            // 
            this.lblSaatOnBir.AutoSize = true;
            this.lblSaatOnBir.BackColor = System.Drawing.Color.White;
            this.lblSaatOnBir.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSaatOnBir.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblSaatOnBir.Image = ((System.Drawing.Image)(resources.GetObject("lblSaatOnBir.Image")));
            this.lblSaatOnBir.Location = new System.Drawing.Point(929, 417);
            this.lblSaatOnBir.Name = "lblSaatOnBir";
            this.lblSaatOnBir.Size = new System.Drawing.Size(64, 24);
            this.lblSaatOnBir.TabIndex = 158;
            this.lblSaatOnBir.Text = "11:00";
            // 
            // lblSaatOnBirBucuk
            // 
            this.lblSaatOnBirBucuk.AutoSize = true;
            this.lblSaatOnBirBucuk.BackColor = System.Drawing.Color.White;
            this.lblSaatOnBirBucuk.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSaatOnBirBucuk.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblSaatOnBirBucuk.Image = ((System.Drawing.Image)(resources.GetObject("lblSaatOnBirBucuk.Image")));
            this.lblSaatOnBirBucuk.Location = new System.Drawing.Point(389, 491);
            this.lblSaatOnBirBucuk.Name = "lblSaatOnBirBucuk";
            this.lblSaatOnBirBucuk.Size = new System.Drawing.Size(64, 24);
            this.lblSaatOnBirBucuk.TabIndex = 159;
            this.lblSaatOnBirBucuk.Text = "11:30";
            // 
            // lblSaatOnİki
            // 
            this.lblSaatOnİki.AutoSize = true;
            this.lblSaatOnİki.BackColor = System.Drawing.Color.White;
            this.lblSaatOnİki.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSaatOnİki.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblSaatOnİki.Image = ((System.Drawing.Image)(resources.GetObject("lblSaatOnİki.Image")));
            this.lblSaatOnİki.Location = new System.Drawing.Point(520, 491);
            this.lblSaatOnİki.Name = "lblSaatOnİki";
            this.lblSaatOnİki.Size = new System.Drawing.Size(65, 24);
            this.lblSaatOnİki.TabIndex = 160;
            this.lblSaatOnİki.Text = "12:00";
            // 
            // lblSaatOnİkiBucuk
            // 
            this.lblSaatOnİkiBucuk.AutoSize = true;
            this.lblSaatOnİkiBucuk.BackColor = System.Drawing.Color.White;
            this.lblSaatOnİkiBucuk.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSaatOnİkiBucuk.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblSaatOnİkiBucuk.Image = ((System.Drawing.Image)(resources.GetObject("lblSaatOnİkiBucuk.Image")));
            this.lblSaatOnİkiBucuk.Location = new System.Drawing.Point(662, 491);
            this.lblSaatOnİkiBucuk.Name = "lblSaatOnİkiBucuk";
            this.lblSaatOnİkiBucuk.Size = new System.Drawing.Size(65, 24);
            this.lblSaatOnİkiBucuk.TabIndex = 161;
            this.lblSaatOnİkiBucuk.Text = "12:30";
            // 
            // lblSaatOnUc
            // 
            this.lblSaatOnUc.AutoSize = true;
            this.lblSaatOnUc.BackColor = System.Drawing.Color.White;
            this.lblSaatOnUc.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSaatOnUc.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblSaatOnUc.Image = ((System.Drawing.Image)(resources.GetObject("lblSaatOnUc.Image")));
            this.lblSaatOnUc.Location = new System.Drawing.Point(796, 491);
            this.lblSaatOnUc.Name = "lblSaatOnUc";
            this.lblSaatOnUc.Size = new System.Drawing.Size(65, 24);
            this.lblSaatOnUc.TabIndex = 162;
            this.lblSaatOnUc.Text = "13:00";
            // 
            // lblSaatOnUcOtuz
            // 
            this.lblSaatOnUcOtuz.AutoSize = true;
            this.lblSaatOnUcOtuz.BackColor = System.Drawing.Color.White;
            this.lblSaatOnUcOtuz.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSaatOnUcOtuz.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblSaatOnUcOtuz.Image = ((System.Drawing.Image)(resources.GetObject("lblSaatOnUcOtuz.Image")));
            this.lblSaatOnUcOtuz.Location = new System.Drawing.Point(929, 491);
            this.lblSaatOnUcOtuz.Name = "lblSaatOnUcOtuz";
            this.lblSaatOnUcOtuz.Size = new System.Drawing.Size(65, 24);
            this.lblSaatOnUcOtuz.TabIndex = 163;
            this.lblSaatOnUcOtuz.Text = "13:30";
            // 
            // lblSaatOnDört
            // 
            this.lblSaatOnDört.AutoSize = true;
            this.lblSaatOnDört.BackColor = System.Drawing.Color.White;
            this.lblSaatOnDört.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSaatOnDört.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblSaatOnDört.Image = ((System.Drawing.Image)(resources.GetObject("lblSaatOnDört.Image")));
            this.lblSaatOnDört.Location = new System.Drawing.Point(389, 570);
            this.lblSaatOnDört.Name = "lblSaatOnDört";
            this.lblSaatOnDört.Size = new System.Drawing.Size(65, 24);
            this.lblSaatOnDört.TabIndex = 164;
            this.lblSaatOnDört.Text = "14:00";
            // 
            // lblSaatOnDörtOtuz
            // 
            this.lblSaatOnDörtOtuz.AutoSize = true;
            this.lblSaatOnDörtOtuz.BackColor = System.Drawing.Color.White;
            this.lblSaatOnDörtOtuz.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSaatOnDörtOtuz.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblSaatOnDörtOtuz.Image = ((System.Drawing.Image)(resources.GetObject("lblSaatOnDörtOtuz.Image")));
            this.lblSaatOnDörtOtuz.Location = new System.Drawing.Point(518, 570);
            this.lblSaatOnDörtOtuz.Name = "lblSaatOnDörtOtuz";
            this.lblSaatOnDörtOtuz.Size = new System.Drawing.Size(65, 24);
            this.lblSaatOnDörtOtuz.TabIndex = 165;
            this.lblSaatOnDörtOtuz.Text = "14:30";
            // 
            // lblSaatOnBes
            // 
            this.lblSaatOnBes.AutoSize = true;
            this.lblSaatOnBes.BackColor = System.Drawing.Color.White;
            this.lblSaatOnBes.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSaatOnBes.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblSaatOnBes.Image = ((System.Drawing.Image)(resources.GetObject("lblSaatOnBes.Image")));
            this.lblSaatOnBes.Location = new System.Drawing.Point(662, 570);
            this.lblSaatOnBes.Name = "lblSaatOnBes";
            this.lblSaatOnBes.Size = new System.Drawing.Size(65, 24);
            this.lblSaatOnBes.TabIndex = 166;
            this.lblSaatOnBes.Text = "15:00";
            // 
            // lblSaatOnBesOtuz
            // 
            this.lblSaatOnBesOtuz.AutoSize = true;
            this.lblSaatOnBesOtuz.BackColor = System.Drawing.Color.White;
            this.lblSaatOnBesOtuz.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSaatOnBesOtuz.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblSaatOnBesOtuz.Image = ((System.Drawing.Image)(resources.GetObject("lblSaatOnBesOtuz.Image")));
            this.lblSaatOnBesOtuz.Location = new System.Drawing.Point(796, 570);
            this.lblSaatOnBesOtuz.Name = "lblSaatOnBesOtuz";
            this.lblSaatOnBesOtuz.Size = new System.Drawing.Size(65, 24);
            this.lblSaatOnBesOtuz.TabIndex = 167;
            this.lblSaatOnBesOtuz.Text = "15:30";
            // 
            // lblSaatOnAltı
            // 
            this.lblSaatOnAltı.AutoSize = true;
            this.lblSaatOnAltı.BackColor = System.Drawing.Color.White;
            this.lblSaatOnAltı.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSaatOnAltı.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblSaatOnAltı.Image = ((System.Drawing.Image)(resources.GetObject("lblSaatOnAltı.Image")));
            this.lblSaatOnAltı.Location = new System.Drawing.Point(934, 570);
            this.lblSaatOnAltı.Name = "lblSaatOnAltı";
            this.lblSaatOnAltı.Size = new System.Drawing.Size(65, 24);
            this.lblSaatOnAltı.TabIndex = 168;
            this.lblSaatOnAltı.Text = "16:00";
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1015, 670);
            this.Controls.Add(this.lblSaatOnAltı);
            this.Controls.Add(this.lblSaatOnBesOtuz);
            this.Controls.Add(this.lblSaatOnBes);
            this.Controls.Add(this.lblSaatOnDörtOtuz);
            this.Controls.Add(this.lblSaatOnDört);
            this.Controls.Add(this.lblSaatOnUcOtuz);
            this.Controls.Add(this.lblSaatOnUc);
            this.Controls.Add(this.lblSaatOnİkiBucuk);
            this.Controls.Add(this.lblSaatOnİki);
            this.Controls.Add(this.lblSaatOnBirBucuk);
            this.Controls.Add(this.lblSaatOnBir);
            this.Controls.Add(this.lblSaatOnBucuk);
            this.Controls.Add(this.lblSaatOn);
            this.Controls.Add(this.lblSaatDokuzBucuk);
            this.Controls.Add(this.lblSaatDokuz);
            this.Controls.Add(this.picBoxSaatOnAltı);
            this.Controls.Add(this.picBoxSaatOnBesOtuz);
            this.Controls.Add(this.picBoxSaatOnBes);
            this.Controls.Add(this.picBoxSaatOnDörtOtuz);
            this.Controls.Add(this.picBoxSaatOnDört);
            this.Controls.Add(this.picBoxSaatOnUcOtuz);
            this.Controls.Add(this.picBoxSaatOnUc);
            this.Controls.Add(this.picBoxSaatOnİkiOtuz);
            this.Controls.Add(this.picBoxSaatOnİki);
            this.Controls.Add(this.picBoxSaatOnBirBucuk);
            this.Controls.Add(this.picBoxSaatOnBir);
            this.Controls.Add(this.picBoxSaatOnBucuk);
            this.Controls.Add(this.picBoxSaatOn);
            this.Controls.Add(this.picBoxSaatDokuzBucuk);
            this.Controls.Add(this.picBoxGeri);
            this.Controls.Add(this.lblTarihveSonrasiniAciklama2);
            this.Controls.Add(this.lblNormalAciklama1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblBransAdi2);
            this.Controls.Add(this.picBoxSaatDokuz);
            this.Controls.Add(this.lblTarih1);
            this.Controls.Add(this.lblBransAdi1);
            this.Controls.Add(this.lblBransAdiAciklama);
            this.Controls.Add(this.llblTarihAciklama);
            this.Controls.Add(this.lblTarihveSonrasiniAciklama3);
            this.Controls.Add(this.lblTarihveSonrasiniAciklama1);
            this.Controls.Add(this.lblTarih2);
            this.Controls.Add(this.picBoxTarihAciklama);
            this.Controls.Add(this.picBoxBransListesi);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btnRandevularım);
            this.Controls.Add(this.btnCikis);
            this.Controls.Add(this.lblHosgeldinizAciklama);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form5";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form5_FormClosed);
            this.Load += new System.EventHandler(this.Form5_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picBoxGeri)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSaatDokuz)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxTarihAciklama)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxBransListesi)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSaatDokuzBucuk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSaatOn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSaatOnBucuk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSaatOnBir)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSaatOnUcOtuz)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSaatOnUc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSaatOnİkiOtuz)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSaatOnİki)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSaatOnBirBucuk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSaatOnAltı)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSaatOnBesOtuz)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSaatOnBes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSaatOnDörtOtuz)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSaatOnDört)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Button btnRandevularım;
        public System.Windows.Forms.Button btnCikis;
        public System.Windows.Forms.Label lblHosgeldinizAciklama;
        public System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox picBoxGeri;
        public System.Windows.Forms.Label lblTarihveSonrasiniAciklama2;
        public System.Windows.Forms.Label lblNormalAciklama1;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label lblBransAdi2;
        public System.Windows.Forms.PictureBox picBoxSaatDokuz;
        public System.Windows.Forms.Label lblTarih1;
        public System.Windows.Forms.Label lblBransAdi1;
        public System.Windows.Forms.Label lblBransAdiAciklama;
        public System.Windows.Forms.Label llblTarihAciklama;
        public System.Windows.Forms.Label lblTarihveSonrasiniAciklama3;
        public System.Windows.Forms.Label lblTarihveSonrasiniAciklama1;
        public System.Windows.Forms.Label lblTarih2;
        public System.Windows.Forms.PictureBox picBoxTarihAciklama;
        public System.Windows.Forms.PictureBox picBoxBransListesi;
        public System.Windows.Forms.Panel panel2;
        public System.Windows.Forms.MonthCalendar monthCalendar_randevuTarihleri;
        public System.Windows.Forms.PictureBox picBoxSaatDokuzBucuk;
        public System.Windows.Forms.PictureBox picBoxSaatOn;
        public System.Windows.Forms.PictureBox picBoxSaatOnBucuk;
        public System.Windows.Forms.PictureBox picBoxSaatOnBir;
        public System.Windows.Forms.PictureBox picBoxSaatOnUcOtuz;
        public System.Windows.Forms.PictureBox picBoxSaatOnUc;
        public System.Windows.Forms.PictureBox picBoxSaatOnİkiOtuz;
        public System.Windows.Forms.PictureBox picBoxSaatOnİki;
        public System.Windows.Forms.PictureBox picBoxSaatOnBirBucuk;
        public System.Windows.Forms.PictureBox picBoxSaatOnAltı;
        public System.Windows.Forms.PictureBox picBoxSaatOnBesOtuz;
        public System.Windows.Forms.PictureBox picBoxSaatOnBes;
        public System.Windows.Forms.PictureBox picBoxSaatOnDörtOtuz;
        public System.Windows.Forms.PictureBox picBoxSaatOnDört;
        public System.Windows.Forms.Label lblSaatDokuz;
        public System.Windows.Forms.Label lblSaatDokuzBucuk;
        public System.Windows.Forms.Label lblSaatOn;
        public System.Windows.Forms.Label lblSaatOnBucuk;
        public System.Windows.Forms.Label lblSaatOnBir;
        public System.Windows.Forms.Label lblSaatOnBirBucuk;
        public System.Windows.Forms.Label lblSaatOnİki;
        public System.Windows.Forms.Label lblSaatOnİkiBucuk;
        public System.Windows.Forms.Label lblSaatOnUc;
        public System.Windows.Forms.Label lblSaatOnUcOtuz;
        public System.Windows.Forms.Label lblSaatOnDört;
        public System.Windows.Forms.Label lblSaatOnDörtOtuz;
        public System.Windows.Forms.Label lblSaatOnBes;
        public System.Windows.Forms.Label lblSaatOnBesOtuz;
        public System.Windows.Forms.Label lblSaatOnAltı;
    }
}