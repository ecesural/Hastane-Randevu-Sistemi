﻿namespace Randevu_Sistemi
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.panel2 = new System.Windows.Forms.Panel();
            this.monthCalendar_randevuTarihleri = new System.Windows.Forms.MonthCalendar();
            this.panel1 = new System.Windows.Forms.Panel();
            this.picBoxBransListesi = new System.Windows.Forms.PictureBox();
            this.picBoxTarihAciklama = new System.Windows.Forms.PictureBox();
            this.llblTarihAciklama = new System.Windows.Forms.Label();
            this.lblTarih1 = new System.Windows.Forms.Label();
            this.lblTarih2 = new System.Windows.Forms.Label();
            this.lblTarihveSonrasiniAciklama1 = new System.Windows.Forms.Label();
            this.btnRandevularım = new System.Windows.Forms.Button();
            this.btnCikis = new System.Windows.Forms.Button();
            this.lblHosgeldinizAciklama = new System.Windows.Forms.Label();
            this.lblTarihveSonrasiniAciklama2 = new System.Windows.Forms.Label();
            this.picBoxKardiyoloji = new System.Windows.Forms.PictureBox();
            this.picBoxNöroloji = new System.Windows.Forms.PictureBox();
            this.picBoxGögüsHastalıkları = new System.Windows.Forms.PictureBox();
            this.picBoxKulakBurunBoğazHastalıkları = new System.Windows.Forms.PictureBox();
            this.picBoxGözHastalıkları = new System.Windows.Forms.PictureBox();
            this.picBoxİcHastalıkları = new System.Windows.Forms.PictureBox();
            this.picBoxKalpveDamarCerrahisi = new System.Windows.Forms.PictureBox();
            this.picBoxGastroenteroloji = new System.Windows.Forms.PictureBox();
            this.picBoxPlastikveEstetikCerrahisi = new System.Windows.Forms.PictureBox();
            this.picBoxKadınHastalıklarıveDogum = new System.Windows.Forms.PictureBox();
            this.picBoxEndokronolojiveMetabolizma = new System.Windows.Forms.PictureBox();
            this.picBoxDermatoloji = new System.Windows.Forms.PictureBox();
            this.picBoxOrtopediveTravma = new System.Windows.Forms.PictureBox();
            this.picBoxFizikselTıpveRehabilitasyon = new System.Windows.Forms.PictureBox();
            this.picBoxÜroloji = new System.Windows.Forms.PictureBox();
            this.picBoxRomatoloji = new System.Windows.Forms.PictureBox();
            this.picBoxHematoloji = new System.Windows.Forms.PictureBox();
            this.picBoxNefroloji = new System.Windows.Forms.PictureBox();
            this.lblBeyinveSinirCerrahisi = new System.Windows.Forms.Label();
            this.lblKardiyoloji = new System.Windows.Forms.Label();
            this.lblNöroloji = new System.Windows.Forms.Label();
            this.picBoxPsikiyatri = new System.Windows.Forms.PictureBox();
            this.lblPsikiyatri = new System.Windows.Forms.Label();
            this.lblİcHastaliklari = new System.Windows.Forms.Label();
            this.lblGözHastaliklari = new System.Windows.Forms.Label();
            this.lblKulakBurunBogazHastaliklari = new System.Windows.Forms.Label();
            this.lblGögüsHastaliklari = new System.Windows.Forms.Label();
            this.lblKalpveDamarCerrahisi = new System.Windows.Forms.Label();
            this.lblGastroenteroloji = new System.Windows.Forms.Label();
            this.lblPlastikveEstetikCerrahisi = new System.Windows.Forms.Label();
            this.lblKadınHastaliklariveDogum = new System.Windows.Forms.Label();
            this.lblEndokronolojiveMetabolizma = new System.Windows.Forms.Label();
            this.lblDermatoloji = new System.Windows.Forms.Label();
            this.lblOrtopediveTravma = new System.Windows.Forms.Label();
            this.lblFizikselTıpveRehabilitasyon = new System.Windows.Forms.Label();
            this.lblHematoloji = new System.Windows.Forms.Label();
            this.lblNefroloji = new System.Windows.Forms.Label();
            this.lblRomatoloji = new System.Windows.Forms.Label();
            this.lblÜroloji = new System.Windows.Forms.Label();
            this.picBoxBeyinveSinirCerrahisi = new System.Windows.Forms.PictureBox();
            this.label21 = new System.Windows.Forms.Label();
            this.lblBosBeyinveSinirCerrahisi = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lblDoluBeyinveSinirCerrahisi = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lblDoluKardiyoloji = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.lblBosKardiyoloji = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.lblBosNöroloji = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.lblDoluNöroloji = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.lblBosPsikiyatri = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.lblDoluPsikiyatri = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.lblBosİcHastaliklari = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.lblDoluİcHastaliklari = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.lblBosGözHastalıkları = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.lblDoluGözHastalıkları = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.lblBosKulakBurunBogazHastaliklari = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.lblDoluKulakBurunBogazHastaliklari = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.lblBosGögüsHastaliklari = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.panel18 = new System.Windows.Forms.Panel();
            this.lblDoluGögüsHastaliklari = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.panel19 = new System.Windows.Forms.Panel();
            this.lblBosKalpveDamarCerrahisi = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.lblDoluKalpveDamarCerrahisi = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.panel21 = new System.Windows.Forms.Panel();
            this.lblBosGastroenteroloji = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.panel22 = new System.Windows.Forms.Panel();
            this.lblDoluGastroenteroloji = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.panel23 = new System.Windows.Forms.Panel();
            this.lblBosPlastikveEstetikCerrahisi = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.panel24 = new System.Windows.Forms.Panel();
            this.lblDoluPlastikveEstetikCerrahisi = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.panel25 = new System.Windows.Forms.Panel();
            this.lblBosKadınHastaliklariveDogum = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.panel26 = new System.Windows.Forms.Panel();
            this.lblDoluKadınHastaliklariveDogum = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.panel27 = new System.Windows.Forms.Panel();
            this.lblBosEndokronolojiveMetabolizma = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.panel28 = new System.Windows.Forms.Panel();
            this.lblDoluEndokronolojiveMetabolizma = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.panel29 = new System.Windows.Forms.Panel();
            this.lblBosDermatoloji = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.panel30 = new System.Windows.Forms.Panel();
            this.lblDoluDermatoloji = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.panel31 = new System.Windows.Forms.Panel();
            this.lblBosOrtopediveTravma = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.panel32 = new System.Windows.Forms.Panel();
            this.lblDoluOrtopediveTravma = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.panel33 = new System.Windows.Forms.Panel();
            this.lblBosFizikselTıpveRehabilitasyon = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.panel34 = new System.Windows.Forms.Panel();
            this.lblDoluFizikselTıpveRehabilitasyon = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.panel35 = new System.Windows.Forms.Panel();
            this.lblBosNefroloji = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.panel36 = new System.Windows.Forms.Panel();
            this.lblDoluNefroloji = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.panel37 = new System.Windows.Forms.Panel();
            this.lblBosHematoloji = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.panel38 = new System.Windows.Forms.Panel();
            this.lblDoluHematoloji = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.panel39 = new System.Windows.Forms.Panel();
            this.lblBosRomatoloji = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.panel40 = new System.Windows.Forms.Panel();
            this.lblDoluRomatoloji = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.panel41 = new System.Windows.Forms.Panel();
            this.lblBosÜroloji = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.panel42 = new System.Windows.Forms.Panel();
            this.lblDoluÜroloji = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxBransListesi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxTarihAciklama)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxKardiyoloji)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxNöroloji)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxGögüsHastalıkları)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxKulakBurunBoğazHastalıkları)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxGözHastalıkları)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxİcHastalıkları)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxKalpveDamarCerrahisi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxGastroenteroloji)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxPlastikveEstetikCerrahisi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxKadınHastalıklarıveDogum)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxEndokronolojiveMetabolizma)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxDermatoloji)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxOrtopediveTravma)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxFizikselTıpveRehabilitasyon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxÜroloji)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxRomatoloji)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxHematoloji)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxNefroloji)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxPsikiyatri)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxBeyinveSinirCerrahisi)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel25.SuspendLayout();
            this.panel26.SuspendLayout();
            this.panel27.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel29.SuspendLayout();
            this.panel30.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel33.SuspendLayout();
            this.panel34.SuspendLayout();
            this.panel35.SuspendLayout();
            this.panel36.SuspendLayout();
            this.panel37.SuspendLayout();
            this.panel38.SuspendLayout();
            this.panel39.SuspendLayout();
            this.panel40.SuspendLayout();
            this.panel41.SuspendLayout();
            this.panel42.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.monthCalendar_randevuTarihleri);
            this.panel2.Location = new System.Drawing.Point(2, 203);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(290, 234);
            this.panel2.TabIndex = 37;
            // 
            // monthCalendar_randevuTarihleri
            // 
            this.monthCalendar_randevuTarihleri.BackColor = System.Drawing.Color.Gold;
            this.monthCalendar_randevuTarihleri.FirstDayOfWeek = System.Windows.Forms.Day.Monday;
            this.monthCalendar_randevuTarihleri.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.monthCalendar_randevuTarihleri.ForeColor = System.Drawing.Color.White;
            this.monthCalendar_randevuTarihleri.Location = new System.Drawing.Point(9, 9);
            this.monthCalendar_randevuTarihleri.MaxSelectionCount = 1;
            this.monthCalendar_randevuTarihleri.Name = "monthCalendar_randevuTarihleri";
            this.monthCalendar_randevuTarihleri.TabIndex = 21;
            this.monthCalendar_randevuTarihleri.TitleBackColor = System.Drawing.Color.Red;
            this.monthCalendar_randevuTarihleri.TitleForeColor = System.Drawing.Color.White;
            this.monthCalendar_randevuTarihleri.TrailingForeColor = System.Drawing.SystemColors.WindowFrame;
            this.monthCalendar_randevuTarihleri.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar_randevuTarihleri_DateChanged);
            // 
            // panel1
            // 
            this.panel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(2, 77);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1011, 110);
            this.panel1.TabIndex = 36;
            // 
            // picBoxBransListesi
            // 
            this.picBoxBransListesi.Image = ((System.Drawing.Image)(resources.GetObject("picBoxBransListesi.Image")));
            this.picBoxBransListesi.Location = new System.Drawing.Point(313, 203);
            this.picBoxBransListesi.Name = "picBoxBransListesi";
            this.picBoxBransListesi.Size = new System.Drawing.Size(690, 35);
            this.picBoxBransListesi.TabIndex = 40;
            this.picBoxBransListesi.TabStop = false;
            // 
            // picBoxTarihAciklama
            // 
            this.picBoxTarihAciklama.Image = ((System.Drawing.Image)(resources.GetObject("picBoxTarihAciklama.Image")));
            this.picBoxTarihAciklama.Location = new System.Drawing.Point(313, 248);
            this.picBoxTarihAciklama.Name = "picBoxTarihAciklama";
            this.picBoxTarihAciklama.Size = new System.Drawing.Size(690, 25);
            this.picBoxTarihAciklama.TabIndex = 41;
            this.picBoxTarihAciklama.TabStop = false;
            // 
            // llblTarihAciklama
            // 
            this.llblTarihAciklama.AutoSize = true;
            this.llblTarihAciklama.BackColor = System.Drawing.SystemColors.Control;
            this.llblTarihAciklama.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.llblTarihAciklama.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.llblTarihAciklama.Image = ((System.Drawing.Image)(resources.GetObject("llblTarihAciklama.Image")));
            this.llblTarihAciklama.Location = new System.Drawing.Point(321, 253);
            this.llblTarihAciklama.Name = "llblTarihAciklama";
            this.llblTarihAciklama.Size = new System.Drawing.Size(98, 15);
            this.llblTarihAciklama.TabIndex = 42;
            this.llblTarihAciklama.Text = "Tarih                    :";
            // 
            // lblTarih1
            // 
            this.lblTarih1.AutoSize = true;
            this.lblTarih1.BackColor = System.Drawing.SystemColors.Control;
            this.lblTarih1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTarih1.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblTarih1.Image = ((System.Drawing.Image)(resources.GetObject("lblTarih1.Image")));
            this.lblTarih1.Location = new System.Drawing.Point(416, 253);
            this.lblTarih1.Name = "lblTarih1";
            this.lblTarih1.Size = new System.Drawing.Size(116, 15);
            this.lblTarih1.TabIndex = 43;
            this.lblTarih1.Text = "ToLongDateString()";
            // 
            // lblTarih2
            // 
            this.lblTarih2.AutoSize = true;
            this.lblTarih2.BackColor = System.Drawing.Color.White;
            this.lblTarih2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTarih2.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblTarih2.Location = new System.Drawing.Point(314, 288);
            this.lblTarih2.Name = "lblTarih2";
            this.lblTarih2.Size = new System.Drawing.Size(116, 15);
            this.lblTarih2.TabIndex = 44;
            this.lblTarih2.Text = "ToLongDateString()";
            // 
            // lblTarihveSonrasiniAciklama1
            // 
            this.lblTarihveSonrasiniAciklama1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTarihveSonrasiniAciklama1.AutoSize = true;
            this.lblTarihveSonrasiniAciklama1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTarihveSonrasiniAciklama1.ForeColor = System.Drawing.Color.Black;
            this.lblTarihveSonrasiniAciklama1.Location = new System.Drawing.Point(461, 288);
            this.lblTarihveSonrasiniAciklama1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTarihveSonrasiniAciklama1.Name = "lblTarihveSonrasiniAciklama1";
            this.lblTarihveSonrasiniAciklama1.Size = new System.Drawing.Size(549, 30);
            this.lblTarihveSonrasiniAciklama1.TabIndex = 45;
            this.lblTarihveSonrasiniAciklama1.Text = "tarihinde randevusu olan poliklinik branşları aşağıda listelenmiştir. Lütfen rand" +
    "evu almak istediğiniz\r\n\r\n";
            // 
            // btnRandevularım
            // 
            this.btnRandevularım.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnRandevularım.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnRandevularım.BackColor = System.Drawing.Color.Orange;
            this.btnRandevularım.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRandevularım.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnRandevularım.ForeColor = System.Drawing.Color.White;
            this.btnRandevularım.Location = new System.Drawing.Point(839, 40);
            this.btnRandevularım.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnRandevularım.Name = "btnRandevularım";
            this.btnRandevularım.Size = new System.Drawing.Size(101, 31);
            this.btnRandevularım.TabIndex = 48;
            this.btnRandevularım.Text = "Randevularım";
            this.btnRandevularım.UseVisualStyleBackColor = false;
            this.btnRandevularım.Click += new System.EventHandler(this.btnRandevularım_Click);
            this.btnRandevularım.MouseLeave += new System.EventHandler(this.btnRandevularım_MouseLeave);
            this.btnRandevularım.MouseMove += new System.Windows.Forms.MouseEventHandler(this.btnRandevularım_MouseMove);
            // 
            // btnCikis
            // 
            this.btnCikis.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnCikis.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnCikis.BackColor = System.Drawing.Color.Orange;
            this.btnCikis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCikis.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnCikis.ForeColor = System.Drawing.Color.White;
            this.btnCikis.Location = new System.Drawing.Point(944, 40);
            this.btnCikis.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnCikis.Name = "btnCikis";
            this.btnCikis.Size = new System.Drawing.Size(66, 31);
            this.btnCikis.TabIndex = 47;
            this.btnCikis.Text = "Çıkış";
            this.btnCikis.UseVisualStyleBackColor = false;
            this.btnCikis.Click += new System.EventHandler(this.btnCikis_Click);
            this.btnCikis.MouseLeave += new System.EventHandler(this.btnCikis_MouseLeave);
            this.btnCikis.MouseMove += new System.Windows.Forms.MouseEventHandler(this.btnCikis_MouseMove);
            // 
            // lblHosgeldinizAciklama
            // 
            this.lblHosgeldinizAciklama.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblHosgeldinizAciklama.AutoSize = true;
            this.lblHosgeldinizAciklama.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblHosgeldinizAciklama.ForeColor = System.Drawing.Color.Black;
            this.lblHosgeldinizAciklama.Location = new System.Drawing.Point(632, 12);
            this.lblHosgeldinizAciklama.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblHosgeldinizAciklama.Name = "lblHosgeldinizAciklama";
            this.lblHosgeldinizAciklama.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblHosgeldinizAciklama.Size = new System.Drawing.Size(135, 15);
            this.lblHosgeldinizAciklama.TabIndex = 46;
            this.lblHosgeldinizAciklama.Text = "lblHosgeldinizAciklama";
            this.lblHosgeldinizAciklama.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTarihveSonrasiniAciklama2
            // 
            this.lblTarihveSonrasiniAciklama2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTarihveSonrasiniAciklama2.AutoSize = true;
            this.lblTarihveSonrasiniAciklama2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTarihveSonrasiniAciklama2.ForeColor = System.Drawing.Color.Black;
            this.lblTarihveSonrasiniAciklama2.Location = new System.Drawing.Point(314, 303);
            this.lblTarihveSonrasiniAciklama2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTarihveSonrasiniAciklama2.Name = "lblTarihveSonrasiniAciklama2";
            this.lblTarihveSonrasiniAciklama2.Size = new System.Drawing.Size(143, 15);
            this.lblTarihveSonrasiniAciklama2.TabIndex = 49;
            this.lblTarihveSonrasiniAciklama2.Text = "branşın üzerine tıklayınız.\r\n";
            // 
            // picBoxKardiyoloji
            // 
            this.picBoxKardiyoloji.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxKardiyoloji.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxKardiyoloji.BackgroundImage")));
            this.picBoxKardiyoloji.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxKardiyoloji.Location = new System.Drawing.Point(517, 331);
            this.picBoxKardiyoloji.Name = "picBoxKardiyoloji";
            this.picBoxKardiyoloji.Size = new System.Drawing.Size(145, 63);
            this.picBoxKardiyoloji.TabIndex = 70;
            this.picBoxKardiyoloji.TabStop = false;
            this.picBoxKardiyoloji.Click += new System.EventHandler(this.picBoxKardiyoloji_Click);
            // 
            // picBoxNöroloji
            // 
            this.picBoxNöroloji.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxNöroloji.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxNöroloji.BackgroundImage")));
            this.picBoxNöroloji.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxNöroloji.Location = new System.Drawing.Point(668, 331);
            this.picBoxNöroloji.Name = "picBoxNöroloji";
            this.picBoxNöroloji.Size = new System.Drawing.Size(145, 63);
            this.picBoxNöroloji.TabIndex = 71;
            this.picBoxNöroloji.TabStop = false;
            this.picBoxNöroloji.Click += new System.EventHandler(this.picBoxNöroloji_Click);
            // 
            // picBoxGögüsHastalıkları
            // 
            this.picBoxGögüsHastalıkları.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxGögüsHastalıkları.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxGögüsHastalıkları.BackgroundImage")));
            this.picBoxGögüsHastalıkları.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxGögüsHastalıkları.Location = new System.Drawing.Point(819, 398);
            this.picBoxGögüsHastalıkları.Name = "picBoxGögüsHastalıkları";
            this.picBoxGögüsHastalıkları.Size = new System.Drawing.Size(145, 63);
            this.picBoxGögüsHastalıkları.TabIndex = 76;
            this.picBoxGögüsHastalıkları.TabStop = false;
            this.picBoxGögüsHastalıkları.Click += new System.EventHandler(this.picBoxGögüsHastalıkları_Click);
            // 
            // picBoxKulakBurunBoğazHastalıkları
            // 
            this.picBoxKulakBurunBoğazHastalıkları.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxKulakBurunBoğazHastalıkları.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxKulakBurunBoğazHastalıkları.BackgroundImage")));
            this.picBoxKulakBurunBoğazHastalıkları.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxKulakBurunBoğazHastalıkları.Location = new System.Drawing.Point(668, 398);
            this.picBoxKulakBurunBoğazHastalıkları.Name = "picBoxKulakBurunBoğazHastalıkları";
            this.picBoxKulakBurunBoğazHastalıkları.Size = new System.Drawing.Size(145, 63);
            this.picBoxKulakBurunBoğazHastalıkları.TabIndex = 75;
            this.picBoxKulakBurunBoğazHastalıkları.TabStop = false;
            this.picBoxKulakBurunBoğazHastalıkları.Click += new System.EventHandler(this.picBoxKulakBurunBoğazHastalıkları_Click);
            // 
            // picBoxGözHastalıkları
            // 
            this.picBoxGözHastalıkları.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxGözHastalıkları.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxGözHastalıkları.BackgroundImage")));
            this.picBoxGözHastalıkları.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxGözHastalıkları.Location = new System.Drawing.Point(517, 398);
            this.picBoxGözHastalıkları.Name = "picBoxGözHastalıkları";
            this.picBoxGözHastalıkları.Size = new System.Drawing.Size(145, 63);
            this.picBoxGözHastalıkları.TabIndex = 74;
            this.picBoxGözHastalıkları.TabStop = false;
            this.picBoxGözHastalıkları.Click += new System.EventHandler(this.picBoxGözHastalıkları_Click);
            // 
            // picBoxİcHastalıkları
            // 
            this.picBoxİcHastalıkları.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxİcHastalıkları.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxİcHastalıkları.BackgroundImage")));
            this.picBoxİcHastalıkları.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxİcHastalıkları.Location = new System.Drawing.Point(366, 398);
            this.picBoxİcHastalıkları.Name = "picBoxİcHastalıkları";
            this.picBoxİcHastalıkları.Size = new System.Drawing.Size(145, 63);
            this.picBoxİcHastalıkları.TabIndex = 73;
            this.picBoxİcHastalıkları.TabStop = false;
            this.picBoxİcHastalıkları.Click += new System.EventHandler(this.picBoxİcHastalıkları_Click);
            // 
            // picBoxKalpveDamarCerrahisi
            // 
            this.picBoxKalpveDamarCerrahisi.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxKalpveDamarCerrahisi.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxKalpveDamarCerrahisi.BackgroundImage")));
            this.picBoxKalpveDamarCerrahisi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxKalpveDamarCerrahisi.Location = new System.Drawing.Point(366, 465);
            this.picBoxKalpveDamarCerrahisi.Name = "picBoxKalpveDamarCerrahisi";
            this.picBoxKalpveDamarCerrahisi.Size = new System.Drawing.Size(145, 63);
            this.picBoxKalpveDamarCerrahisi.TabIndex = 77;
            this.picBoxKalpveDamarCerrahisi.TabStop = false;
            this.picBoxKalpveDamarCerrahisi.Click += new System.EventHandler(this.picBoxKalpveDamarCerrahisi_Click);
            // 
            // picBoxGastroenteroloji
            // 
            this.picBoxGastroenteroloji.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxGastroenteroloji.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxGastroenteroloji.BackgroundImage")));
            this.picBoxGastroenteroloji.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxGastroenteroloji.Location = new System.Drawing.Point(517, 465);
            this.picBoxGastroenteroloji.Name = "picBoxGastroenteroloji";
            this.picBoxGastroenteroloji.Size = new System.Drawing.Size(145, 63);
            this.picBoxGastroenteroloji.TabIndex = 78;
            this.picBoxGastroenteroloji.TabStop = false;
            this.picBoxGastroenteroloji.Click += new System.EventHandler(this.picBoxGastroenteroloji_Click);
            // 
            // picBoxPlastikveEstetikCerrahisi
            // 
            this.picBoxPlastikveEstetikCerrahisi.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxPlastikveEstetikCerrahisi.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxPlastikveEstetikCerrahisi.BackgroundImage")));
            this.picBoxPlastikveEstetikCerrahisi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxPlastikveEstetikCerrahisi.Location = new System.Drawing.Point(668, 465);
            this.picBoxPlastikveEstetikCerrahisi.Name = "picBoxPlastikveEstetikCerrahisi";
            this.picBoxPlastikveEstetikCerrahisi.Size = new System.Drawing.Size(145, 63);
            this.picBoxPlastikveEstetikCerrahisi.TabIndex = 79;
            this.picBoxPlastikveEstetikCerrahisi.TabStop = false;
            this.picBoxPlastikveEstetikCerrahisi.Click += new System.EventHandler(this.picBoxPlastikveEstetikCerrahisi_Click);
            // 
            // picBoxKadınHastalıklarıveDogum
            // 
            this.picBoxKadınHastalıklarıveDogum.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxKadınHastalıklarıveDogum.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxKadınHastalıklarıveDogum.BackgroundImage")));
            this.picBoxKadınHastalıklarıveDogum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxKadınHastalıklarıveDogum.Location = new System.Drawing.Point(819, 465);
            this.picBoxKadınHastalıklarıveDogum.Name = "picBoxKadınHastalıklarıveDogum";
            this.picBoxKadınHastalıklarıveDogum.Size = new System.Drawing.Size(145, 63);
            this.picBoxKadınHastalıklarıveDogum.TabIndex = 80;
            this.picBoxKadınHastalıklarıveDogum.TabStop = false;
            this.picBoxKadınHastalıklarıveDogum.Click += new System.EventHandler(this.picBoxKadınHastalıklarıveDogum_Click);
            // 
            // picBoxEndokronolojiveMetabolizma
            // 
            this.picBoxEndokronolojiveMetabolizma.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxEndokronolojiveMetabolizma.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxEndokronolojiveMetabolizma.BackgroundImage")));
            this.picBoxEndokronolojiveMetabolizma.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxEndokronolojiveMetabolizma.Location = new System.Drawing.Point(366, 532);
            this.picBoxEndokronolojiveMetabolizma.Name = "picBoxEndokronolojiveMetabolizma";
            this.picBoxEndokronolojiveMetabolizma.Size = new System.Drawing.Size(145, 63);
            this.picBoxEndokronolojiveMetabolizma.TabIndex = 81;
            this.picBoxEndokronolojiveMetabolizma.TabStop = false;
            this.picBoxEndokronolojiveMetabolizma.Click += new System.EventHandler(this.picBoxEndokronolojiveMetabolizma_Click);
            // 
            // picBoxDermatoloji
            // 
            this.picBoxDermatoloji.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxDermatoloji.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxDermatoloji.BackgroundImage")));
            this.picBoxDermatoloji.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxDermatoloji.Location = new System.Drawing.Point(516, 532);
            this.picBoxDermatoloji.Name = "picBoxDermatoloji";
            this.picBoxDermatoloji.Size = new System.Drawing.Size(145, 63);
            this.picBoxDermatoloji.TabIndex = 82;
            this.picBoxDermatoloji.TabStop = false;
            this.picBoxDermatoloji.Click += new System.EventHandler(this.picBoxDermatoloji_Click);
            // 
            // picBoxOrtopediveTravma
            // 
            this.picBoxOrtopediveTravma.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxOrtopediveTravma.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxOrtopediveTravma.BackgroundImage")));
            this.picBoxOrtopediveTravma.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxOrtopediveTravma.Location = new System.Drawing.Point(668, 532);
            this.picBoxOrtopediveTravma.Name = "picBoxOrtopediveTravma";
            this.picBoxOrtopediveTravma.Size = new System.Drawing.Size(145, 63);
            this.picBoxOrtopediveTravma.TabIndex = 83;
            this.picBoxOrtopediveTravma.TabStop = false;
            this.picBoxOrtopediveTravma.Click += new System.EventHandler(this.picBoxOrtopediveTravma_Click);
            // 
            // picBoxFizikselTıpveRehabilitasyon
            // 
            this.picBoxFizikselTıpveRehabilitasyon.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxFizikselTıpveRehabilitasyon.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxFizikselTıpveRehabilitasyon.BackgroundImage")));
            this.picBoxFizikselTıpveRehabilitasyon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxFizikselTıpveRehabilitasyon.Location = new System.Drawing.Point(819, 532);
            this.picBoxFizikselTıpveRehabilitasyon.Name = "picBoxFizikselTıpveRehabilitasyon";
            this.picBoxFizikselTıpveRehabilitasyon.Size = new System.Drawing.Size(145, 63);
            this.picBoxFizikselTıpveRehabilitasyon.TabIndex = 84;
            this.picBoxFizikselTıpveRehabilitasyon.TabStop = false;
            this.picBoxFizikselTıpveRehabilitasyon.Click += new System.EventHandler(this.picBoxFizikselTıpveRehabilitasyon_Click);
            // 
            // picBoxÜroloji
            // 
            this.picBoxÜroloji.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxÜroloji.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxÜroloji.BackgroundImage")));
            this.picBoxÜroloji.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxÜroloji.Location = new System.Drawing.Point(819, 599);
            this.picBoxÜroloji.Name = "picBoxÜroloji";
            this.picBoxÜroloji.Size = new System.Drawing.Size(145, 63);
            this.picBoxÜroloji.TabIndex = 88;
            this.picBoxÜroloji.TabStop = false;
            this.picBoxÜroloji.Click += new System.EventHandler(this.picBoxÜroloji_Click);
            // 
            // picBoxRomatoloji
            // 
            this.picBoxRomatoloji.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxRomatoloji.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxRomatoloji.BackgroundImage")));
            this.picBoxRomatoloji.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxRomatoloji.Location = new System.Drawing.Point(668, 599);
            this.picBoxRomatoloji.Name = "picBoxRomatoloji";
            this.picBoxRomatoloji.Size = new System.Drawing.Size(145, 63);
            this.picBoxRomatoloji.TabIndex = 87;
            this.picBoxRomatoloji.TabStop = false;
            this.picBoxRomatoloji.Click += new System.EventHandler(this.picBoxRomatoloji_Click);
            // 
            // picBoxHematoloji
            // 
            this.picBoxHematoloji.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxHematoloji.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxHematoloji.BackgroundImage")));
            this.picBoxHematoloji.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxHematoloji.Location = new System.Drawing.Point(517, 599);
            this.picBoxHematoloji.Name = "picBoxHematoloji";
            this.picBoxHematoloji.Size = new System.Drawing.Size(145, 63);
            this.picBoxHematoloji.TabIndex = 86;
            this.picBoxHematoloji.TabStop = false;
            this.picBoxHematoloji.Click += new System.EventHandler(this.picBoxHematoloji_Click);
            // 
            // picBoxNefroloji
            // 
            this.picBoxNefroloji.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxNefroloji.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxNefroloji.BackgroundImage")));
            this.picBoxNefroloji.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxNefroloji.Location = new System.Drawing.Point(366, 599);
            this.picBoxNefroloji.Name = "picBoxNefroloji";
            this.picBoxNefroloji.Size = new System.Drawing.Size(145, 63);
            this.picBoxNefroloji.TabIndex = 85;
            this.picBoxNefroloji.TabStop = false;
            this.picBoxNefroloji.Click += new System.EventHandler(this.picBoxNefroloji_Click);
            // 
            // lblBeyinveSinirCerrahisi
            // 
            this.lblBeyinveSinirCerrahisi.AutoSize = true;
            this.lblBeyinveSinirCerrahisi.BackColor = System.Drawing.Color.White;
            this.lblBeyinveSinirCerrahisi.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBeyinveSinirCerrahisi.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblBeyinveSinirCerrahisi.Image = ((System.Drawing.Image)(resources.GetObject("lblBeyinveSinirCerrahisi.Image")));
            this.lblBeyinveSinirCerrahisi.Location = new System.Drawing.Point(394, 338);
            this.lblBeyinveSinirCerrahisi.Name = "lblBeyinveSinirCerrahisi";
            this.lblBeyinveSinirCerrahisi.Size = new System.Drawing.Size(97, 32);
            this.lblBeyinveSinirCerrahisi.TabIndex = 93;
            this.lblBeyinveSinirCerrahisi.Text = "Beyin ve Sinir\r\n   Cerrahisi";
            // 
            // lblKardiyoloji
            // 
            this.lblKardiyoloji.AutoSize = true;
            this.lblKardiyoloji.BackColor = System.Drawing.Color.White;
            this.lblKardiyoloji.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblKardiyoloji.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblKardiyoloji.Image = ((System.Drawing.Image)(resources.GetObject("lblKardiyoloji.Image")));
            this.lblKardiyoloji.Location = new System.Drawing.Point(549, 347);
            this.lblKardiyoloji.Name = "lblKardiyoloji";
            this.lblKardiyoloji.Size = new System.Drawing.Size(77, 16);
            this.lblKardiyoloji.TabIndex = 94;
            this.lblKardiyoloji.Text = "Kardiyoloji";
            // 
            // lblNöroloji
            // 
            this.lblNöroloji.AutoSize = true;
            this.lblNöroloji.BackColor = System.Drawing.Color.White;
            this.lblNöroloji.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblNöroloji.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblNöroloji.Image = ((System.Drawing.Image)(resources.GetObject("lblNöroloji.Image")));
            this.lblNöroloji.Location = new System.Drawing.Point(709, 347);
            this.lblNöroloji.Name = "lblNöroloji";
            this.lblNöroloji.Size = new System.Drawing.Size(58, 16);
            this.lblNöroloji.TabIndex = 95;
            this.lblNöroloji.Text = "Nöroloji";
            // 
            // picBoxPsikiyatri
            // 
            this.picBoxPsikiyatri.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxPsikiyatri.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxPsikiyatri.BackgroundImage")));
            this.picBoxPsikiyatri.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxPsikiyatri.Location = new System.Drawing.Point(819, 331);
            this.picBoxPsikiyatri.Name = "picBoxPsikiyatri";
            this.picBoxPsikiyatri.Size = new System.Drawing.Size(145, 63);
            this.picBoxPsikiyatri.TabIndex = 72;
            this.picBoxPsikiyatri.TabStop = false;
            this.picBoxPsikiyatri.Click += new System.EventHandler(this.picBoxPsikiyatri_Click);
            // 
            // lblPsikiyatri
            // 
            this.lblPsikiyatri.AutoSize = true;
            this.lblPsikiyatri.BackColor = System.Drawing.Color.White;
            this.lblPsikiyatri.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblPsikiyatri.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblPsikiyatri.Image = ((System.Drawing.Image)(resources.GetObject("lblPsikiyatri.Image")));
            this.lblPsikiyatri.Location = new System.Drawing.Point(856, 347);
            this.lblPsikiyatri.Name = "lblPsikiyatri";
            this.lblPsikiyatri.Size = new System.Drawing.Size(66, 16);
            this.lblPsikiyatri.TabIndex = 96;
            this.lblPsikiyatri.Text = "Psikiyatri";
            // 
            // lblİcHastaliklari
            // 
            this.lblİcHastaliklari.AutoSize = true;
            this.lblİcHastaliklari.BackColor = System.Drawing.Color.White;
            this.lblİcHastaliklari.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblİcHastaliklari.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblİcHastaliklari.Image = ((System.Drawing.Image)(resources.GetObject("lblİcHastaliklari.Image")));
            this.lblİcHastaliklari.Location = new System.Drawing.Point(400, 410);
            this.lblİcHastaliklari.Name = "lblİcHastaliklari";
            this.lblİcHastaliklari.Size = new System.Drawing.Size(94, 16);
            this.lblİcHastaliklari.TabIndex = 97;
            this.lblİcHastaliklari.Text = "İç Hastalıkları";
            // 
            // lblGözHastaliklari
            // 
            this.lblGözHastaliklari.AutoSize = true;
            this.lblGözHastaliklari.BackColor = System.Drawing.Color.White;
            this.lblGözHastaliklari.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblGözHastaliklari.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblGözHastaliklari.Image = ((System.Drawing.Image)(resources.GetObject("lblGözHastaliklari.Image")));
            this.lblGözHastaliklari.Location = new System.Drawing.Point(537, 410);
            this.lblGözHastaliklari.Name = "lblGözHastaliklari";
            this.lblGözHastaliklari.Size = new System.Drawing.Size(108, 16);
            this.lblGözHastaliklari.TabIndex = 98;
            this.lblGözHastaliklari.Text = "Göz Hastalıkları";
            // 
            // lblKulakBurunBogazHastaliklari
            // 
            this.lblKulakBurunBogazHastaliklari.AutoSize = true;
            this.lblKulakBurunBogazHastaliklari.BackColor = System.Drawing.Color.White;
            this.lblKulakBurunBogazHastaliklari.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblKulakBurunBogazHastaliklari.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblKulakBurunBogazHastaliklari.Image = ((System.Drawing.Image)(resources.GetObject("lblKulakBurunBogazHastaliklari.Image")));
            this.lblKulakBurunBogazHastaliklari.Location = new System.Drawing.Point(675, 405);
            this.lblKulakBurunBogazHastaliklari.Name = "lblKulakBurunBogazHastaliklari";
            this.lblKulakBurunBogazHastaliklari.Size = new System.Drawing.Size(130, 32);
            this.lblKulakBurunBogazHastaliklari.TabIndex = 99;
            this.lblKulakBurunBogazHastaliklari.Text = "Kulak-Burun-Boğaz\r\n       Hastalıkları";
            // 
            // lblGögüsHastaliklari
            // 
            this.lblGögüsHastaliklari.AutoSize = true;
            this.lblGögüsHastaliklari.BackColor = System.Drawing.Color.White;
            this.lblGögüsHastaliklari.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblGögüsHastaliklari.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblGögüsHastaliklari.Image = ((System.Drawing.Image)(resources.GetObject("lblGögüsHastaliklari.Image")));
            this.lblGögüsHastaliklari.Location = new System.Drawing.Point(830, 410);
            this.lblGögüsHastaliklari.Name = "lblGögüsHastaliklari";
            this.lblGögüsHastaliklari.Size = new System.Drawing.Size(123, 16);
            this.lblGögüsHastaliklari.TabIndex = 100;
            this.lblGögüsHastaliklari.Text = "Göğüs Hastalıkları";
            // 
            // lblKalpveDamarCerrahisi
            // 
            this.lblKalpveDamarCerrahisi.AutoSize = true;
            this.lblKalpveDamarCerrahisi.BackColor = System.Drawing.Color.White;
            this.lblKalpveDamarCerrahisi.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblKalpveDamarCerrahisi.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblKalpveDamarCerrahisi.Image = ((System.Drawing.Image)(resources.GetObject("lblKalpveDamarCerrahisi.Image")));
            this.lblKalpveDamarCerrahisi.Location = new System.Drawing.Point(390, 472);
            this.lblKalpveDamarCerrahisi.Name = "lblKalpveDamarCerrahisi";
            this.lblKalpveDamarCerrahisi.Size = new System.Drawing.Size(102, 32);
            this.lblKalpveDamarCerrahisi.TabIndex = 101;
            this.lblKalpveDamarCerrahisi.Text = "Kalp ve Damar\r\n   Cerrahisi";
            // 
            // lblGastroenteroloji
            // 
            this.lblGastroenteroloji.AutoSize = true;
            this.lblGastroenteroloji.BackColor = System.Drawing.Color.White;
            this.lblGastroenteroloji.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblGastroenteroloji.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblGastroenteroloji.Image = ((System.Drawing.Image)(resources.GetObject("lblGastroenteroloji.Image")));
            this.lblGastroenteroloji.Location = new System.Drawing.Point(534, 475);
            this.lblGastroenteroloji.Name = "lblGastroenteroloji";
            this.lblGastroenteroloji.Size = new System.Drawing.Size(110, 16);
            this.lblGastroenteroloji.TabIndex = 102;
            this.lblGastroenteroloji.Text = "Gastroenteroloji";
            // 
            // lblPlastikveEstetikCerrahisi
            // 
            this.lblPlastikveEstetikCerrahisi.AutoSize = true;
            this.lblPlastikveEstetikCerrahisi.BackColor = System.Drawing.Color.White;
            this.lblPlastikveEstetikCerrahisi.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblPlastikveEstetikCerrahisi.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblPlastikveEstetikCerrahisi.Image = ((System.Drawing.Image)(resources.GetObject("lblPlastikveEstetikCerrahisi.Image")));
            this.lblPlastikveEstetikCerrahisi.Location = new System.Drawing.Point(685, 472);
            this.lblPlastikveEstetikCerrahisi.Name = "lblPlastikveEstetikCerrahisi";
            this.lblPlastikveEstetikCerrahisi.Size = new System.Drawing.Size(114, 32);
            this.lblPlastikveEstetikCerrahisi.TabIndex = 103;
            this.lblPlastikveEstetikCerrahisi.Text = "Plastik ve Estetik\r\n     Cerrahisi";
            // 
            // lblKadınHastaliklariveDogum
            // 
            this.lblKadınHastaliklariveDogum.AutoSize = true;
            this.lblKadınHastaliklariveDogum.BackColor = System.Drawing.Color.White;
            this.lblKadınHastaliklariveDogum.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblKadınHastaliklariveDogum.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblKadınHastaliklariveDogum.Image = ((System.Drawing.Image)(resources.GetObject("lblKadınHastaliklariveDogum.Image")));
            this.lblKadınHastaliklariveDogum.Location = new System.Drawing.Point(830, 472);
            this.lblKadınHastaliklariveDogum.Name = "lblKadınHastaliklariveDogum";
            this.lblKadınHastaliklariveDogum.Size = new System.Drawing.Size(120, 32);
            this.lblKadınHastaliklariveDogum.TabIndex = 104;
            this.lblKadınHastaliklariveDogum.Text = "Kadın Hastalıkları\r\n     ve Doğum";
            // 
            // lblEndokronolojiveMetabolizma
            // 
            this.lblEndokronolojiveMetabolizma.AutoSize = true;
            this.lblEndokronolojiveMetabolizma.BackColor = System.Drawing.Color.White;
            this.lblEndokronolojiveMetabolizma.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblEndokronolojiveMetabolizma.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblEndokronolojiveMetabolizma.Image = ((System.Drawing.Image)(resources.GetObject("lblEndokronolojiveMetabolizma.Image")));
            this.lblEndokronolojiveMetabolizma.Location = new System.Drawing.Point(379, 539);
            this.lblEndokronolojiveMetabolizma.Name = "lblEndokronolojiveMetabolizma";
            this.lblEndokronolojiveMetabolizma.Size = new System.Drawing.Size(115, 32);
            this.lblEndokronolojiveMetabolizma.TabIndex = 105;
            this.lblEndokronolojiveMetabolizma.Text = "Endokronoloji ve\r\n   Metabolizma";
            // 
            // lblDermatoloji
            // 
            this.lblDermatoloji.AutoSize = true;
            this.lblDermatoloji.BackColor = System.Drawing.Color.White;
            this.lblDermatoloji.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblDermatoloji.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblDermatoloji.Image = ((System.Drawing.Image)(resources.GetObject("lblDermatoloji.Image")));
            this.lblDermatoloji.Location = new System.Drawing.Point(545, 544);
            this.lblDermatoloji.Name = "lblDermatoloji";
            this.lblDermatoloji.Size = new System.Drawing.Size(82, 16);
            this.lblDermatoloji.TabIndex = 106;
            this.lblDermatoloji.Text = "Dermatoloji";
            // 
            // lblOrtopediveTravma
            // 
            this.lblOrtopediveTravma.AutoSize = true;
            this.lblOrtopediveTravma.BackColor = System.Drawing.Color.White;
            this.lblOrtopediveTravma.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblOrtopediveTravma.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblOrtopediveTravma.Image = ((System.Drawing.Image)(resources.GetObject("lblOrtopediveTravma.Image")));
            this.lblOrtopediveTravma.Location = new System.Drawing.Point(697, 539);
            this.lblOrtopediveTravma.Name = "lblOrtopediveTravma";
            this.lblOrtopediveTravma.Size = new System.Drawing.Size(82, 32);
            this.lblOrtopediveTravma.TabIndex = 107;
            this.lblOrtopediveTravma.Text = "Ortopedi ve\r\n   Travma.";
            // 
            // lblFizikselTıpveRehabilitasyon
            // 
            this.lblFizikselTıpveRehabilitasyon.AutoSize = true;
            this.lblFizikselTıpveRehabilitasyon.BackColor = System.Drawing.Color.White;
            this.lblFizikselTıpveRehabilitasyon.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblFizikselTıpveRehabilitasyon.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblFizikselTıpveRehabilitasyon.Image = ((System.Drawing.Image)(resources.GetObject("lblFizikselTıpveRehabilitasyon.Image")));
            this.lblFizikselTıpveRehabilitasyon.Location = new System.Drawing.Point(825, 539);
            this.lblFizikselTıpveRehabilitasyon.Name = "lblFizikselTıpveRehabilitasyon";
            this.lblFizikselTıpveRehabilitasyon.Size = new System.Drawing.Size(118, 32);
            this.lblFizikselTıpveRehabilitasyon.TabIndex = 108;
            this.lblFizikselTıpveRehabilitasyon.Text = "    Fiziksel Tıp ve\r\n    Rehabilitasyon";
            // 
            // lblHematoloji
            // 
            this.lblHematoloji.AutoSize = true;
            this.lblHematoloji.BackColor = System.Drawing.Color.White;
            this.lblHematoloji.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblHematoloji.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblHematoloji.Image = ((System.Drawing.Image)(resources.GetObject("lblHematoloji.Image")));
            this.lblHematoloji.Location = new System.Drawing.Point(549, 611);
            this.lblHematoloji.Name = "lblHematoloji";
            this.lblHematoloji.Size = new System.Drawing.Size(77, 16);
            this.lblHematoloji.TabIndex = 109;
            this.lblHematoloji.Text = "Hematoloji";
            // 
            // lblNefroloji
            // 
            this.lblNefroloji.AutoSize = true;
            this.lblNefroloji.BackColor = System.Drawing.Color.White;
            this.lblNefroloji.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblNefroloji.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblNefroloji.Image = ((System.Drawing.Image)(resources.GetObject("lblNefroloji.Image")));
            this.lblNefroloji.Location = new System.Drawing.Point(412, 611);
            this.lblNefroloji.Name = "lblNefroloji";
            this.lblNefroloji.Size = new System.Drawing.Size(62, 16);
            this.lblNefroloji.TabIndex = 110;
            this.lblNefroloji.Text = "Nefroloji";
            // 
            // lblRomatoloji
            // 
            this.lblRomatoloji.AutoSize = true;
            this.lblRomatoloji.BackColor = System.Drawing.Color.White;
            this.lblRomatoloji.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblRomatoloji.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblRomatoloji.Image = ((System.Drawing.Image)(resources.GetObject("lblRomatoloji.Image")));
            this.lblRomatoloji.Location = new System.Drawing.Point(702, 611);
            this.lblRomatoloji.Name = "lblRomatoloji";
            this.lblRomatoloji.Size = new System.Drawing.Size(77, 16);
            this.lblRomatoloji.TabIndex = 111;
            this.lblRomatoloji.Text = "Romatoloji";
            // 
            // lblÜroloji
            // 
            this.lblÜroloji.AutoSize = true;
            this.lblÜroloji.BackColor = System.Drawing.Color.White;
            this.lblÜroloji.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblÜroloji.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblÜroloji.Image = ((System.Drawing.Image)(resources.GetObject("lblÜroloji.Image")));
            this.lblÜroloji.Location = new System.Drawing.Point(860, 611);
            this.lblÜroloji.Name = "lblÜroloji";
            this.lblÜroloji.Size = new System.Drawing.Size(50, 16);
            this.lblÜroloji.TabIndex = 112;
            this.lblÜroloji.Text = "Üroloji";
            // 
            // picBoxBeyinveSinirCerrahisi
            // 
            this.picBoxBeyinveSinirCerrahisi.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxBeyinveSinirCerrahisi.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxBeyinveSinirCerrahisi.BackgroundImage")));
            this.picBoxBeyinveSinirCerrahisi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxBeyinveSinirCerrahisi.Location = new System.Drawing.Point(366, 331);
            this.picBoxBeyinveSinirCerrahisi.Name = "picBoxBeyinveSinirCerrahisi";
            this.picBoxBeyinveSinirCerrahisi.Size = new System.Drawing.Size(145, 63);
            this.picBoxBeyinveSinirCerrahisi.TabIndex = 69;
            this.picBoxBeyinveSinirCerrahisi.TabStop = false;
            this.picBoxBeyinveSinirCerrahisi.Click += new System.EventHandler(this.picBoxBeyinveSinirCerrahisi_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label21.ForeColor = System.Drawing.Color.Green;
            this.label21.Location = new System.Drawing.Point(1, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(32, 15);
            this.label21.TabIndex = 113;
            this.label21.Text = "Boş:";
            // 
            // lblBosBeyinveSinirCerrahisi
            // 
            this.lblBosBeyinveSinirCerrahisi.AutoSize = true;
            this.lblBosBeyinveSinirCerrahisi.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBosBeyinveSinirCerrahisi.ForeColor = System.Drawing.Color.Green;
            this.lblBosBeyinveSinirCerrahisi.Location = new System.Drawing.Point(29, 0);
            this.lblBosBeyinveSinirCerrahisi.Name = "lblBosBeyinveSinirCerrahisi";
            this.lblBosBeyinveSinirCerrahisi.Size = new System.Drawing.Size(21, 15);
            this.lblBosBeyinveSinirCerrahisi.TabIndex = 114;
            this.lblBosBeyinveSinirCerrahisi.Text = "15";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.lblBosBeyinveSinirCerrahisi);
            this.panel3.Controls.Add(this.label21);
            this.panel3.Location = new System.Drawing.Point(392, 373);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(50, 19);
            this.panel3.TabIndex = 22;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.MistyRose;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.lblDoluBeyinveSinirCerrahisi);
            this.panel4.Controls.Add(this.label24);
            this.panel4.Location = new System.Drawing.Point(444, 373);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(52, 19);
            this.panel4.TabIndex = 113;
            // 
            // lblDoluBeyinveSinirCerrahisi
            // 
            this.lblDoluBeyinveSinirCerrahisi.AutoSize = true;
            this.lblDoluBeyinveSinirCerrahisi.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblDoluBeyinveSinirCerrahisi.ForeColor = System.Drawing.Color.Red;
            this.lblDoluBeyinveSinirCerrahisi.Location = new System.Drawing.Point(32, 0);
            this.lblDoluBeyinveSinirCerrahisi.Name = "lblDoluBeyinveSinirCerrahisi";
            this.lblDoluBeyinveSinirCerrahisi.Size = new System.Drawing.Size(14, 15);
            this.lblDoluBeyinveSinirCerrahisi.TabIndex = 114;
            this.lblDoluBeyinveSinirCerrahisi.Text = "0";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label24.ForeColor = System.Drawing.Color.Red;
            this.label24.Location = new System.Drawing.Point(0, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(35, 15);
            this.label24.TabIndex = 113;
            this.label24.Text = "Dolu:";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.MistyRose;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.lblDoluKardiyoloji);
            this.panel5.Controls.Add(this.label26);
            this.panel5.Location = new System.Drawing.Point(594, 373);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(52, 19);
            this.panel5.TabIndex = 114;
            // 
            // lblDoluKardiyoloji
            // 
            this.lblDoluKardiyoloji.AutoSize = true;
            this.lblDoluKardiyoloji.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblDoluKardiyoloji.ForeColor = System.Drawing.Color.Red;
            this.lblDoluKardiyoloji.Location = new System.Drawing.Point(31, 0);
            this.lblDoluKardiyoloji.Name = "lblDoluKardiyoloji";
            this.lblDoluKardiyoloji.Size = new System.Drawing.Size(14, 15);
            this.lblDoluKardiyoloji.TabIndex = 114;
            this.lblDoluKardiyoloji.Text = "0";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label26.ForeColor = System.Drawing.Color.Red;
            this.label26.Location = new System.Drawing.Point(1, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(35, 15);
            this.label26.TabIndex = 113;
            this.label26.Text = "Dolu:";
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.lblBosKardiyoloji);
            this.panel6.Controls.Add(this.label28);
            this.panel6.Location = new System.Drawing.Point(540, 373);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(50, 19);
            this.panel6.TabIndex = 115;
            // 
            // lblBosKardiyoloji
            // 
            this.lblBosKardiyoloji.AutoSize = true;
            this.lblBosKardiyoloji.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBosKardiyoloji.ForeColor = System.Drawing.Color.Green;
            this.lblBosKardiyoloji.Location = new System.Drawing.Point(29, 0);
            this.lblBosKardiyoloji.Name = "lblBosKardiyoloji";
            this.lblBosKardiyoloji.Size = new System.Drawing.Size(21, 15);
            this.lblBosKardiyoloji.TabIndex = 114;
            this.lblBosKardiyoloji.Text = "15";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label28.ForeColor = System.Drawing.Color.Green;
            this.label28.Location = new System.Drawing.Point(1, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(32, 15);
            this.label28.TabIndex = 113;
            this.label28.Text = "Boş:";
            // 
            // panel7
            // 
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.lblBosNöroloji);
            this.panel7.Controls.Add(this.label30);
            this.panel7.Location = new System.Drawing.Point(688, 373);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(50, 19);
            this.panel7.TabIndex = 117;
            // 
            // lblBosNöroloji
            // 
            this.lblBosNöroloji.AutoSize = true;
            this.lblBosNöroloji.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBosNöroloji.ForeColor = System.Drawing.Color.Green;
            this.lblBosNöroloji.Location = new System.Drawing.Point(29, 0);
            this.lblBosNöroloji.Name = "lblBosNöroloji";
            this.lblBosNöroloji.Size = new System.Drawing.Size(21, 15);
            this.lblBosNöroloji.TabIndex = 114;
            this.lblBosNöroloji.Text = "15";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label30.ForeColor = System.Drawing.Color.Green;
            this.label30.Location = new System.Drawing.Point(1, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(32, 15);
            this.label30.TabIndex = 113;
            this.label30.Text = "Boş:";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.MistyRose;
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.lblDoluNöroloji);
            this.panel8.Controls.Add(this.label32);
            this.panel8.Location = new System.Drawing.Point(742, 373);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(52, 19);
            this.panel8.TabIndex = 116;
            // 
            // lblDoluNöroloji
            // 
            this.lblDoluNöroloji.AutoSize = true;
            this.lblDoluNöroloji.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblDoluNöroloji.ForeColor = System.Drawing.Color.Red;
            this.lblDoluNöroloji.Location = new System.Drawing.Point(31, 0);
            this.lblDoluNöroloji.Name = "lblDoluNöroloji";
            this.lblDoluNöroloji.Size = new System.Drawing.Size(14, 15);
            this.lblDoluNöroloji.TabIndex = 114;
            this.lblDoluNöroloji.Text = "0";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label32.ForeColor = System.Drawing.Color.Red;
            this.label32.Location = new System.Drawing.Point(1, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(35, 15);
            this.label32.TabIndex = 113;
            this.label32.Text = "Dolu:";
            // 
            // panel9
            // 
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.lblBosPsikiyatri);
            this.panel9.Controls.Add(this.label34);
            this.panel9.Location = new System.Drawing.Point(843, 373);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(50, 19);
            this.panel9.TabIndex = 119;
            // 
            // lblBosPsikiyatri
            // 
            this.lblBosPsikiyatri.AutoSize = true;
            this.lblBosPsikiyatri.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBosPsikiyatri.ForeColor = System.Drawing.Color.Green;
            this.lblBosPsikiyatri.Location = new System.Drawing.Point(29, 0);
            this.lblBosPsikiyatri.Name = "lblBosPsikiyatri";
            this.lblBosPsikiyatri.Size = new System.Drawing.Size(21, 15);
            this.lblBosPsikiyatri.TabIndex = 114;
            this.lblBosPsikiyatri.Text = "15";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label34.ForeColor = System.Drawing.Color.Green;
            this.label34.Location = new System.Drawing.Point(1, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(32, 15);
            this.label34.TabIndex = 113;
            this.label34.Text = "Boş:";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.MistyRose;
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.lblDoluPsikiyatri);
            this.panel10.Controls.Add(this.label36);
            this.panel10.Location = new System.Drawing.Point(897, 373);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(52, 19);
            this.panel10.TabIndex = 118;
            // 
            // lblDoluPsikiyatri
            // 
            this.lblDoluPsikiyatri.AutoSize = true;
            this.lblDoluPsikiyatri.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblDoluPsikiyatri.ForeColor = System.Drawing.Color.Red;
            this.lblDoluPsikiyatri.Location = new System.Drawing.Point(31, 0);
            this.lblDoluPsikiyatri.Name = "lblDoluPsikiyatri";
            this.lblDoluPsikiyatri.Size = new System.Drawing.Size(14, 15);
            this.lblDoluPsikiyatri.TabIndex = 114;
            this.lblDoluPsikiyatri.Text = "0";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label36.ForeColor = System.Drawing.Color.Red;
            this.label36.Location = new System.Drawing.Point(1, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(35, 15);
            this.label36.TabIndex = 113;
            this.label36.Text = "Dolu:";
            // 
            // panel11
            // 
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel11.Controls.Add(this.lblBosİcHastaliklari);
            this.panel11.Controls.Add(this.label38);
            this.panel11.Location = new System.Drawing.Point(392, 429);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(50, 19);
            this.panel11.TabIndex = 121;
            // 
            // lblBosİcHastaliklari
            // 
            this.lblBosİcHastaliklari.AutoSize = true;
            this.lblBosİcHastaliklari.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBosİcHastaliklari.ForeColor = System.Drawing.Color.Green;
            this.lblBosİcHastaliklari.Location = new System.Drawing.Point(29, 0);
            this.lblBosİcHastaliklari.Name = "lblBosİcHastaliklari";
            this.lblBosİcHastaliklari.Size = new System.Drawing.Size(21, 15);
            this.lblBosİcHastaliklari.TabIndex = 114;
            this.lblBosİcHastaliklari.Text = "15";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label38.ForeColor = System.Drawing.Color.Green;
            this.label38.Location = new System.Drawing.Point(1, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(32, 15);
            this.label38.TabIndex = 113;
            this.label38.Text = "Boş:";
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.MistyRose;
            this.panel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel12.Controls.Add(this.lblDoluİcHastaliklari);
            this.panel12.Controls.Add(this.label40);
            this.panel12.Location = new System.Drawing.Point(446, 429);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(52, 19);
            this.panel12.TabIndex = 120;
            // 
            // lblDoluİcHastaliklari
            // 
            this.lblDoluİcHastaliklari.AutoSize = true;
            this.lblDoluİcHastaliklari.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblDoluİcHastaliklari.ForeColor = System.Drawing.Color.Red;
            this.lblDoluİcHastaliklari.Location = new System.Drawing.Point(31, 0);
            this.lblDoluİcHastaliklari.Name = "lblDoluİcHastaliklari";
            this.lblDoluİcHastaliklari.Size = new System.Drawing.Size(14, 15);
            this.lblDoluİcHastaliklari.TabIndex = 114;
            this.lblDoluİcHastaliklari.Text = "0";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label40.ForeColor = System.Drawing.Color.Red;
            this.label40.Location = new System.Drawing.Point(1, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(35, 15);
            this.label40.TabIndex = 113;
            this.label40.Text = "Dolu:";
            // 
            // panel13
            // 
            this.panel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel13.Controls.Add(this.lblBosGözHastalıkları);
            this.panel13.Controls.Add(this.label42);
            this.panel13.Location = new System.Drawing.Point(537, 429);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(50, 19);
            this.panel13.TabIndex = 123;
            // 
            // lblBosGözHastalıkları
            // 
            this.lblBosGözHastalıkları.AutoSize = true;
            this.lblBosGözHastalıkları.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBosGözHastalıkları.ForeColor = System.Drawing.Color.Green;
            this.lblBosGözHastalıkları.Location = new System.Drawing.Point(29, 0);
            this.lblBosGözHastalıkları.Name = "lblBosGözHastalıkları";
            this.lblBosGözHastalıkları.Size = new System.Drawing.Size(21, 15);
            this.lblBosGözHastalıkları.TabIndex = 114;
            this.lblBosGözHastalıkları.Text = "15";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label42.ForeColor = System.Drawing.Color.Green;
            this.label42.Location = new System.Drawing.Point(1, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(32, 15);
            this.label42.TabIndex = 113;
            this.label42.Text = "Boş:";
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.MistyRose;
            this.panel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel14.Controls.Add(this.lblDoluGözHastalıkları);
            this.panel14.Controls.Add(this.label44);
            this.panel14.Location = new System.Drawing.Point(591, 429);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(52, 19);
            this.panel14.TabIndex = 122;
            // 
            // lblDoluGözHastalıkları
            // 
            this.lblDoluGözHastalıkları.AutoSize = true;
            this.lblDoluGözHastalıkları.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblDoluGözHastalıkları.ForeColor = System.Drawing.Color.Red;
            this.lblDoluGözHastalıkları.Location = new System.Drawing.Point(31, 0);
            this.lblDoluGözHastalıkları.Name = "lblDoluGözHastalıkları";
            this.lblDoluGözHastalıkları.Size = new System.Drawing.Size(14, 15);
            this.lblDoluGözHastalıkları.TabIndex = 114;
            this.lblDoluGözHastalıkları.Text = "0";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label44.ForeColor = System.Drawing.Color.Red;
            this.label44.Location = new System.Drawing.Point(1, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(35, 15);
            this.label44.TabIndex = 113;
            this.label44.Text = "Dolu:";
            // 
            // panel15
            // 
            this.panel15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel15.Controls.Add(this.lblBosKulakBurunBogazHastaliklari);
            this.panel15.Controls.Add(this.label46);
            this.panel15.Location = new System.Drawing.Point(688, 440);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(50, 19);
            this.panel15.TabIndex = 125;
            // 
            // lblBosKulakBurunBogazHastaliklari
            // 
            this.lblBosKulakBurunBogazHastaliklari.AutoSize = true;
            this.lblBosKulakBurunBogazHastaliklari.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBosKulakBurunBogazHastaliklari.ForeColor = System.Drawing.Color.Green;
            this.lblBosKulakBurunBogazHastaliklari.Location = new System.Drawing.Point(29, 0);
            this.lblBosKulakBurunBogazHastaliklari.Name = "lblBosKulakBurunBogazHastaliklari";
            this.lblBosKulakBurunBogazHastaliklari.Size = new System.Drawing.Size(21, 15);
            this.lblBosKulakBurunBogazHastaliklari.TabIndex = 114;
            this.lblBosKulakBurunBogazHastaliklari.Text = "15";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label46.ForeColor = System.Drawing.Color.Green;
            this.label46.Location = new System.Drawing.Point(1, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(32, 15);
            this.label46.TabIndex = 113;
            this.label46.Text = "Boş:";
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.MistyRose;
            this.panel16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel16.Controls.Add(this.lblDoluKulakBurunBogazHastaliklari);
            this.panel16.Controls.Add(this.label48);
            this.panel16.Location = new System.Drawing.Point(742, 440);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(52, 19);
            this.panel16.TabIndex = 124;
            // 
            // lblDoluKulakBurunBogazHastaliklari
            // 
            this.lblDoluKulakBurunBogazHastaliklari.AutoSize = true;
            this.lblDoluKulakBurunBogazHastaliklari.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblDoluKulakBurunBogazHastaliklari.ForeColor = System.Drawing.Color.Red;
            this.lblDoluKulakBurunBogazHastaliklari.Location = new System.Drawing.Point(31, 0);
            this.lblDoluKulakBurunBogazHastaliklari.Name = "lblDoluKulakBurunBogazHastaliklari";
            this.lblDoluKulakBurunBogazHastaliklari.Size = new System.Drawing.Size(14, 15);
            this.lblDoluKulakBurunBogazHastaliklari.TabIndex = 114;
            this.lblDoluKulakBurunBogazHastaliklari.Text = "0";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label48.ForeColor = System.Drawing.Color.Red;
            this.label48.Location = new System.Drawing.Point(1, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(35, 15);
            this.label48.TabIndex = 113;
            this.label48.Text = "Dolu:";
            // 
            // panel17
            // 
            this.panel17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel17.Controls.Add(this.lblBosGögüsHastaliklari);
            this.panel17.Controls.Add(this.label50);
            this.panel17.Location = new System.Drawing.Point(842, 430);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(50, 19);
            this.panel17.TabIndex = 127;
            // 
            // lblBosGögüsHastaliklari
            // 
            this.lblBosGögüsHastaliklari.AutoSize = true;
            this.lblBosGögüsHastaliklari.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBosGögüsHastaliklari.ForeColor = System.Drawing.Color.Green;
            this.lblBosGögüsHastaliklari.Location = new System.Drawing.Point(29, 0);
            this.lblBosGögüsHastaliklari.Name = "lblBosGögüsHastaliklari";
            this.lblBosGögüsHastaliklari.Size = new System.Drawing.Size(21, 15);
            this.lblBosGögüsHastaliklari.TabIndex = 114;
            this.lblBosGögüsHastaliklari.Text = "15";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label50.ForeColor = System.Drawing.Color.Green;
            this.label50.Location = new System.Drawing.Point(1, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(32, 15);
            this.label50.TabIndex = 113;
            this.label50.Text = "Boş:";
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.MistyRose;
            this.panel18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel18.Controls.Add(this.lblDoluGögüsHastaliklari);
            this.panel18.Controls.Add(this.label52);
            this.panel18.Location = new System.Drawing.Point(896, 430);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(52, 19);
            this.panel18.TabIndex = 126;
            // 
            // lblDoluGögüsHastaliklari
            // 
            this.lblDoluGögüsHastaliklari.AutoSize = true;
            this.lblDoluGögüsHastaliklari.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblDoluGögüsHastaliklari.ForeColor = System.Drawing.Color.Red;
            this.lblDoluGögüsHastaliklari.Location = new System.Drawing.Point(31, 0);
            this.lblDoluGögüsHastaliklari.Name = "lblDoluGögüsHastaliklari";
            this.lblDoluGögüsHastaliklari.Size = new System.Drawing.Size(14, 15);
            this.lblDoluGögüsHastaliklari.TabIndex = 114;
            this.lblDoluGögüsHastaliklari.Text = "0";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label52.ForeColor = System.Drawing.Color.Red;
            this.label52.Location = new System.Drawing.Point(1, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(35, 15);
            this.label52.TabIndex = 113;
            this.label52.Text = "Dolu:";
            // 
            // panel19
            // 
            this.panel19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel19.Controls.Add(this.lblBosKalpveDamarCerrahisi);
            this.panel19.Controls.Add(this.label54);
            this.panel19.Location = new System.Drawing.Point(392, 507);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(50, 19);
            this.panel19.TabIndex = 129;
            // 
            // lblBosKalpveDamarCerrahisi
            // 
            this.lblBosKalpveDamarCerrahisi.AutoSize = true;
            this.lblBosKalpveDamarCerrahisi.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBosKalpveDamarCerrahisi.ForeColor = System.Drawing.Color.Green;
            this.lblBosKalpveDamarCerrahisi.Location = new System.Drawing.Point(29, 0);
            this.lblBosKalpveDamarCerrahisi.Name = "lblBosKalpveDamarCerrahisi";
            this.lblBosKalpveDamarCerrahisi.Size = new System.Drawing.Size(21, 15);
            this.lblBosKalpveDamarCerrahisi.TabIndex = 114;
            this.lblBosKalpveDamarCerrahisi.Text = "15";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label54.ForeColor = System.Drawing.Color.Green;
            this.label54.Location = new System.Drawing.Point(1, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(32, 15);
            this.label54.TabIndex = 113;
            this.label54.Text = "Boş:";
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.MistyRose;
            this.panel20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel20.Controls.Add(this.lblDoluKalpveDamarCerrahisi);
            this.panel20.Controls.Add(this.label56);
            this.panel20.Location = new System.Drawing.Point(446, 507);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(52, 19);
            this.panel20.TabIndex = 128;
            // 
            // lblDoluKalpveDamarCerrahisi
            // 
            this.lblDoluKalpveDamarCerrahisi.AutoSize = true;
            this.lblDoluKalpveDamarCerrahisi.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblDoluKalpveDamarCerrahisi.ForeColor = System.Drawing.Color.Red;
            this.lblDoluKalpveDamarCerrahisi.Location = new System.Drawing.Point(31, 0);
            this.lblDoluKalpveDamarCerrahisi.Name = "lblDoluKalpveDamarCerrahisi";
            this.lblDoluKalpveDamarCerrahisi.Size = new System.Drawing.Size(14, 15);
            this.lblDoluKalpveDamarCerrahisi.TabIndex = 114;
            this.lblDoluKalpveDamarCerrahisi.Text = "0";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label56.ForeColor = System.Drawing.Color.Red;
            this.label56.Location = new System.Drawing.Point(1, 0);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(35, 15);
            this.label56.TabIndex = 113;
            this.label56.Text = "Dolu:";
            // 
            // panel21
            // 
            this.panel21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel21.Controls.Add(this.lblBosGastroenteroloji);
            this.panel21.Controls.Add(this.label58);
            this.panel21.Location = new System.Drawing.Point(537, 494);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(50, 19);
            this.panel21.TabIndex = 131;
            // 
            // lblBosGastroenteroloji
            // 
            this.lblBosGastroenteroloji.AutoSize = true;
            this.lblBosGastroenteroloji.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBosGastroenteroloji.ForeColor = System.Drawing.Color.Green;
            this.lblBosGastroenteroloji.Location = new System.Drawing.Point(29, 0);
            this.lblBosGastroenteroloji.Name = "lblBosGastroenteroloji";
            this.lblBosGastroenteroloji.Size = new System.Drawing.Size(21, 15);
            this.lblBosGastroenteroloji.TabIndex = 114;
            this.lblBosGastroenteroloji.Text = "15";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label58.ForeColor = System.Drawing.Color.Green;
            this.label58.Location = new System.Drawing.Point(1, 0);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(32, 15);
            this.label58.TabIndex = 113;
            this.label58.Text = "Boş:";
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.Color.MistyRose;
            this.panel22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel22.Controls.Add(this.lblDoluGastroenteroloji);
            this.panel22.Controls.Add(this.label60);
            this.panel22.Location = new System.Drawing.Point(591, 494);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(52, 19);
            this.panel22.TabIndex = 130;
            // 
            // lblDoluGastroenteroloji
            // 
            this.lblDoluGastroenteroloji.AutoSize = true;
            this.lblDoluGastroenteroloji.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblDoluGastroenteroloji.ForeColor = System.Drawing.Color.Red;
            this.lblDoluGastroenteroloji.Location = new System.Drawing.Point(31, 0);
            this.lblDoluGastroenteroloji.Name = "lblDoluGastroenteroloji";
            this.lblDoluGastroenteroloji.Size = new System.Drawing.Size(14, 15);
            this.lblDoluGastroenteroloji.TabIndex = 114;
            this.lblDoluGastroenteroloji.Text = "0";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label60.ForeColor = System.Drawing.Color.Red;
            this.label60.Location = new System.Drawing.Point(1, 0);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(35, 15);
            this.label60.TabIndex = 113;
            this.label60.Text = "Dolu:";
            // 
            // panel23
            // 
            this.panel23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel23.Controls.Add(this.lblBosPlastikveEstetikCerrahisi);
            this.panel23.Controls.Add(this.label62);
            this.panel23.Location = new System.Drawing.Point(688, 507);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(50, 19);
            this.panel23.TabIndex = 133;
            // 
            // lblBosPlastikveEstetikCerrahisi
            // 
            this.lblBosPlastikveEstetikCerrahisi.AutoSize = true;
            this.lblBosPlastikveEstetikCerrahisi.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBosPlastikveEstetikCerrahisi.ForeColor = System.Drawing.Color.Green;
            this.lblBosPlastikveEstetikCerrahisi.Location = new System.Drawing.Point(29, 0);
            this.lblBosPlastikveEstetikCerrahisi.Name = "lblBosPlastikveEstetikCerrahisi";
            this.lblBosPlastikveEstetikCerrahisi.Size = new System.Drawing.Size(21, 15);
            this.lblBosPlastikveEstetikCerrahisi.TabIndex = 114;
            this.lblBosPlastikveEstetikCerrahisi.Text = "15";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label62.ForeColor = System.Drawing.Color.Green;
            this.label62.Location = new System.Drawing.Point(1, 0);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(32, 15);
            this.label62.TabIndex = 113;
            this.label62.Text = "Boş:";
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.Color.MistyRose;
            this.panel24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel24.Controls.Add(this.lblDoluPlastikveEstetikCerrahisi);
            this.panel24.Controls.Add(this.label64);
            this.panel24.Location = new System.Drawing.Point(742, 507);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(52, 19);
            this.panel24.TabIndex = 132;
            // 
            // lblDoluPlastikveEstetikCerrahisi
            // 
            this.lblDoluPlastikveEstetikCerrahisi.AutoSize = true;
            this.lblDoluPlastikveEstetikCerrahisi.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblDoluPlastikveEstetikCerrahisi.ForeColor = System.Drawing.Color.Red;
            this.lblDoluPlastikveEstetikCerrahisi.Location = new System.Drawing.Point(31, 0);
            this.lblDoluPlastikveEstetikCerrahisi.Name = "lblDoluPlastikveEstetikCerrahisi";
            this.lblDoluPlastikveEstetikCerrahisi.Size = new System.Drawing.Size(14, 15);
            this.lblDoluPlastikveEstetikCerrahisi.TabIndex = 114;
            this.lblDoluPlastikveEstetikCerrahisi.Text = "0";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label64.ForeColor = System.Drawing.Color.Red;
            this.label64.Location = new System.Drawing.Point(1, 0);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(35, 15);
            this.label64.TabIndex = 113;
            this.label64.Text = "Dolu:";
            // 
            // panel25
            // 
            this.panel25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel25.Controls.Add(this.lblBosKadınHastaliklariveDogum);
            this.panel25.Controls.Add(this.label66);
            this.panel25.Location = new System.Drawing.Point(842, 507);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(50, 19);
            this.panel25.TabIndex = 135;
            // 
            // lblBosKadınHastaliklariveDogum
            // 
            this.lblBosKadınHastaliklariveDogum.AutoSize = true;
            this.lblBosKadınHastaliklariveDogum.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBosKadınHastaliklariveDogum.ForeColor = System.Drawing.Color.Green;
            this.lblBosKadınHastaliklariveDogum.Location = new System.Drawing.Point(29, 0);
            this.lblBosKadınHastaliklariveDogum.Name = "lblBosKadınHastaliklariveDogum";
            this.lblBosKadınHastaliklariveDogum.Size = new System.Drawing.Size(21, 15);
            this.lblBosKadınHastaliklariveDogum.TabIndex = 114;
            this.lblBosKadınHastaliklariveDogum.Text = "15";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label66.ForeColor = System.Drawing.Color.Green;
            this.label66.Location = new System.Drawing.Point(1, 0);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(32, 15);
            this.label66.TabIndex = 113;
            this.label66.Text = "Boş:";
            // 
            // panel26
            // 
            this.panel26.BackColor = System.Drawing.Color.MistyRose;
            this.panel26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel26.Controls.Add(this.lblDoluKadınHastaliklariveDogum);
            this.panel26.Controls.Add(this.label68);
            this.panel26.Location = new System.Drawing.Point(896, 507);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(52, 19);
            this.panel26.TabIndex = 134;
            // 
            // lblDoluKadınHastaliklariveDogum
            // 
            this.lblDoluKadınHastaliklariveDogum.AutoSize = true;
            this.lblDoluKadınHastaliklariveDogum.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblDoluKadınHastaliklariveDogum.ForeColor = System.Drawing.Color.Red;
            this.lblDoluKadınHastaliklariveDogum.Location = new System.Drawing.Point(31, 0);
            this.lblDoluKadınHastaliklariveDogum.Name = "lblDoluKadınHastaliklariveDogum";
            this.lblDoluKadınHastaliklariveDogum.Size = new System.Drawing.Size(14, 15);
            this.lblDoluKadınHastaliklariveDogum.TabIndex = 114;
            this.lblDoluKadınHastaliklariveDogum.Text = "0";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label68.ForeColor = System.Drawing.Color.Red;
            this.label68.Location = new System.Drawing.Point(1, 0);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(35, 15);
            this.label68.TabIndex = 113;
            this.label68.Text = "Dolu:";
            // 
            // panel27
            // 
            this.panel27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel27.Controls.Add(this.lblBosEndokronolojiveMetabolizma);
            this.panel27.Controls.Add(this.label70);
            this.panel27.Location = new System.Drawing.Point(392, 574);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(50, 19);
            this.panel27.TabIndex = 137;
            // 
            // lblBosEndokronolojiveMetabolizma
            // 
            this.lblBosEndokronolojiveMetabolizma.AutoSize = true;
            this.lblBosEndokronolojiveMetabolizma.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBosEndokronolojiveMetabolizma.ForeColor = System.Drawing.Color.Green;
            this.lblBosEndokronolojiveMetabolizma.Location = new System.Drawing.Point(29, 0);
            this.lblBosEndokronolojiveMetabolizma.Name = "lblBosEndokronolojiveMetabolizma";
            this.lblBosEndokronolojiveMetabolizma.Size = new System.Drawing.Size(21, 15);
            this.lblBosEndokronolojiveMetabolizma.TabIndex = 114;
            this.lblBosEndokronolojiveMetabolizma.Text = "15";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label70.ForeColor = System.Drawing.Color.Green;
            this.label70.Location = new System.Drawing.Point(1, 0);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(32, 15);
            this.label70.TabIndex = 113;
            this.label70.Text = "Boş:";
            // 
            // panel28
            // 
            this.panel28.BackColor = System.Drawing.Color.MistyRose;
            this.panel28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel28.Controls.Add(this.lblDoluEndokronolojiveMetabolizma);
            this.panel28.Controls.Add(this.label72);
            this.panel28.Location = new System.Drawing.Point(446, 574);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(52, 19);
            this.panel28.TabIndex = 136;
            // 
            // lblDoluEndokronolojiveMetabolizma
            // 
            this.lblDoluEndokronolojiveMetabolizma.AutoSize = true;
            this.lblDoluEndokronolojiveMetabolizma.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblDoluEndokronolojiveMetabolizma.ForeColor = System.Drawing.Color.Red;
            this.lblDoluEndokronolojiveMetabolizma.Location = new System.Drawing.Point(31, 0);
            this.lblDoluEndokronolojiveMetabolizma.Name = "lblDoluEndokronolojiveMetabolizma";
            this.lblDoluEndokronolojiveMetabolizma.Size = new System.Drawing.Size(14, 15);
            this.lblDoluEndokronolojiveMetabolizma.TabIndex = 114;
            this.lblDoluEndokronolojiveMetabolizma.Text = "0";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label72.ForeColor = System.Drawing.Color.Red;
            this.label72.Location = new System.Drawing.Point(1, 0);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(35, 15);
            this.label72.TabIndex = 113;
            this.label72.Text = "Dolu:";
            // 
            // panel29
            // 
            this.panel29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel29.Controls.Add(this.lblBosDermatoloji);
            this.panel29.Controls.Add(this.label74);
            this.panel29.Location = new System.Drawing.Point(537, 563);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(50, 19);
            this.panel29.TabIndex = 139;
            // 
            // lblBosDermatoloji
            // 
            this.lblBosDermatoloji.AutoSize = true;
            this.lblBosDermatoloji.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBosDermatoloji.ForeColor = System.Drawing.Color.Green;
            this.lblBosDermatoloji.Location = new System.Drawing.Point(29, 0);
            this.lblBosDermatoloji.Name = "lblBosDermatoloji";
            this.lblBosDermatoloji.Size = new System.Drawing.Size(21, 15);
            this.lblBosDermatoloji.TabIndex = 114;
            this.lblBosDermatoloji.Text = "15";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label74.ForeColor = System.Drawing.Color.Green;
            this.label74.Location = new System.Drawing.Point(1, 0);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(32, 15);
            this.label74.TabIndex = 113;
            this.label74.Text = "Boş:";
            // 
            // panel30
            // 
            this.panel30.BackColor = System.Drawing.Color.MistyRose;
            this.panel30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel30.Controls.Add(this.lblDoluDermatoloji);
            this.panel30.Controls.Add(this.label76);
            this.panel30.Location = new System.Drawing.Point(591, 563);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(52, 19);
            this.panel30.TabIndex = 138;
            // 
            // lblDoluDermatoloji
            // 
            this.lblDoluDermatoloji.AutoSize = true;
            this.lblDoluDermatoloji.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblDoluDermatoloji.ForeColor = System.Drawing.Color.Red;
            this.lblDoluDermatoloji.Location = new System.Drawing.Point(31, 0);
            this.lblDoluDermatoloji.Name = "lblDoluDermatoloji";
            this.lblDoluDermatoloji.Size = new System.Drawing.Size(14, 15);
            this.lblDoluDermatoloji.TabIndex = 114;
            this.lblDoluDermatoloji.Text = "0";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label76.ForeColor = System.Drawing.Color.Red;
            this.label76.Location = new System.Drawing.Point(1, 0);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(35, 15);
            this.label76.TabIndex = 113;
            this.label76.Text = "Dolu:";
            // 
            // panel31
            // 
            this.panel31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel31.Controls.Add(this.lblBosOrtopediveTravma);
            this.panel31.Controls.Add(this.label78);
            this.panel31.Location = new System.Drawing.Point(688, 574);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(50, 19);
            this.panel31.TabIndex = 141;
            // 
            // lblBosOrtopediveTravma
            // 
            this.lblBosOrtopediveTravma.AutoSize = true;
            this.lblBosOrtopediveTravma.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBosOrtopediveTravma.ForeColor = System.Drawing.Color.Green;
            this.lblBosOrtopediveTravma.Location = new System.Drawing.Point(29, 0);
            this.lblBosOrtopediveTravma.Name = "lblBosOrtopediveTravma";
            this.lblBosOrtopediveTravma.Size = new System.Drawing.Size(21, 15);
            this.lblBosOrtopediveTravma.TabIndex = 114;
            this.lblBosOrtopediveTravma.Text = "15";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label78.ForeColor = System.Drawing.Color.Green;
            this.label78.Location = new System.Drawing.Point(1, 0);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(32, 15);
            this.label78.TabIndex = 113;
            this.label78.Text = "Boş:";
            // 
            // panel32
            // 
            this.panel32.BackColor = System.Drawing.Color.MistyRose;
            this.panel32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel32.Controls.Add(this.lblDoluOrtopediveTravma);
            this.panel32.Controls.Add(this.label80);
            this.panel32.Location = new System.Drawing.Point(742, 574);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(52, 19);
            this.panel32.TabIndex = 140;
            // 
            // lblDoluOrtopediveTravma
            // 
            this.lblDoluOrtopediveTravma.AutoSize = true;
            this.lblDoluOrtopediveTravma.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblDoluOrtopediveTravma.ForeColor = System.Drawing.Color.Red;
            this.lblDoluOrtopediveTravma.Location = new System.Drawing.Point(31, 0);
            this.lblDoluOrtopediveTravma.Name = "lblDoluOrtopediveTravma";
            this.lblDoluOrtopediveTravma.Size = new System.Drawing.Size(14, 15);
            this.lblDoluOrtopediveTravma.TabIndex = 114;
            this.lblDoluOrtopediveTravma.Text = "0";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label80.ForeColor = System.Drawing.Color.Red;
            this.label80.Location = new System.Drawing.Point(1, 0);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(35, 15);
            this.label80.TabIndex = 113;
            this.label80.Text = "Dolu:";
            // 
            // panel33
            // 
            this.panel33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel33.Controls.Add(this.lblBosFizikselTıpveRehabilitasyon);
            this.panel33.Controls.Add(this.label82);
            this.panel33.Location = new System.Drawing.Point(842, 572);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(50, 19);
            this.panel33.TabIndex = 143;
            // 
            // lblBosFizikselTıpveRehabilitasyon
            // 
            this.lblBosFizikselTıpveRehabilitasyon.AutoSize = true;
            this.lblBosFizikselTıpveRehabilitasyon.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBosFizikselTıpveRehabilitasyon.ForeColor = System.Drawing.Color.Green;
            this.lblBosFizikselTıpveRehabilitasyon.Location = new System.Drawing.Point(29, 0);
            this.lblBosFizikselTıpveRehabilitasyon.Name = "lblBosFizikselTıpveRehabilitasyon";
            this.lblBosFizikselTıpveRehabilitasyon.Size = new System.Drawing.Size(21, 15);
            this.lblBosFizikselTıpveRehabilitasyon.TabIndex = 114;
            this.lblBosFizikselTıpveRehabilitasyon.Text = "15";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label82.ForeColor = System.Drawing.Color.Green;
            this.label82.Location = new System.Drawing.Point(1, 0);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(32, 15);
            this.label82.TabIndex = 113;
            this.label82.Text = "Boş:";
            // 
            // panel34
            // 
            this.panel34.BackColor = System.Drawing.Color.MistyRose;
            this.panel34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel34.Controls.Add(this.lblDoluFizikselTıpveRehabilitasyon);
            this.panel34.Controls.Add(this.label84);
            this.panel34.Location = new System.Drawing.Point(896, 572);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(52, 19);
            this.panel34.TabIndex = 142;
            // 
            // lblDoluFizikselTıpveRehabilitasyon
            // 
            this.lblDoluFizikselTıpveRehabilitasyon.AutoSize = true;
            this.lblDoluFizikselTıpveRehabilitasyon.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblDoluFizikselTıpveRehabilitasyon.ForeColor = System.Drawing.Color.Red;
            this.lblDoluFizikselTıpveRehabilitasyon.Location = new System.Drawing.Point(31, 0);
            this.lblDoluFizikselTıpveRehabilitasyon.Name = "lblDoluFizikselTıpveRehabilitasyon";
            this.lblDoluFizikselTıpveRehabilitasyon.Size = new System.Drawing.Size(14, 15);
            this.lblDoluFizikselTıpveRehabilitasyon.TabIndex = 114;
            this.lblDoluFizikselTıpveRehabilitasyon.Text = "0";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label84.ForeColor = System.Drawing.Color.Red;
            this.label84.Location = new System.Drawing.Point(1, 0);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(35, 15);
            this.label84.TabIndex = 113;
            this.label84.Text = "Dolu:";
            // 
            // panel35
            // 
            this.panel35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel35.Controls.Add(this.lblBosNefroloji);
            this.panel35.Controls.Add(this.label86);
            this.panel35.Location = new System.Drawing.Point(392, 632);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(50, 19);
            this.panel35.TabIndex = 145;
            // 
            // lblBosNefroloji
            // 
            this.lblBosNefroloji.AutoSize = true;
            this.lblBosNefroloji.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBosNefroloji.ForeColor = System.Drawing.Color.Green;
            this.lblBosNefroloji.Location = new System.Drawing.Point(29, 0);
            this.lblBosNefroloji.Name = "lblBosNefroloji";
            this.lblBosNefroloji.Size = new System.Drawing.Size(21, 15);
            this.lblBosNefroloji.TabIndex = 114;
            this.lblBosNefroloji.Text = "15";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label86.ForeColor = System.Drawing.Color.Green;
            this.label86.Location = new System.Drawing.Point(1, 0);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(32, 15);
            this.label86.TabIndex = 113;
            this.label86.Text = "Boş:";
            // 
            // panel36
            // 
            this.panel36.BackColor = System.Drawing.Color.MistyRose;
            this.panel36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel36.Controls.Add(this.lblDoluNefroloji);
            this.panel36.Controls.Add(this.label88);
            this.panel36.Location = new System.Drawing.Point(446, 632);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(52, 19);
            this.panel36.TabIndex = 144;
            // 
            // lblDoluNefroloji
            // 
            this.lblDoluNefroloji.AutoSize = true;
            this.lblDoluNefroloji.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblDoluNefroloji.ForeColor = System.Drawing.Color.Red;
            this.lblDoluNefroloji.Location = new System.Drawing.Point(31, 0);
            this.lblDoluNefroloji.Name = "lblDoluNefroloji";
            this.lblDoluNefroloji.Size = new System.Drawing.Size(14, 15);
            this.lblDoluNefroloji.TabIndex = 114;
            this.lblDoluNefroloji.Text = "0";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label88.ForeColor = System.Drawing.Color.Red;
            this.label88.Location = new System.Drawing.Point(1, 0);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(35, 15);
            this.label88.TabIndex = 113;
            this.label88.Text = "Dolu:";
            // 
            // panel37
            // 
            this.panel37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel37.Controls.Add(this.lblBosHematoloji);
            this.panel37.Controls.Add(this.label90);
            this.panel37.Location = new System.Drawing.Point(538, 632);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(50, 19);
            this.panel37.TabIndex = 147;
            // 
            // lblBosHematoloji
            // 
            this.lblBosHematoloji.AutoSize = true;
            this.lblBosHematoloji.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBosHematoloji.ForeColor = System.Drawing.Color.Green;
            this.lblBosHematoloji.Location = new System.Drawing.Point(29, 0);
            this.lblBosHematoloji.Name = "lblBosHematoloji";
            this.lblBosHematoloji.Size = new System.Drawing.Size(21, 15);
            this.lblBosHematoloji.TabIndex = 114;
            this.lblBosHematoloji.Text = "15";
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label90.ForeColor = System.Drawing.Color.Green;
            this.label90.Location = new System.Drawing.Point(1, 0);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(32, 15);
            this.label90.TabIndex = 113;
            this.label90.Text = "Boş:";
            // 
            // panel38
            // 
            this.panel38.BackColor = System.Drawing.Color.MistyRose;
            this.panel38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel38.Controls.Add(this.lblDoluHematoloji);
            this.panel38.Controls.Add(this.label92);
            this.panel38.Location = new System.Drawing.Point(592, 632);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(52, 19);
            this.panel38.TabIndex = 146;
            // 
            // lblDoluHematoloji
            // 
            this.lblDoluHematoloji.AutoSize = true;
            this.lblDoluHematoloji.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblDoluHematoloji.ForeColor = System.Drawing.Color.Red;
            this.lblDoluHematoloji.Location = new System.Drawing.Point(31, 0);
            this.lblDoluHematoloji.Name = "lblDoluHematoloji";
            this.lblDoluHematoloji.Size = new System.Drawing.Size(14, 15);
            this.lblDoluHematoloji.TabIndex = 114;
            this.lblDoluHematoloji.Text = "0";
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label92.ForeColor = System.Drawing.Color.Red;
            this.label92.Location = new System.Drawing.Point(1, 0);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(35, 15);
            this.label92.TabIndex = 113;
            this.label92.Text = "Dolu:";
            // 
            // panel39
            // 
            this.panel39.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel39.Controls.Add(this.lblBosRomatoloji);
            this.panel39.Controls.Add(this.label94);
            this.panel39.Location = new System.Drawing.Point(688, 633);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(50, 19);
            this.panel39.TabIndex = 149;
            // 
            // lblBosRomatoloji
            // 
            this.lblBosRomatoloji.AutoSize = true;
            this.lblBosRomatoloji.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBosRomatoloji.ForeColor = System.Drawing.Color.Green;
            this.lblBosRomatoloji.Location = new System.Drawing.Point(29, 0);
            this.lblBosRomatoloji.Name = "lblBosRomatoloji";
            this.lblBosRomatoloji.Size = new System.Drawing.Size(21, 15);
            this.lblBosRomatoloji.TabIndex = 114;
            this.lblBosRomatoloji.Text = "15";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label94.ForeColor = System.Drawing.Color.Green;
            this.label94.Location = new System.Drawing.Point(1, 0);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(32, 15);
            this.label94.TabIndex = 113;
            this.label94.Text = "Boş:";
            // 
            // panel40
            // 
            this.panel40.BackColor = System.Drawing.Color.MistyRose;
            this.panel40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel40.Controls.Add(this.lblDoluRomatoloji);
            this.panel40.Controls.Add(this.label96);
            this.panel40.Location = new System.Drawing.Point(742, 633);
            this.panel40.Name = "panel40";
            this.panel40.Size = new System.Drawing.Size(52, 19);
            this.panel40.TabIndex = 148;
            // 
            // lblDoluRomatoloji
            // 
            this.lblDoluRomatoloji.AutoSize = true;
            this.lblDoluRomatoloji.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblDoluRomatoloji.ForeColor = System.Drawing.Color.Red;
            this.lblDoluRomatoloji.Location = new System.Drawing.Point(31, 0);
            this.lblDoluRomatoloji.Name = "lblDoluRomatoloji";
            this.lblDoluRomatoloji.Size = new System.Drawing.Size(14, 15);
            this.lblDoluRomatoloji.TabIndex = 114;
            this.lblDoluRomatoloji.Text = "0";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label96.ForeColor = System.Drawing.Color.Red;
            this.label96.Location = new System.Drawing.Point(1, 0);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(35, 15);
            this.label96.TabIndex = 113;
            this.label96.Text = "Dolu:";
            // 
            // panel41
            // 
            this.panel41.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel41.Controls.Add(this.lblBosÜroloji);
            this.panel41.Controls.Add(this.label98);
            this.panel41.Location = new System.Drawing.Point(844, 632);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(50, 19);
            this.panel41.TabIndex = 151;
            // 
            // lblBosÜroloji
            // 
            this.lblBosÜroloji.AutoSize = true;
            this.lblBosÜroloji.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBosÜroloji.ForeColor = System.Drawing.Color.Green;
            this.lblBosÜroloji.Location = new System.Drawing.Point(29, 0);
            this.lblBosÜroloji.Name = "lblBosÜroloji";
            this.lblBosÜroloji.Size = new System.Drawing.Size(21, 15);
            this.lblBosÜroloji.TabIndex = 114;
            this.lblBosÜroloji.Text = "15";
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label98.ForeColor = System.Drawing.Color.Green;
            this.label98.Location = new System.Drawing.Point(1, 0);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(32, 15);
            this.label98.TabIndex = 113;
            this.label98.Text = "Boş:";
            // 
            // panel42
            // 
            this.panel42.BackColor = System.Drawing.Color.MistyRose;
            this.panel42.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel42.Controls.Add(this.lblDoluÜroloji);
            this.panel42.Controls.Add(this.label100);
            this.panel42.Location = new System.Drawing.Point(898, 632);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(52, 19);
            this.panel42.TabIndex = 150;
            // 
            // lblDoluÜroloji
            // 
            this.lblDoluÜroloji.AutoSize = true;
            this.lblDoluÜroloji.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblDoluÜroloji.ForeColor = System.Drawing.Color.Red;
            this.lblDoluÜroloji.Location = new System.Drawing.Point(31, 0);
            this.lblDoluÜroloji.Name = "lblDoluÜroloji";
            this.lblDoluÜroloji.Size = new System.Drawing.Size(14, 15);
            this.lblDoluÜroloji.TabIndex = 114;
            this.lblDoluÜroloji.Text = "0";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label100.ForeColor = System.Drawing.Color.Red;
            this.label100.Location = new System.Drawing.Point(1, 0);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(35, 15);
            this.label100.TabIndex = 113;
            this.label100.Text = "Dolu:";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1015, 670);
            this.Controls.Add(this.panel41);
            this.Controls.Add(this.panel42);
            this.Controls.Add(this.panel39);
            this.Controls.Add(this.panel40);
            this.Controls.Add(this.panel37);
            this.Controls.Add(this.panel38);
            this.Controls.Add(this.panel35);
            this.Controls.Add(this.panel36);
            this.Controls.Add(this.panel33);
            this.Controls.Add(this.panel34);
            this.Controls.Add(this.panel31);
            this.Controls.Add(this.panel32);
            this.Controls.Add(this.panel29);
            this.Controls.Add(this.panel30);
            this.Controls.Add(this.panel27);
            this.Controls.Add(this.panel28);
            this.Controls.Add(this.panel25);
            this.Controls.Add(this.panel26);
            this.Controls.Add(this.panel23);
            this.Controls.Add(this.panel24);
            this.Controls.Add(this.panel21);
            this.Controls.Add(this.panel22);
            this.Controls.Add(this.panel19);
            this.Controls.Add(this.panel20);
            this.Controls.Add(this.panel17);
            this.Controls.Add(this.panel18);
            this.Controls.Add(this.panel15);
            this.Controls.Add(this.panel16);
            this.Controls.Add(this.panel13);
            this.Controls.Add(this.panel14);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.panel12);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.lblÜroloji);
            this.Controls.Add(this.lblRomatoloji);
            this.Controls.Add(this.lblNefroloji);
            this.Controls.Add(this.lblHematoloji);
            this.Controls.Add(this.lblFizikselTıpveRehabilitasyon);
            this.Controls.Add(this.lblOrtopediveTravma);
            this.Controls.Add(this.lblDermatoloji);
            this.Controls.Add(this.lblEndokronolojiveMetabolizma);
            this.Controls.Add(this.lblKadınHastaliklariveDogum);
            this.Controls.Add(this.lblPlastikveEstetikCerrahisi);
            this.Controls.Add(this.lblGastroenteroloji);
            this.Controls.Add(this.lblKalpveDamarCerrahisi);
            this.Controls.Add(this.lblGögüsHastaliklari);
            this.Controls.Add(this.lblKulakBurunBogazHastaliklari);
            this.Controls.Add(this.lblGözHastaliklari);
            this.Controls.Add(this.lblİcHastaliklari);
            this.Controls.Add(this.lblPsikiyatri);
            this.Controls.Add(this.lblNöroloji);
            this.Controls.Add(this.lblKardiyoloji);
            this.Controls.Add(this.lblBeyinveSinirCerrahisi);
            this.Controls.Add(this.picBoxÜroloji);
            this.Controls.Add(this.picBoxRomatoloji);
            this.Controls.Add(this.picBoxHematoloji);
            this.Controls.Add(this.picBoxNefroloji);
            this.Controls.Add(this.picBoxBeyinveSinirCerrahisi);
            this.Controls.Add(this.picBoxFizikselTıpveRehabilitasyon);
            this.Controls.Add(this.picBoxKardiyoloji);
            this.Controls.Add(this.picBoxOrtopediveTravma);
            this.Controls.Add(this.picBoxNöroloji);
            this.Controls.Add(this.picBoxDermatoloji);
            this.Controls.Add(this.picBoxPsikiyatri);
            this.Controls.Add(this.picBoxEndokronolojiveMetabolizma);
            this.Controls.Add(this.picBoxİcHastalıkları);
            this.Controls.Add(this.picBoxKadınHastalıklarıveDogum);
            this.Controls.Add(this.picBoxGözHastalıkları);
            this.Controls.Add(this.picBoxPlastikveEstetikCerrahisi);
            this.Controls.Add(this.picBoxKulakBurunBoğazHastalıkları);
            this.Controls.Add(this.picBoxGastroenteroloji);
            this.Controls.Add(this.picBoxGögüsHastalıkları);
            this.Controls.Add(this.picBoxKalpveDamarCerrahisi);
            this.Controls.Add(this.lblTarihveSonrasiniAciklama2);
            this.Controls.Add(this.btnRandevularım);
            this.Controls.Add(this.btnCikis);
            this.Controls.Add(this.lblHosgeldinizAciklama);
            this.Controls.Add(this.lblTarihveSonrasiniAciklama1);
            this.Controls.Add(this.lblTarih2);
            this.Controls.Add(this.lblTarih1);
            this.Controls.Add(this.llblTarihAciklama);
            this.Controls.Add(this.picBoxTarihAciklama);
            this.Controls.Add(this.picBoxBransListesi);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form3_FormClosed);
            this.Load += new System.EventHandler(this.Form3_Load);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picBoxBransListesi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxTarihAciklama)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxKardiyoloji)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxNöroloji)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxGögüsHastalıkları)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxKulakBurunBoğazHastalıkları)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxGözHastalıkları)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxİcHastalıkları)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxKalpveDamarCerrahisi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxGastroenteroloji)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxPlastikveEstetikCerrahisi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxKadınHastalıklarıveDogum)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxEndokronolojiveMetabolizma)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxDermatoloji)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxOrtopediveTravma)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxFizikselTıpveRehabilitasyon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxÜroloji)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxRomatoloji)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxHematoloji)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxNefroloji)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxPsikiyatri)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxBeyinveSinirCerrahisi)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.panel25.ResumeLayout(false);
            this.panel25.PerformLayout();
            this.panel26.ResumeLayout(false);
            this.panel26.PerformLayout();
            this.panel27.ResumeLayout(false);
            this.panel27.PerformLayout();
            this.panel28.ResumeLayout(false);
            this.panel28.PerformLayout();
            this.panel29.ResumeLayout(false);
            this.panel29.PerformLayout();
            this.panel30.ResumeLayout(false);
            this.panel30.PerformLayout();
            this.panel31.ResumeLayout(false);
            this.panel31.PerformLayout();
            this.panel32.ResumeLayout(false);
            this.panel32.PerformLayout();
            this.panel33.ResumeLayout(false);
            this.panel33.PerformLayout();
            this.panel34.ResumeLayout(false);
            this.panel34.PerformLayout();
            this.panel35.ResumeLayout(false);
            this.panel35.PerformLayout();
            this.panel36.ResumeLayout(false);
            this.panel36.PerformLayout();
            this.panel37.ResumeLayout(false);
            this.panel37.PerformLayout();
            this.panel38.ResumeLayout(false);
            this.panel38.PerformLayout();
            this.panel39.ResumeLayout(false);
            this.panel39.PerformLayout();
            this.panel40.ResumeLayout(false);
            this.panel40.PerformLayout();
            this.panel41.ResumeLayout(false);
            this.panel41.PerformLayout();
            this.panel42.ResumeLayout(false);
            this.panel42.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Panel panel2;
        public System.Windows.Forms.MonthCalendar monthCalendar_randevuTarihleri;
        public System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.PictureBox picBoxBransListesi;
        public System.Windows.Forms.PictureBox picBoxTarihAciklama;
        public System.Windows.Forms.Label llblTarihAciklama;
        public System.Windows.Forms.Label lblTarih1;
        public System.Windows.Forms.Label lblTarih2;
        public System.Windows.Forms.Label lblTarihveSonrasiniAciklama1;
        public System.Windows.Forms.Button btnRandevularım;
        public System.Windows.Forms.Button btnCikis;
        public System.Windows.Forms.Label lblHosgeldinizAciklama;
        public System.Windows.Forms.Label lblTarihveSonrasiniAciklama2;
        public System.Windows.Forms.Label lblBeyinveSinirCerrahisi;
        public System.Windows.Forms.Label lblKardiyoloji;
        public System.Windows.Forms.Label lblNöroloji;
        public System.Windows.Forms.Label lblPsikiyatri;
        public System.Windows.Forms.Label lblİcHastaliklari;
        public System.Windows.Forms.Label lblGözHastaliklari;
        public System.Windows.Forms.Label lblKulakBurunBogazHastaliklari;
        public System.Windows.Forms.Label lblGögüsHastaliklari;
        public System.Windows.Forms.Label lblKalpveDamarCerrahisi;
        public System.Windows.Forms.Label lblGastroenteroloji;
        public System.Windows.Forms.Label lblPlastikveEstetikCerrahisi;
        public System.Windows.Forms.Label lblKadınHastaliklariveDogum;
        public System.Windows.Forms.Label lblEndokronolojiveMetabolizma;
        public System.Windows.Forms.Label lblDermatoloji;
        public System.Windows.Forms.Label lblOrtopediveTravma;
        public System.Windows.Forms.Label lblFizikselTıpveRehabilitasyon;
        public System.Windows.Forms.Label lblHematoloji;
        public System.Windows.Forms.Label lblNefroloji;
        public System.Windows.Forms.Label lblRomatoloji;
        public System.Windows.Forms.Label lblÜroloji;
        public System.Windows.Forms.PictureBox picBoxKardiyoloji;
        public System.Windows.Forms.PictureBox picBoxNöroloji;
        public System.Windows.Forms.PictureBox picBoxGögüsHastalıkları;
        public System.Windows.Forms.PictureBox picBoxKulakBurunBoğazHastalıkları;
        public System.Windows.Forms.PictureBox picBoxGözHastalıkları;
        public System.Windows.Forms.PictureBox picBoxİcHastalıkları;
        public System.Windows.Forms.PictureBox picBoxKalpveDamarCerrahisi;
        public System.Windows.Forms.PictureBox picBoxGastroenteroloji;
        public System.Windows.Forms.PictureBox picBoxPlastikveEstetikCerrahisi;
        public System.Windows.Forms.PictureBox picBoxKadınHastalıklarıveDogum;
        public System.Windows.Forms.PictureBox picBoxEndokronolojiveMetabolizma;
        public System.Windows.Forms.PictureBox picBoxDermatoloji;
        public System.Windows.Forms.PictureBox picBoxOrtopediveTravma;
        public System.Windows.Forms.PictureBox picBoxFizikselTıpveRehabilitasyon;
        public System.Windows.Forms.PictureBox picBoxÜroloji;
        public System.Windows.Forms.PictureBox picBoxRomatoloji;
        public System.Windows.Forms.PictureBox picBoxHematoloji;
        public System.Windows.Forms.PictureBox picBoxNefroloji;
        public System.Windows.Forms.PictureBox picBoxPsikiyatri;
        public System.Windows.Forms.PictureBox picBoxBeyinveSinirCerrahisi;
        public System.Windows.Forms.Label label21;
        public System.Windows.Forms.Label lblBosBeyinveSinirCerrahisi;
        public System.Windows.Forms.Panel panel3;
        public System.Windows.Forms.Panel panel4;
        public System.Windows.Forms.Label lblDoluBeyinveSinirCerrahisi;
        public System.Windows.Forms.Label label24;
        public System.Windows.Forms.Panel panel5;
        public System.Windows.Forms.Label lblDoluKardiyoloji;
        public System.Windows.Forms.Label label26;
        public System.Windows.Forms.Panel panel6;
        public System.Windows.Forms.Label lblBosKardiyoloji;
        public System.Windows.Forms.Label label28;
        public System.Windows.Forms.Panel panel7;
        public System.Windows.Forms.Label lblBosNöroloji;
        public System.Windows.Forms.Label label30;
        public System.Windows.Forms.Panel panel8;
        public System.Windows.Forms.Label lblDoluNöroloji;
        public System.Windows.Forms.Label label32;
        public System.Windows.Forms.Panel panel9;
        public System.Windows.Forms.Label lblBosPsikiyatri;
        public System.Windows.Forms.Label label34;
        public System.Windows.Forms.Panel panel10;
        public System.Windows.Forms.Label lblDoluPsikiyatri;
        public System.Windows.Forms.Label label36;
        public System.Windows.Forms.Panel panel11;
        public System.Windows.Forms.Label lblBosİcHastaliklari;
        public System.Windows.Forms.Label label38;
        public System.Windows.Forms.Panel panel12;
        public System.Windows.Forms.Label lblDoluİcHastaliklari;
        public System.Windows.Forms.Label label40;
        public System.Windows.Forms.Panel panel13;
        public System.Windows.Forms.Label lblBosGözHastalıkları;
        public System.Windows.Forms.Label label42;
        public System.Windows.Forms.Panel panel14;
        public System.Windows.Forms.Label lblDoluGözHastalıkları;
        public System.Windows.Forms.Label label44;
        public System.Windows.Forms.Panel panel15;
        public System.Windows.Forms.Label lblBosKulakBurunBogazHastaliklari;
        public System.Windows.Forms.Label label46;
        public System.Windows.Forms.Panel panel16;
        public System.Windows.Forms.Label lblDoluKulakBurunBogazHastaliklari;
        public System.Windows.Forms.Label label48;
        public System.Windows.Forms.Panel panel17;
        public System.Windows.Forms.Label lblBosGögüsHastaliklari;
        public System.Windows.Forms.Label label50;
        public System.Windows.Forms.Panel panel18;
        public System.Windows.Forms.Label lblDoluGögüsHastaliklari;
        public System.Windows.Forms.Label label52;
        public System.Windows.Forms.Panel panel19;
        public System.Windows.Forms.Label lblBosKalpveDamarCerrahisi;
        public System.Windows.Forms.Label label54;
        public System.Windows.Forms.Panel panel20;
        public System.Windows.Forms.Label lblDoluKalpveDamarCerrahisi;
        public System.Windows.Forms.Label label56;
        public System.Windows.Forms.Panel panel21;
        public System.Windows.Forms.Label lblBosGastroenteroloji;
        public System.Windows.Forms.Label label58;
        public System.Windows.Forms.Panel panel22;
        public System.Windows.Forms.Label lblDoluGastroenteroloji;
        public System.Windows.Forms.Label label60;
        public System.Windows.Forms.Panel panel23;
        public System.Windows.Forms.Label lblBosPlastikveEstetikCerrahisi;
        public System.Windows.Forms.Label label62;
        public System.Windows.Forms.Panel panel24;
        public System.Windows.Forms.Label lblDoluPlastikveEstetikCerrahisi;
        public System.Windows.Forms.Label label64;
        public System.Windows.Forms.Panel panel25;
        public System.Windows.Forms.Label lblBosKadınHastaliklariveDogum;
        public System.Windows.Forms.Label label66;
        public System.Windows.Forms.Panel panel26;
        public System.Windows.Forms.Label lblDoluKadınHastaliklariveDogum;
        public System.Windows.Forms.Label label68;
        public System.Windows.Forms.Panel panel27;
        public System.Windows.Forms.Label lblBosEndokronolojiveMetabolizma;
        public System.Windows.Forms.Label label70;
        public System.Windows.Forms.Panel panel28;
        public System.Windows.Forms.Label lblDoluEndokronolojiveMetabolizma;
        public System.Windows.Forms.Label label72;
        public System.Windows.Forms.Panel panel29;
        public System.Windows.Forms.Label lblBosDermatoloji;
        public System.Windows.Forms.Label label74;
        public System.Windows.Forms.Panel panel30;
        public System.Windows.Forms.Label lblDoluDermatoloji;
        public System.Windows.Forms.Label label76;
        public System.Windows.Forms.Panel panel31;
        public System.Windows.Forms.Label lblBosOrtopediveTravma;
        public System.Windows.Forms.Label label78;
        public System.Windows.Forms.Panel panel32;
        public System.Windows.Forms.Label lblDoluOrtopediveTravma;
        public System.Windows.Forms.Label label80;
        public System.Windows.Forms.Panel panel33;
        public System.Windows.Forms.Label lblBosFizikselTıpveRehabilitasyon;
        public System.Windows.Forms.Label label82;
        public System.Windows.Forms.Panel panel34;
        public System.Windows.Forms.Label lblDoluFizikselTıpveRehabilitasyon;
        public System.Windows.Forms.Label label84;
        public System.Windows.Forms.Panel panel35;
        public System.Windows.Forms.Label lblBosNefroloji;
        public System.Windows.Forms.Label label86;
        public System.Windows.Forms.Panel panel36;
        public System.Windows.Forms.Label lblDoluNefroloji;
        public System.Windows.Forms.Label label88;
        public System.Windows.Forms.Panel panel37;
        public System.Windows.Forms.Label lblBosHematoloji;
        public System.Windows.Forms.Label label90;
        public System.Windows.Forms.Panel panel38;
        public System.Windows.Forms.Label lblDoluHematoloji;
        public System.Windows.Forms.Label label92;
        public System.Windows.Forms.Panel panel39;
        public System.Windows.Forms.Label lblBosRomatoloji;
        public System.Windows.Forms.Label label94;
        public System.Windows.Forms.Panel panel40;
        public System.Windows.Forms.Label lblDoluRomatoloji;
        public System.Windows.Forms.Label label96;
        public System.Windows.Forms.Panel panel41;
        public System.Windows.Forms.Label lblBosÜroloji;
        public System.Windows.Forms.Label label98;
        public System.Windows.Forms.Panel panel42;
        public System.Windows.Forms.Label lblDoluÜroloji;
        public System.Windows.Forms.Label label100;
    }
}