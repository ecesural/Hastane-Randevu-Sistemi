﻿namespace Randevu_Sistemi
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblKimlikSorgulamaAciklama = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnGüvenlikKoduYenile = new System.Windows.Forms.Button();
            this.lblGüvenlikKodu = new System.Windows.Forms.Label();
            this.picBoxGüvenlikKoduSimgesi = new System.Windows.Forms.PictureBox();
            this.txtGüvenlikKodu = new System.Windows.Forms.TextBox();
            this.lblDogumTarihi = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.btnGirisYap = new System.Windows.Forms.Button();
            this.txtAd = new System.Windows.Forms.TextBox();
            this.mskTxtDogumTarihi = new System.Windows.Forms.MaskedTextBox();
            this.picBoxTelNo = new System.Windows.Forms.PictureBox();
            this.picBoxSoyad = new System.Windows.Forms.PictureBox();
            this.lblTCKimlikNo = new System.Windows.Forms.Label();
            this.picBoxAd = new System.Windows.Forms.PictureBox();
            this.picBoxTCKimlikNo = new System.Windows.Forms.PictureBox();
            this.lblTelefonNo = new System.Windows.Forms.Label();
            this.lblSoyad = new System.Windows.Forms.Label();
            this.lblAd = new System.Windows.Forms.Label();
            this.txtSoyad = new System.Windows.Forms.TextBox();
            this.mskTxtTCKimlikNo = new System.Windows.Forms.MaskedTextBox();
            this.mskTxtTelefonNo = new System.Windows.Forms.MaskedTextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblKimlikSorgulamaBaslik = new System.Windows.Forms.Label();
            this.picBoxHastane1 = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lblGirisAciklama2 = new System.Windows.Forms.Label();
            this.lblGirisAciklama1 = new System.Windows.Forms.Label();
            this.lblGirisAciklamaBaslik = new System.Windows.Forms.Label();
            this.picBoxHastane2 = new System.Windows.Forms.PictureBox();
            this.errorProv_mskTxtTCKimlikNo = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProv_txtAd = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProv_txtSoyad = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProv_mskTxtDogumTarihi = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProv_mskTxtTelefonNo = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProv_txtGüvenlikKodu = new System.Windows.Forms.ErrorProvider(this.components);
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxGüvenlikKoduSimgesi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxTelNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSoyad)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxAd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxTCKimlikNo)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxHastane1)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxHastane2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProv_mskTxtTCKimlikNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProv_txtAd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProv_txtSoyad)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProv_mskTxtDogumTarihi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProv_mskTxtTelefonNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProv_txtGüvenlikKodu)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.lblKimlikSorgulamaAciklama);
            this.panel2.Location = new System.Drawing.Point(371, 62);
            this.panel2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(421, 56);
            this.panel2.TabIndex = 10;
            this.panel2.TabStop = true;
            // 
            // lblKimlikSorgulamaAciklama
            // 
            this.lblKimlikSorgulamaAciklama.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblKimlikSorgulamaAciklama.AutoSize = true;
            this.lblKimlikSorgulamaAciklama.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblKimlikSorgulamaAciklama.Location = new System.Drawing.Point(13, 2);
            this.lblKimlikSorgulamaAciklama.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblKimlikSorgulamaAciklama.Name = "lblKimlikSorgulamaAciklama";
            this.lblKimlikSorgulamaAciklama.Size = new System.Drawing.Size(387, 45);
            this.lblKimlikSorgulamaAciklama.TabIndex = 11;
            this.lblKimlikSorgulamaAciklama.Text = "T.C. kimlik numaranızı, ad\'ınızı, soyad\'ınızı, size ulaşabileceğimiz\r\ncep telefon" +
    "u numaranızı ve ekranda belirtilen güvenlik kodunu yazarak\r\ngiriş yapabilirsiniz" +
    ".";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.picBoxGüvenlikKoduSimgesi);
            this.panel3.Controls.Add(this.txtGüvenlikKodu);
            this.panel3.Controls.Add(this.lblDogumTarihi);
            this.panel3.Controls.Add(this.pictureBox4);
            this.panel3.Controls.Add(this.btnGirisYap);
            this.panel3.Controls.Add(this.txtAd);
            this.panel3.Controls.Add(this.mskTxtDogumTarihi);
            this.panel3.Controls.Add(this.picBoxTelNo);
            this.panel3.Controls.Add(this.picBoxSoyad);
            this.panel3.Controls.Add(this.lblTCKimlikNo);
            this.panel3.Controls.Add(this.picBoxAd);
            this.panel3.Controls.Add(this.picBoxTCKimlikNo);
            this.panel3.Controls.Add(this.lblTelefonNo);
            this.panel3.Controls.Add(this.lblSoyad);
            this.panel3.Controls.Add(this.lblAd);
            this.panel3.Controls.Add(this.txtSoyad);
            this.panel3.Controls.Add(this.mskTxtTCKimlikNo);
            this.panel3.Controls.Add(this.mskTxtTelefonNo);
            this.panel3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.panel3.ForeColor = System.Drawing.Color.Black;
            this.panel3.Location = new System.Drawing.Point(371, 118);
            this.panel3.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(421, 283);
            this.panel3.TabIndex = 12;
            this.panel3.TabStop = true;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.btnGüvenlikKoduYenile);
            this.panel5.Controls.Add(this.lblGüvenlikKodu);
            this.panel5.Location = new System.Drawing.Point(11, 180);
            this.panel5.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(128, 33);
            this.panel5.TabIndex = 18;
            // 
            // btnGüvenlikKoduYenile
            // 
            this.btnGüvenlikKoduYenile.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGüvenlikKoduYenile.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnGüvenlikKoduYenile.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnGüvenlikKoduYenile.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnGüvenlikKoduYenile.BackgroundImage")));
            this.btnGüvenlikKoduYenile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnGüvenlikKoduYenile.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGüvenlikKoduYenile.Location = new System.Drawing.Point(92, 3);
            this.btnGüvenlikKoduYenile.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnGüvenlikKoduYenile.Name = "btnGüvenlikKoduYenile";
            this.btnGüvenlikKoduYenile.Size = new System.Drawing.Size(29, 24);
            this.btnGüvenlikKoduYenile.TabIndex = 6;
            this.btnGüvenlikKoduYenile.UseVisualStyleBackColor = false;
            this.btnGüvenlikKoduYenile.Click += new System.EventHandler(this.btnGüvenlikKoduYenile_Click);
            // 
            // lblGüvenlikKodu
            // 
            this.lblGüvenlikKodu.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblGüvenlikKodu.AutoSize = true;
            this.lblGüvenlikKodu.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblGüvenlikKodu.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblGüvenlikKodu.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblGüvenlikKodu.Location = new System.Drawing.Point(1, 7);
            this.lblGüvenlikKodu.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblGüvenlikKodu.Name = "lblGüvenlikKodu";
            this.lblGüvenlikKodu.Size = new System.Drawing.Size(95, 16);
            this.lblGüvenlikKodu.TabIndex = 17;
            this.lblGüvenlikKodu.Text = "Güvenlik Kodu:";
            // 
            // picBoxGüvenlikKoduSimgesi
            // 
            this.picBoxGüvenlikKoduSimgesi.BackColor = System.Drawing.Color.Red;
            this.picBoxGüvenlikKoduSimgesi.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxGüvenlikKoduSimgesi.BackgroundImage")));
            this.picBoxGüvenlikKoduSimgesi.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picBoxGüvenlikKoduSimgesi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxGüvenlikKoduSimgesi.Location = new System.Drawing.Point(242, 180);
            this.picBoxGüvenlikKoduSimgesi.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.picBoxGüvenlikKoduSimgesi.Name = "picBoxGüvenlikKoduSimgesi";
            this.picBoxGüvenlikKoduSimgesi.Size = new System.Drawing.Size(30, 33);
            this.picBoxGüvenlikKoduSimgesi.TabIndex = 32;
            this.picBoxGüvenlikKoduSimgesi.TabStop = false;
            // 
            // txtGüvenlikKodu
            // 
            this.txtGüvenlikKodu.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtGüvenlikKodu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtGüvenlikKodu.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtGüvenlikKodu.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtGüvenlikKodu.Location = new System.Drawing.Point(268, 180);
            this.txtGüvenlikKodu.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtGüvenlikKodu.Multiline = true;
            this.txtGüvenlikKodu.Name = "txtGüvenlikKodu";
            this.txtGüvenlikKodu.ShortcutsEnabled = false;
            this.txtGüvenlikKodu.Size = new System.Drawing.Size(88, 33);
            this.txtGüvenlikKodu.TabIndex = 5;
            // 
            // lblDogumTarihi
            // 
            this.lblDogumTarihi.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDogumTarihi.AutoSize = true;
            this.lblDogumTarihi.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblDogumTarihi.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblDogumTarihi.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblDogumTarihi.Location = new System.Drawing.Point(40, 115);
            this.lblDogumTarihi.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDogumTarihi.Name = "lblDogumTarihi";
            this.lblDogumTarihi.Size = new System.Drawing.Size(104, 16);
            this.lblDogumTarihi.TabIndex = 31;
            this.lblDogumTarihi.Text = "Doğum Tarihiniz:";
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox4.BackgroundImage")));
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox4.Location = new System.Drawing.Point(146, 111);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(34, 25);
            this.pictureBox4.TabIndex = 30;
            this.pictureBox4.TabStop = false;
            // 
            // btnGirisYap
            // 
            this.btnGirisYap.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGirisYap.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnGirisYap.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnGirisYap.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGirisYap.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnGirisYap.ForeColor = System.Drawing.Color.White;
            this.btnGirisYap.Location = new System.Drawing.Point(278, 227);
            this.btnGirisYap.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnGirisYap.Name = "btnGirisYap";
            this.btnGirisYap.Size = new System.Drawing.Size(78, 31);
            this.btnGirisYap.TabIndex = 7;
            this.btnGirisYap.Text = "Giriş Yap";
            this.btnGirisYap.UseVisualStyleBackColor = false;
            this.btnGirisYap.Click += new System.EventHandler(this.btnGirisYap_Click);
            this.btnGirisYap.MouseLeave += new System.EventHandler(this.btnGirisYap_MouseLeave);
            this.btnGirisYap.MouseMove += new System.Windows.Forms.MouseEventHandler(this.btnGirisYap_MouseMove);
            // 
            // txtAd
            // 
            this.txtAd.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtAd.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtAd.ForeColor = System.Drawing.Color.Black;
            this.txtAd.Location = new System.Drawing.Point(180, 47);
            this.txtAd.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtAd.MaxLength = 30;
            this.txtAd.Name = "txtAd";
            this.txtAd.Size = new System.Drawing.Size(174, 25);
            this.txtAd.TabIndex = 1;
            this.txtAd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAd_KeyPress);
            // 
            // mskTxtDogumTarihi
            // 
            this.mskTxtDogumTarihi.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.mskTxtDogumTarihi.BeepOnError = true;
            this.mskTxtDogumTarihi.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.mskTxtDogumTarihi.Location = new System.Drawing.Point(180, 111);
            this.mskTxtDogumTarihi.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.mskTxtDogumTarihi.Mask = "00/00/0000";
            this.mskTxtDogumTarihi.Name = "mskTxtDogumTarihi";
            this.mskTxtDogumTarihi.ResetOnSpace = false;
            this.mskTxtDogumTarihi.Size = new System.Drawing.Size(174, 25);
            this.mskTxtDogumTarihi.TabIndex = 3;
            this.mskTxtDogumTarihi.ValidatingType = typeof(System.DateTime);
            // 
            // picBoxTelNo
            // 
            this.picBoxTelNo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxTelNo.BackgroundImage")));
            this.picBoxTelNo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picBoxTelNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxTelNo.Location = new System.Drawing.Point(146, 143);
            this.picBoxTelNo.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.picBoxTelNo.Name = "picBoxTelNo";
            this.picBoxTelNo.Size = new System.Drawing.Size(34, 25);
            this.picBoxTelNo.TabIndex = 25;
            this.picBoxTelNo.TabStop = false;
            // 
            // picBoxSoyad
            // 
            this.picBoxSoyad.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxSoyad.BackgroundImage")));
            this.picBoxSoyad.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picBoxSoyad.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxSoyad.Location = new System.Drawing.Point(146, 80);
            this.picBoxSoyad.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.picBoxSoyad.Name = "picBoxSoyad";
            this.picBoxSoyad.Size = new System.Drawing.Size(34, 25);
            this.picBoxSoyad.TabIndex = 29;
            this.picBoxSoyad.TabStop = false;
            // 
            // lblTCKimlikNo
            // 
            this.lblTCKimlikNo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTCKimlikNo.AutoSize = true;
            this.lblTCKimlikNo.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblTCKimlikNo.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTCKimlikNo.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblTCKimlikNo.Location = new System.Drawing.Point(46, 18);
            this.lblTCKimlikNo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTCKimlikNo.Name = "lblTCKimlikNo";
            this.lblTCKimlikNo.Size = new System.Drawing.Size(95, 16);
            this.lblTCKimlikNo.TabIndex = 22;
            this.lblTCKimlikNo.Text = "T.C. Kimlik No:";
            // 
            // picBoxAd
            // 
            this.picBoxAd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxAd.BackgroundImage")));
            this.picBoxAd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picBoxAd.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxAd.Location = new System.Drawing.Point(146, 47);
            this.picBoxAd.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.picBoxAd.Name = "picBoxAd";
            this.picBoxAd.Size = new System.Drawing.Size(34, 25);
            this.picBoxAd.TabIndex = 28;
            this.picBoxAd.TabStop = false;
            // 
            // picBoxTCKimlikNo
            // 
            this.picBoxTCKimlikNo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxTCKimlikNo.BackgroundImage")));
            this.picBoxTCKimlikNo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picBoxTCKimlikNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxTCKimlikNo.Location = new System.Drawing.Point(146, 14);
            this.picBoxTCKimlikNo.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.picBoxTCKimlikNo.Name = "picBoxTCKimlikNo";
            this.picBoxTCKimlikNo.Size = new System.Drawing.Size(34, 25);
            this.picBoxTCKimlikNo.TabIndex = 24;
            this.picBoxTCKimlikNo.TabStop = false;
            // 
            // lblTelefonNo
            // 
            this.lblTelefonNo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTelefonNo.AutoSize = true;
            this.lblTelefonNo.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblTelefonNo.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTelefonNo.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblTelefonNo.Location = new System.Drawing.Point(20, 149);
            this.lblTelefonNo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTelefonNo.Name = "lblTelefonNo";
            this.lblTelefonNo.Size = new System.Drawing.Size(118, 16);
            this.lblTelefonNo.TabIndex = 19;
            this.lblTelefonNo.Text = "Telefon Numaranız:";
            // 
            // lblSoyad
            // 
            this.lblSoyad.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSoyad.AutoSize = true;
            this.lblSoyad.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblSoyad.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSoyad.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblSoyad.Location = new System.Drawing.Point(90, 84);
            this.lblSoyad.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSoyad.Name = "lblSoyad";
            this.lblSoyad.Size = new System.Drawing.Size(49, 16);
            this.lblSoyad.TabIndex = 20;
            this.lblSoyad.Text = "Soyad:";
            // 
            // lblAd
            // 
            this.lblAd.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblAd.AutoSize = true;
            this.lblAd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblAd.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblAd.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblAd.Location = new System.Drawing.Point(110, 54);
            this.lblAd.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAd.Name = "lblAd";
            this.lblAd.Size = new System.Drawing.Size(28, 16);
            this.lblAd.TabIndex = 21;
            this.lblAd.Text = "Ad:";
            // 
            // txtSoyad
            // 
            this.txtSoyad.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSoyad.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtSoyad.ForeColor = System.Drawing.Color.Black;
            this.txtSoyad.Location = new System.Drawing.Point(180, 80);
            this.txtSoyad.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtSoyad.MaxLength = 20;
            this.txtSoyad.Name = "txtSoyad";
            this.txtSoyad.Size = new System.Drawing.Size(174, 25);
            this.txtSoyad.TabIndex = 2;
            this.txtSoyad.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSoyad_KeyPress);
            // 
            // mskTxtTCKimlikNo
            // 
            this.mskTxtTCKimlikNo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.mskTxtTCKimlikNo.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.mskTxtTCKimlikNo.ForeColor = System.Drawing.Color.Black;
            this.mskTxtTCKimlikNo.Location = new System.Drawing.Point(180, 14);
            this.mskTxtTCKimlikNo.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.mskTxtTCKimlikNo.Mask = "00000000000";
            this.mskTxtTCKimlikNo.Name = "mskTxtTCKimlikNo";
            this.mskTxtTCKimlikNo.ResetOnSpace = false;
            this.mskTxtTCKimlikNo.Size = new System.Drawing.Size(174, 25);
            this.mskTxtTCKimlikNo.TabIndex = 0;
            // 
            // mskTxtTelefonNo
            // 
            this.mskTxtTelefonNo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.mskTxtTelefonNo.BeepOnError = true;
            this.mskTxtTelefonNo.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.mskTxtTelefonNo.ForeColor = System.Drawing.Color.Black;
            this.mskTxtTelefonNo.Location = new System.Drawing.Point(180, 143);
            this.mskTxtTelefonNo.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.mskTxtTelefonNo.Mask = "(000) 000 00 00";
            this.mskTxtTelefonNo.Name = "mskTxtTelefonNo";
            this.mskTxtTelefonNo.ResetOnSpace = false;
            this.mskTxtTelefonNo.Size = new System.Drawing.Size(174, 25);
            this.mskTxtTelefonNo.TabIndex = 4;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.lblKimlikSorgulamaBaslik);
            this.panel1.Location = new System.Drawing.Point(371, 12);
            this.panel1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(421, 50);
            this.panel1.TabIndex = 8;
            this.panel1.TabStop = true;
            // 
            // lblKimlikSorgulamaBaslik
            // 
            this.lblKimlikSorgulamaBaslik.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblKimlikSorgulamaBaslik.AutoSize = true;
            this.lblKimlikSorgulamaBaslik.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblKimlikSorgulamaBaslik.ForeColor = System.Drawing.Color.Crimson;
            this.lblKimlikSorgulamaBaslik.Location = new System.Drawing.Point(128, 10);
            this.lblKimlikSorgulamaBaslik.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblKimlikSorgulamaBaslik.Name = "lblKimlikSorgulamaBaslik";
            this.lblKimlikSorgulamaBaslik.Size = new System.Drawing.Size(186, 24);
            this.lblKimlikSorgulamaBaslik.TabIndex = 9;
            this.lblKimlikSorgulamaBaslik.Text = "Kimlik Sorgulama";
            // 
            // picBoxHastane1
            // 
            this.picBoxHastane1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxHastane1.BackgroundImage")));
            this.picBoxHastane1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picBoxHastane1.Location = new System.Drawing.Point(62, 12);
            this.picBoxHastane1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.picBoxHastane1.Name = "picBoxHastane1";
            this.picBoxHastane1.Size = new System.Drawing.Size(102, 111);
            this.picBoxHastane1.TabIndex = 25;
            this.picBoxHastane1.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.lblGirisAciklama2);
            this.panel4.Controls.Add(this.lblGirisAciklama1);
            this.panel4.Controls.Add(this.lblGirisAciklamaBaslik);
            this.panel4.Location = new System.Drawing.Point(12, 137);
            this.panel4.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(337, 187);
            this.panel4.TabIndex = 13;
            this.panel4.TabStop = true;
            // 
            // lblGirisAciklama2
            // 
            this.lblGirisAciklama2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblGirisAciklama2.AutoSize = true;
            this.lblGirisAciklama2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblGirisAciklama2.ForeColor = System.Drawing.Color.Black;
            this.lblGirisAciklama2.Location = new System.Drawing.Point(2, 138);
            this.lblGirisAciklama2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblGirisAciklama2.Name = "lblGirisAciklama2";
            this.lblGirisAciklama2.Size = new System.Drawing.Size(210, 16);
            this.lblGirisAciklama2.TabIndex = 16;
            this.lblGirisAciklama2.Text = "Her alanın doldurulması zorunludur.";
            // 
            // lblGirisAciklama1
            // 
            this.lblGirisAciklama1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblGirisAciklama1.AutoSize = true;
            this.lblGirisAciklama1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblGirisAciklama1.ForeColor = System.Drawing.Color.Black;
            this.lblGirisAciklama1.Location = new System.Drawing.Point(2, 38);
            this.lblGirisAciklama1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblGirisAciklama1.Name = "lblGirisAciklama1";
            this.lblGirisAciklama1.Size = new System.Drawing.Size(327, 80);
            this.lblGirisAciklama1.TabIndex = 15;
            this.lblGirisAciklama1.Text = resources.GetString("lblGirisAciklama1.Text");
            // 
            // lblGirisAciklamaBaslik
            // 
            this.lblGirisAciklamaBaslik.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblGirisAciklamaBaslik.AutoSize = true;
            this.lblGirisAciklamaBaslik.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblGirisAciklamaBaslik.ForeColor = System.Drawing.Color.Crimson;
            this.lblGirisAciklamaBaslik.Location = new System.Drawing.Point(2, 4);
            this.lblGirisAciklamaBaslik.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblGirisAciklamaBaslik.Name = "lblGirisAciklamaBaslik";
            this.lblGirisAciklamaBaslik.Size = new System.Drawing.Size(276, 22);
            this.lblGirisAciklamaBaslik.TabIndex = 14;
            this.lblGirisAciklamaBaslik.Text = "Randevu sistemine hoşgeldiniz.\r\n";
            // 
            // picBoxHastane2
            // 
            this.picBoxHastane2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxHastane2.BackgroundImage")));
            this.picBoxHastane2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picBoxHastane2.Location = new System.Drawing.Point(190, 12);
            this.picBoxHastane2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.picBoxHastane2.Name = "picBoxHastane2";
            this.picBoxHastane2.Size = new System.Drawing.Size(102, 111);
            this.picBoxHastane2.TabIndex = 27;
            this.picBoxHastane2.TabStop = false;
            // 
            // errorProv_mskTxtTCKimlikNo
            // 
            this.errorProv_mskTxtTCKimlikNo.BlinkRate = 1000;
            this.errorProv_mskTxtTCKimlikNo.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.AlwaysBlink;
            this.errorProv_mskTxtTCKimlikNo.ContainerControl = this;
            this.errorProv_mskTxtTCKimlikNo.Icon = ((System.Drawing.Icon)(resources.GetObject("errorProv_mskTxtTCKimlikNo.Icon")));
            // 
            // errorProv_txtAd
            // 
            this.errorProv_txtAd.BlinkRate = 1000;
            this.errorProv_txtAd.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.AlwaysBlink;
            this.errorProv_txtAd.ContainerControl = this;
            this.errorProv_txtAd.Icon = ((System.Drawing.Icon)(resources.GetObject("errorProv_txtAd.Icon")));
            // 
            // errorProv_txtSoyad
            // 
            this.errorProv_txtSoyad.BlinkRate = 1000;
            this.errorProv_txtSoyad.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.AlwaysBlink;
            this.errorProv_txtSoyad.ContainerControl = this;
            this.errorProv_txtSoyad.Icon = ((System.Drawing.Icon)(resources.GetObject("errorProv_txtSoyad.Icon")));
            // 
            // errorProv_mskTxtDogumTarihi
            // 
            this.errorProv_mskTxtDogumTarihi.BlinkRate = 1000;
            this.errorProv_mskTxtDogumTarihi.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.AlwaysBlink;
            this.errorProv_mskTxtDogumTarihi.ContainerControl = this;
            this.errorProv_mskTxtDogumTarihi.Icon = ((System.Drawing.Icon)(resources.GetObject("errorProv_mskTxtDogumTarihi.Icon")));
            // 
            // errorProv_mskTxtTelefonNo
            // 
            this.errorProv_mskTxtTelefonNo.BlinkRate = 1000;
            this.errorProv_mskTxtTelefonNo.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.AlwaysBlink;
            this.errorProv_mskTxtTelefonNo.ContainerControl = this;
            this.errorProv_mskTxtTelefonNo.Icon = ((System.Drawing.Icon)(resources.GetObject("errorProv_mskTxtTelefonNo.Icon")));
            // 
            // errorProv_txtGüvenlikKodu
            // 
            this.errorProv_txtGüvenlikKodu.BlinkRate = 1000;
            this.errorProv_txtGüvenlikKodu.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.AlwaysBlink;
            this.errorProv_txtGüvenlikKodu.ContainerControl = this;
            this.errorProv_txtGüvenlikKodu.Icon = ((System.Drawing.Icon)(resources.GetObject("errorProv_txtGüvenlikKodu.Icon")));
            // 
            // Form1
            // 
            this.AcceptButton = this.btnGirisYap;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(821, 423);
            this.Controls.Add(this.picBoxHastane2);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.picBoxHastane1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Kimlik Sorgulama";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxGüvenlikKoduSimgesi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxTelNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSoyad)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxAd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxTCKimlikNo)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxHastane1)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxHastane2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProv_mskTxtTCKimlikNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProv_txtAd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProv_txtSoyad)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProv_mskTxtDogumTarihi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProv_mskTxtTelefonNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProv_txtGüvenlikKodu)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        public System.Windows.Forms.TextBox txtSoyad;
        public System.Windows.Forms.TextBox txtAd;
        public System.Windows.Forms.MaskedTextBox mskTxtTCKimlikNo;
        public System.Windows.Forms.MaskedTextBox mskTxtTelefonNo;
        public System.Windows.Forms.Button btnGirisYap;
        public System.Windows.Forms.MaskedTextBox mskTxtDogumTarihi;
        public System.Windows.Forms.TextBox txtGüvenlikKodu;
        public System.Windows.Forms.Panel panel2;
        public System.Windows.Forms.Label lblKimlikSorgulamaAciklama;
        public System.Windows.Forms.Panel panel3;
        public System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.Label lblKimlikSorgulamaBaslik;
        public System.Windows.Forms.PictureBox picBoxTelNo;
        public System.Windows.Forms.PictureBox picBoxSoyad;
        public System.Windows.Forms.PictureBox picBoxAd;
        public System.Windows.Forms.PictureBox picBoxTCKimlikNo;
        public System.Windows.Forms.Label lblTelefonNo;
        public System.Windows.Forms.Label lblSoyad;
        public System.Windows.Forms.Label lblAd;
        public System.Windows.Forms.Label lblTCKimlikNo;
        public System.Windows.Forms.PictureBox picBoxHastane1;
        public System.Windows.Forms.Panel panel4;
        public System.Windows.Forms.Label lblGirisAciklama2;
        public System.Windows.Forms.Label lblGirisAciklama1;
        public System.Windows.Forms.Label lblGirisAciklamaBaslik;
        public System.Windows.Forms.PictureBox picBoxHastane2;
        public System.Windows.Forms.PictureBox pictureBox4;
        public System.Windows.Forms.Label lblDogumTarihi;
        public System.Windows.Forms.Label lblGüvenlikKodu;
        public System.Windows.Forms.PictureBox picBoxGüvenlikKoduSimgesi;
        public System.Windows.Forms.Panel panel5;
        public System.Windows.Forms.Button btnGüvenlikKoduYenile;
        public System.Windows.Forms.ErrorProvider errorProv_mskTxtTCKimlikNo;
        public System.Windows.Forms.ErrorProvider errorProv_txtAd;
        public System.Windows.Forms.ErrorProvider errorProv_txtSoyad;
        public System.Windows.Forms.ErrorProvider errorProv_mskTxtDogumTarihi;
        public System.Windows.Forms.ErrorProvider errorProv_mskTxtTelefonNo;
        public System.Windows.Forms.ErrorProvider errorProv_txtGüvenlikKodu;
    }
}

