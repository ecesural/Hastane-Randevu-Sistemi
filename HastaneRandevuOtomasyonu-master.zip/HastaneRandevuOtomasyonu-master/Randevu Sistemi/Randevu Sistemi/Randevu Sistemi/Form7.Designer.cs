﻿namespace Randevu_Sistemi
{
    partial class Form7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form7));
            this.btnRandevularım = new System.Windows.Forms.Button();
            this.btnCikis = new System.Windows.Forms.Button();
            this.lblHosgeldinizAciklama = new System.Windows.Forms.Label();
            this.pnlRandevuOnayi = new System.Windows.Forms.Panel();
            this.picBoxRandevunuzSistemeKaydedildi = new System.Windows.Forms.PictureBox();
            this.pictureBoxOnayKodunuSaklayinizBilgi = new System.Windows.Forms.PictureBox();
            this.lblAciklama2 = new System.Windows.Forms.Label();
            this.lblBransAdi = new System.Windows.Forms.Label();
            this.lblAciklama1 = new System.Windows.Forms.Label();
            this.lblTarih = new System.Windows.Forms.Label();
            this.lblSaat = new System.Windows.Forms.Label();
            this.lblAciklama3 = new System.Windows.Forms.Label();
            this.lblAciklama4 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblHastaSoyad = new System.Windows.Forms.Label();
            this.lblHastaAd = new System.Windows.Forms.Label();
            this.lblHastaTCKimlikNo = new System.Windows.Forms.Label();
            this.lblRandevuSaati = new System.Windows.Forms.Label();
            this.lblRandevuTarihi = new System.Windows.Forms.Label();
            this.lblPoliklinik = new System.Windows.Forms.Label();
            this.lblSube = new System.Windows.Forms.Label();
            this.lblOnayKodu2 = new System.Windows.Forms.Label();
            this.lblRandevuAlmaZamani = new System.Windows.Forms.Label();
            this.lblOnayKoduAciklama = new System.Windows.Forms.Label();
            this.lblOnayKodu1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxRandevunuzSistemeKaydedildi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOnayKodunuSaklayinizBilgi)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnRandevularım
            // 
            this.btnRandevularım.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnRandevularım.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnRandevularım.BackColor = System.Drawing.Color.Orange;
            this.btnRandevularım.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRandevularım.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnRandevularım.ForeColor = System.Drawing.Color.White;
            this.btnRandevularım.Location = new System.Drawing.Point(841, 43);
            this.btnRandevularım.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnRandevularım.Name = "btnRandevularım";
            this.btnRandevularım.Size = new System.Drawing.Size(101, 31);
            this.btnRandevularım.TabIndex = 60;
            this.btnRandevularım.Text = "Randevularım";
            this.btnRandevularım.UseVisualStyleBackColor = false;
            this.btnRandevularım.Click += new System.EventHandler(this.btnRandevularım_Click);
            this.btnRandevularım.MouseLeave += new System.EventHandler(this.btnRandevularım_MouseLeave);
            this.btnRandevularım.MouseMove += new System.Windows.Forms.MouseEventHandler(this.btnRandevularım_MouseMove);
            // 
            // btnCikis
            // 
            this.btnCikis.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnCikis.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnCikis.BackColor = System.Drawing.Color.Orange;
            this.btnCikis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCikis.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnCikis.ForeColor = System.Drawing.Color.White;
            this.btnCikis.Location = new System.Drawing.Point(947, 43);
            this.btnCikis.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnCikis.Name = "btnCikis";
            this.btnCikis.Size = new System.Drawing.Size(66, 31);
            this.btnCikis.TabIndex = 59;
            this.btnCikis.Text = "Çıkış";
            this.btnCikis.UseVisualStyleBackColor = false;
            this.btnCikis.Click += new System.EventHandler(this.btnCikis_Click);
            this.btnCikis.MouseLeave += new System.EventHandler(this.btnCikis_MouseLeave);
            this.btnCikis.MouseMove += new System.Windows.Forms.MouseEventHandler(this.btnCikis_MouseMove);
            // 
            // lblHosgeldinizAciklama
            // 
            this.lblHosgeldinizAciklama.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblHosgeldinizAciklama.AutoSize = true;
            this.lblHosgeldinizAciklama.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblHosgeldinizAciklama.ForeColor = System.Drawing.Color.Black;
            this.lblHosgeldinizAciklama.Location = new System.Drawing.Point(632, 12);
            this.lblHosgeldinizAciklama.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblHosgeldinizAciklama.Name = "lblHosgeldinizAciklama";
            this.lblHosgeldinizAciklama.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblHosgeldinizAciklama.Size = new System.Drawing.Size(135, 15);
            this.lblHosgeldinizAciklama.TabIndex = 58;
            this.lblHosgeldinizAciklama.Text = "lblHosgeldinizAciklama";
            this.lblHosgeldinizAciklama.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlRandevuOnayi
            // 
            this.pnlRandevuOnayi.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnlRandevuOnayi.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlRandevuOnayi.BackgroundImage")));
            this.pnlRandevuOnayi.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pnlRandevuOnayi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlRandevuOnayi.Location = new System.Drawing.Point(2, 80);
            this.pnlRandevuOnayi.Name = "pnlRandevuOnayi";
            this.pnlRandevuOnayi.Size = new System.Drawing.Size(1011, 108);
            this.pnlRandevuOnayi.TabIndex = 57;
            // 
            // picBoxRandevunuzSistemeKaydedildi
            // 
            this.picBoxRandevunuzSistemeKaydedildi.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picBoxRandevunuzSistemeKaydedildi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxRandevunuzSistemeKaydedildi.Image = ((System.Drawing.Image)(resources.GetObject("picBoxRandevunuzSistemeKaydedildi.Image")));
            this.picBoxRandevunuzSistemeKaydedildi.Location = new System.Drawing.Point(2, 202);
            this.picBoxRandevunuzSistemeKaydedildi.Name = "picBoxRandevunuzSistemeKaydedildi";
            this.picBoxRandevunuzSistemeKaydedildi.Size = new System.Drawing.Size(1010, 41);
            this.picBoxRandevunuzSistemeKaydedildi.TabIndex = 123;
            this.picBoxRandevunuzSistemeKaydedildi.TabStop = false;
            // 
            // pictureBoxOnayKodunuSaklayinizBilgi
            // 
            this.pictureBoxOnayKodunuSaklayinizBilgi.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBoxOnayKodunuSaklayinizBilgi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxOnayKodunuSaklayinizBilgi.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxOnayKodunuSaklayinizBilgi.Image")));
            this.pictureBoxOnayKodunuSaklayinizBilgi.Location = new System.Drawing.Point(3, 288);
            this.pictureBoxOnayKodunuSaklayinizBilgi.Name = "pictureBoxOnayKodunuSaklayinizBilgi";
            this.pictureBoxOnayKodunuSaklayinizBilgi.Size = new System.Drawing.Size(1010, 32);
            this.pictureBoxOnayKodunuSaklayinizBilgi.TabIndex = 124;
            this.pictureBoxOnayKodunuSaklayinizBilgi.TabStop = false;
            // 
            // lblAciklama2
            // 
            this.lblAciklama2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblAciklama2.AutoSize = true;
            this.lblAciklama2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblAciklama2.ForeColor = System.Drawing.Color.Black;
            this.lblAciklama2.Location = new System.Drawing.Point(410, 329);
            this.lblAciklama2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAciklama2.Name = "lblAciklama2";
            this.lblAciklama2.Size = new System.Drawing.Size(103, 15);
            this.lblAciklama2.TabIndex = 140;
            this.lblAciklama2.Text = "polikliniğine, saat";
            // 
            // lblBransAdi
            // 
            this.lblBransAdi.AutoSize = true;
            this.lblBransAdi.BackColor = System.Drawing.Color.White;
            this.lblBransAdi.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBransAdi.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblBransAdi.Location = new System.Drawing.Point(227, 328);
            this.lblBransAdi.Name = "lblBransAdi";
            this.lblBransAdi.Size = new System.Drawing.Size(69, 16);
            this.lblBransAdi.TabIndex = 139;
            this.lblBransAdi.Text = "Branş Adı";
            // 
            // lblAciklama1
            // 
            this.lblAciklama1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblAciklama1.AutoSize = true;
            this.lblAciklama1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblAciklama1.ForeColor = System.Drawing.Color.Black;
            this.lblAciklama1.Location = new System.Drawing.Point(167, 329);
            this.lblAciklama1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAciklama1.Name = "lblAciklama1";
            this.lblAciklama1.Size = new System.Drawing.Size(55, 15);
            this.lblAciklama1.TabIndex = 138;
            this.lblAciklama1.Text = "tarihinde";
            // 
            // lblTarih
            // 
            this.lblTarih.AutoSize = true;
            this.lblTarih.BackColor = System.Drawing.Color.White;
            this.lblTarih.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTarih.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblTarih.Location = new System.Drawing.Point(12, 328);
            this.lblTarih.Name = "lblTarih";
            this.lblTarih.Size = new System.Drawing.Size(130, 16);
            this.lblTarih.TabIndex = 137;
            this.lblTarih.Text = "ToLongDateString()";
            // 
            // lblSaat
            // 
            this.lblSaat.AutoSize = true;
            this.lblSaat.BackColor = System.Drawing.Color.White;
            this.lblSaat.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSaat.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblSaat.Location = new System.Drawing.Point(518, 328);
            this.lblSaat.Name = "lblSaat";
            this.lblSaat.Size = new System.Drawing.Size(37, 16);
            this.lblSaat.TabIndex = 141;
            this.lblSaat.Text = "Saat";
            // 
            // lblAciklama3
            // 
            this.lblAciklama3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblAciklama3.AutoSize = true;
            this.lblAciklama3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblAciklama3.ForeColor = System.Drawing.Color.Black;
            this.lblAciklama3.Location = new System.Drawing.Point(557, 329);
            this.lblAciklama3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAciklama3.Name = "lblAciklama3";
            this.lblAciklama3.Size = new System.Drawing.Size(446, 15);
            this.lblAciklama3.TabIndex = 142;
            this.lblAciklama3.Text = "randevunuz başarıyla alınmıştır. Almış olduğunuz randevularınıza sağ üst köşede";
            // 
            // lblAciklama4
            // 
            this.lblAciklama4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblAciklama4.AutoSize = true;
            this.lblAciklama4.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblAciklama4.ForeColor = System.Drawing.Color.Black;
            this.lblAciklama4.Location = new System.Drawing.Point(12, 347);
            this.lblAciklama4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAciklama4.Name = "lblAciklama4";
            this.lblAciklama4.Size = new System.Drawing.Size(506, 15);
            this.lblAciklama4.TabIndex = 143;
            this.lblAciklama4.Text = "bulunan \"Randevularım\" butonundan göz atabilir, randevu saatinden önce iptal edeb" +
    "ilirsiniz.";
            // 
            // panel2
            // 
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.lblHastaSoyad);
            this.panel2.Controls.Add(this.lblHastaAd);
            this.panel2.Controls.Add(this.lblHastaTCKimlikNo);
            this.panel2.Controls.Add(this.lblRandevuSaati);
            this.panel2.Controls.Add(this.lblRandevuTarihi);
            this.panel2.Controls.Add(this.lblPoliklinik);
            this.panel2.Controls.Add(this.lblSube);
            this.panel2.Controls.Add(this.lblOnayKodu2);
            this.panel2.Controls.Add(this.lblRandevuAlmaZamani);
            this.panel2.Location = new System.Drawing.Point(12, 384);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(991, 228);
            this.panel2.TabIndex = 144;
            // 
            // lblHastaSoyad
            // 
            this.lblHastaSoyad.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblHastaSoyad.AutoSize = true;
            this.lblHastaSoyad.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblHastaSoyad.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblHastaSoyad.Location = new System.Drawing.Point(240, 205);
            this.lblHastaSoyad.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblHastaSoyad.Name = "lblHastaSoyad";
            this.lblHastaSoyad.Size = new System.Drawing.Size(99, 16);
            this.lblHastaSoyad.TabIndex = 153;
            this.lblHastaSoyad.Text = "HASTA SOYAD";
            // 
            // lblHastaAd
            // 
            this.lblHastaAd.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblHastaAd.AutoSize = true;
            this.lblHastaAd.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblHastaAd.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblHastaAd.Location = new System.Drawing.Point(240, 180);
            this.lblHastaAd.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblHastaAd.Name = "lblHastaAd";
            this.lblHastaAd.Size = new System.Drawing.Size(73, 16);
            this.lblHastaAd.TabIndex = 152;
            this.lblHastaAd.Text = "HASTA AD";
            // 
            // lblHastaTCKimlikNo
            // 
            this.lblHastaTCKimlikNo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblHastaTCKimlikNo.AutoSize = true;
            this.lblHastaTCKimlikNo.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblHastaTCKimlikNo.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblHastaTCKimlikNo.Location = new System.Drawing.Point(240, 155);
            this.lblHastaTCKimlikNo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblHastaTCKimlikNo.Name = "lblHastaTCKimlikNo";
            this.lblHastaTCKimlikNo.Size = new System.Drawing.Size(151, 16);
            this.lblHastaTCKimlikNo.TabIndex = 151;
            this.lblHastaTCKimlikNo.Text = "HASTA T.C. KİMLİK NO";
            // 
            // lblRandevuSaati
            // 
            this.lblRandevuSaati.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblRandevuSaati.AutoSize = true;
            this.lblRandevuSaati.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblRandevuSaati.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblRandevuSaati.Location = new System.Drawing.Point(240, 130);
            this.lblRandevuSaati.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRandevuSaati.Name = "lblRandevuSaati";
            this.lblRandevuSaati.Size = new System.Drawing.Size(112, 16);
            this.lblRandevuSaati.TabIndex = 150;
            this.lblRandevuSaati.Text = "RANDEVU SAATİ";
            // 
            // lblRandevuTarihi
            // 
            this.lblRandevuTarihi.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblRandevuTarihi.AutoSize = true;
            this.lblRandevuTarihi.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblRandevuTarihi.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblRandevuTarihi.Location = new System.Drawing.Point(240, 105);
            this.lblRandevuTarihi.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRandevuTarihi.Name = "lblRandevuTarihi";
            this.lblRandevuTarihi.Size = new System.Drawing.Size(116, 16);
            this.lblRandevuTarihi.TabIndex = 149;
            this.lblRandevuTarihi.Text = "RANDEVU TARİHİ";
            // 
            // lblPoliklinik
            // 
            this.lblPoliklinik.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblPoliklinik.AutoSize = true;
            this.lblPoliklinik.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblPoliklinik.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblPoliklinik.Location = new System.Drawing.Point(240, 81);
            this.lblPoliklinik.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPoliklinik.Name = "lblPoliklinik";
            this.lblPoliklinik.Size = new System.Drawing.Size(82, 16);
            this.lblPoliklinik.TabIndex = 148;
            this.lblPoliklinik.Text = "POLİKLİNİK";
            // 
            // lblSube
            // 
            this.lblSube.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSube.AutoSize = true;
            this.lblSube.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSube.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblSube.Location = new System.Drawing.Point(240, 56);
            this.lblSube.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSube.Name = "lblSube";
            this.lblSube.Size = new System.Drawing.Size(43, 16);
            this.lblSube.TabIndex = 147;
            this.lblSube.Text = "ŞUBE";
            // 
            // lblOnayKodu2
            // 
            this.lblOnayKodu2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblOnayKodu2.AutoSize = true;
            this.lblOnayKodu2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblOnayKodu2.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblOnayKodu2.Location = new System.Drawing.Point(240, 31);
            this.lblOnayKodu2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblOnayKodu2.Name = "lblOnayKodu2";
            this.lblOnayKodu2.Size = new System.Drawing.Size(84, 16);
            this.lblOnayKodu2.TabIndex = 146;
            this.lblOnayKodu2.Text = "ONAY KODU";
            // 
            // lblRandevuAlmaZamani
            // 
            this.lblRandevuAlmaZamani.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblRandevuAlmaZamani.AutoSize = true;
            this.lblRandevuAlmaZamani.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblRandevuAlmaZamani.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblRandevuAlmaZamani.Location = new System.Drawing.Point(240, 5);
            this.lblRandevuAlmaZamani.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRandevuAlmaZamani.Name = "lblRandevuAlmaZamani";
            this.lblRandevuAlmaZamani.Size = new System.Drawing.Size(164, 16);
            this.lblRandevuAlmaZamani.TabIndex = 145;
            this.lblRandevuAlmaZamani.Text = "RANDEVU ALMA ZAMANI";
            // 
            // lblOnayKoduAciklama
            // 
            this.lblOnayKoduAciklama.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblOnayKoduAciklama.AutoSize = true;
            this.lblOnayKoduAciklama.Font = new System.Drawing.Font("Arial", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblOnayKoduAciklama.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.lblOnayKoduAciklama.Location = new System.Drawing.Point(9, 257);
            this.lblOnayKoduAciklama.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblOnayKoduAciklama.Name = "lblOnayKoduAciklama";
            this.lblOnayKoduAciklama.Size = new System.Drawing.Size(113, 19);
            this.lblOnayKoduAciklama.TabIndex = 147;
            this.lblOnayKoduAciklama.Text = "ONAY KODU:";
            // 
            // lblOnayKodu1
            // 
            this.lblOnayKodu1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblOnayKodu1.AutoSize = true;
            this.lblOnayKodu1.Font = new System.Drawing.Font("Arial", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblOnayKodu1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.lblOnayKodu1.Location = new System.Drawing.Point(117, 257);
            this.lblOnayKodu1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblOnayKodu1.Name = "lblOnayKodu1";
            this.lblOnayKodu1.Size = new System.Drawing.Size(97, 19);
            this.lblOnayKodu1.TabIndex = 148;
            this.lblOnayKodu1.Text = "Onay Kodu";
            // 
            // Form7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1015, 654);
            this.Controls.Add(this.lblOnayKodu1);
            this.Controls.Add(this.lblOnayKoduAciklama);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.lblAciklama4);
            this.Controls.Add(this.lblAciklama3);
            this.Controls.Add(this.lblSaat);
            this.Controls.Add(this.lblAciklama2);
            this.Controls.Add(this.lblBransAdi);
            this.Controls.Add(this.lblAciklama1);
            this.Controls.Add(this.lblTarih);
            this.Controls.Add(this.pictureBoxOnayKodunuSaklayinizBilgi);
            this.Controls.Add(this.picBoxRandevunuzSistemeKaydedildi);
            this.Controls.Add(this.btnRandevularım);
            this.Controls.Add(this.btnCikis);
            this.Controls.Add(this.lblHosgeldinizAciklama);
            this.Controls.Add(this.pnlRandevuOnayi);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form7";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form7_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.picBoxRandevunuzSistemeKaydedildi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOnayKodunuSaklayinizBilgi)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Button btnRandevularım;
        public System.Windows.Forms.Button btnCikis;
        public System.Windows.Forms.Label lblHosgeldinizAciklama;
        public System.Windows.Forms.Panel pnlRandevuOnayi;
        public System.Windows.Forms.PictureBox picBoxRandevunuzSistemeKaydedildi;
        public System.Windows.Forms.PictureBox pictureBoxOnayKodunuSaklayinizBilgi;
        public System.Windows.Forms.Label lblAciklama2;
        public System.Windows.Forms.Label lblBransAdi;
        public System.Windows.Forms.Label lblAciklama1;
        public System.Windows.Forms.Label lblTarih;
        public System.Windows.Forms.Label lblSaat;
        public System.Windows.Forms.Label lblAciklama3;
        public System.Windows.Forms.Label lblAciklama4;
        public System.Windows.Forms.Panel panel2;
        public System.Windows.Forms.Label lblHastaSoyad;
        public System.Windows.Forms.Label lblHastaAd;
        public System.Windows.Forms.Label lblHastaTCKimlikNo;
        public System.Windows.Forms.Label lblRandevuSaati;
        public System.Windows.Forms.Label lblRandevuTarihi;
        public System.Windows.Forms.Label lblPoliklinik;
        public System.Windows.Forms.Label lblSube;
        public System.Windows.Forms.Label lblOnayKodu2;
        public System.Windows.Forms.Label lblRandevuAlmaZamani;
        public System.Windows.Forms.Label lblOnayKoduAciklama;
        public System.Windows.Forms.Label lblOnayKodu1;
    }
}