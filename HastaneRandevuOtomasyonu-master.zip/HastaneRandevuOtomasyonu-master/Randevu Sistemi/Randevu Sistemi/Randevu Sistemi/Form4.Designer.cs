﻿namespace Randevu_Sistemi
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            this.btnRandevularım = new System.Windows.Forms.Button();
            this.btnCikis = new System.Windows.Forms.Button();
            this.lblHosgeldinizAciklama = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.picBoxTarihAciklama = new System.Windows.Forms.PictureBox();
            this.picBoxBransListesi = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.monthCalendar_randevuTarihleri = new System.Windows.Forms.MonthCalendar();
            this.lblTarihveSonrasiniAciklama3 = new System.Windows.Forms.Label();
            this.lblTarihveSonrasiniAciklama1 = new System.Windows.Forms.Label();
            this.lblTarih2 = new System.Windows.Forms.Label();
            this.llblTarihAciklama = new System.Windows.Forms.Label();
            this.lblBransAdiAciklama = new System.Windows.Forms.Label();
            this.lblBransAdi1 = new System.Windows.Forms.Label();
            this.lblTarih1 = new System.Windows.Forms.Label();
            this.picBoxBölüm = new System.Windows.Forms.PictureBox();
            this.lblBolumİsmi = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lblDolu = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblBos = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.lblBransAdi2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblNormalAciklama1 = new System.Windows.Forms.Label();
            this.lblTarihveSonrasiniAciklama2 = new System.Windows.Forms.Label();
            this.picBoxGeri = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxTarihAciklama)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxBransListesi)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxBölüm)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxGeri)).BeginInit();
            this.SuspendLayout();
            // 
            // btnRandevularım
            // 
            this.btnRandevularım.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnRandevularım.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnRandevularım.BackColor = System.Drawing.Color.Orange;
            this.btnRandevularım.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRandevularım.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnRandevularım.ForeColor = System.Drawing.Color.White;
            this.btnRandevularım.Location = new System.Drawing.Point(842, 38);
            this.btnRandevularım.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnRandevularım.Name = "btnRandevularım";
            this.btnRandevularım.Size = new System.Drawing.Size(101, 31);
            this.btnRandevularım.TabIndex = 52;
            this.btnRandevularım.Text = "Randevularım";
            this.btnRandevularım.UseVisualStyleBackColor = false;
            this.btnRandevularım.Click += new System.EventHandler(this.btnRandevularım_Click);
            this.btnRandevularım.MouseLeave += new System.EventHandler(this.btnRandevularım_MouseLeave);
            this.btnRandevularım.MouseMove += new System.Windows.Forms.MouseEventHandler(this.btnRandevularım_MouseMove);
            // 
            // btnCikis
            // 
            this.btnCikis.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnCikis.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnCikis.BackColor = System.Drawing.Color.Orange;
            this.btnCikis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCikis.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnCikis.ForeColor = System.Drawing.Color.White;
            this.btnCikis.Location = new System.Drawing.Point(947, 38);
            this.btnCikis.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnCikis.Name = "btnCikis";
            this.btnCikis.Size = new System.Drawing.Size(66, 31);
            this.btnCikis.TabIndex = 51;
            this.btnCikis.Text = "Çıkış";
            this.btnCikis.UseVisualStyleBackColor = false;
            this.btnCikis.Click += new System.EventHandler(this.btnCikis_Click);
            this.btnCikis.MouseLeave += new System.EventHandler(this.btnCikis_MouseLeave);
            this.btnCikis.MouseMove += new System.Windows.Forms.MouseEventHandler(this.btnCikis_MouseMove);
            // 
            // lblHosgeldinizAciklama
            // 
            this.lblHosgeldinizAciklama.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblHosgeldinizAciklama.AutoSize = true;
            this.lblHosgeldinizAciklama.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblHosgeldinizAciklama.ForeColor = System.Drawing.Color.Black;
            this.lblHosgeldinizAciklama.Location = new System.Drawing.Point(632, 12);
            this.lblHosgeldinizAciklama.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblHosgeldinizAciklama.Name = "lblHosgeldinizAciklama";
            this.lblHosgeldinizAciklama.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblHosgeldinizAciklama.Size = new System.Drawing.Size(135, 15);
            this.lblHosgeldinizAciklama.TabIndex = 50;
            this.lblHosgeldinizAciklama.Text = "lblHosgeldinizAciklama";
            this.lblHosgeldinizAciklama.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(2, 80);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1011, 105);
            this.panel1.TabIndex = 49;
            // 
            // picBoxTarihAciklama
            // 
            this.picBoxTarihAciklama.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxTarihAciklama.BackgroundImage")));
            this.picBoxTarihAciklama.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picBoxTarihAciklama.Location = new System.Drawing.Point(313, 281);
            this.picBoxTarihAciklama.Name = "picBoxTarihAciklama";
            this.picBoxTarihAciklama.Size = new System.Drawing.Size(690, 57);
            this.picBoxTarihAciklama.TabIndex = 55;
            this.picBoxTarihAciklama.TabStop = false;
            // 
            // picBoxBransListesi
            // 
            this.picBoxBransListesi.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picBoxBransListesi.Image = ((System.Drawing.Image)(resources.GetObject("picBoxBransListesi.Image")));
            this.picBoxBransListesi.Location = new System.Drawing.Point(313, 203);
            this.picBoxBransListesi.Name = "picBoxBransListesi";
            this.picBoxBransListesi.Size = new System.Drawing.Size(690, 35);
            this.picBoxBransListesi.TabIndex = 54;
            this.picBoxBransListesi.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.monthCalendar_randevuTarihleri);
            this.panel2.Location = new System.Drawing.Point(2, 203);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(290, 234);
            this.panel2.TabIndex = 53;
            // 
            // monthCalendar_randevuTarihleri
            // 
            this.monthCalendar_randevuTarihleri.BackColor = System.Drawing.Color.Gold;
            this.monthCalendar_randevuTarihleri.Enabled = false;
            this.monthCalendar_randevuTarihleri.FirstDayOfWeek = System.Windows.Forms.Day.Monday;
            this.monthCalendar_randevuTarihleri.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.monthCalendar_randevuTarihleri.ForeColor = System.Drawing.Color.White;
            this.monthCalendar_randevuTarihleri.Location = new System.Drawing.Point(9, 9);
            this.monthCalendar_randevuTarihleri.MaxSelectionCount = 1;
            this.monthCalendar_randevuTarihleri.Name = "monthCalendar_randevuTarihleri";
            this.monthCalendar_randevuTarihleri.TabIndex = 21;
            this.monthCalendar_randevuTarihleri.TitleBackColor = System.Drawing.Color.Red;
            this.monthCalendar_randevuTarihleri.TitleForeColor = System.Drawing.Color.White;
            this.monthCalendar_randevuTarihleri.TrailingForeColor = System.Drawing.SystemColors.WindowFrame;
            // 
            // lblTarihveSonrasiniAciklama3
            // 
            this.lblTarihveSonrasiniAciklama3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTarihveSonrasiniAciklama3.AutoSize = true;
            this.lblTarihveSonrasiniAciklama3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTarihveSonrasiniAciklama3.ForeColor = System.Drawing.Color.Black;
            this.lblTarihveSonrasiniAciklama3.Location = new System.Drawing.Point(314, 371);
            this.lblTarihveSonrasiniAciklama3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTarihveSonrasiniAciklama3.Name = "lblTarihveSonrasiniAciklama3";
            this.lblTarihveSonrasiniAciklama3.Size = new System.Drawing.Size(340, 15);
            this.lblTarihveSonrasiniAciklama3.TabIndex = 58;
            this.lblTarihveSonrasiniAciklama3.Text = "randevu saatlerini görmek istediğiniz kaydın üzerine tıklayınız.";
            // 
            // lblTarihveSonrasiniAciklama1
            // 
            this.lblTarihveSonrasiniAciklama1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTarihveSonrasiniAciklama1.AutoSize = true;
            this.lblTarihveSonrasiniAciklama1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTarihveSonrasiniAciklama1.ForeColor = System.Drawing.Color.Black;
            this.lblTarihveSonrasiniAciklama1.Location = new System.Drawing.Point(464, 356);
            this.lblTarihveSonrasiniAciklama1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTarihveSonrasiniAciklama1.Name = "lblTarihveSonrasiniAciklama1";
            this.lblTarihveSonrasiniAciklama1.Size = new System.Drawing.Size(55, 15);
            this.lblTarihveSonrasiniAciklama1.TabIndex = 57;
            this.lblTarihveSonrasiniAciklama1.Text = "tarihinde";
            // 
            // lblTarih2
            // 
            this.lblTarih2.AutoSize = true;
            this.lblTarih2.BackColor = System.Drawing.Color.White;
            this.lblTarih2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTarih2.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblTarih2.Location = new System.Drawing.Point(314, 356);
            this.lblTarih2.Name = "lblTarih2";
            this.lblTarih2.Size = new System.Drawing.Size(116, 15);
            this.lblTarih2.TabIndex = 56;
            this.lblTarih2.Text = "ToLongDateString()";
            // 
            // llblTarihAciklama
            // 
            this.llblTarihAciklama.AutoSize = true;
            this.llblTarihAciklama.BackColor = System.Drawing.SystemColors.Control;
            this.llblTarihAciklama.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.llblTarihAciklama.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.llblTarihAciklama.Image = ((System.Drawing.Image)(resources.GetObject("llblTarihAciklama.Image")));
            this.llblTarihAciklama.Location = new System.Drawing.Point(319, 289);
            this.llblTarihAciklama.Name = "llblTarihAciklama";
            this.llblTarihAciklama.Size = new System.Drawing.Size(95, 15);
            this.llblTarihAciklama.TabIndex = 59;
            this.llblTarihAciklama.Text = "Tarih                   :";
            // 
            // lblBransAdiAciklama
            // 
            this.lblBransAdiAciklama.AutoSize = true;
            this.lblBransAdiAciklama.BackColor = System.Drawing.SystemColors.Control;
            this.lblBransAdiAciklama.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBransAdiAciklama.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblBransAdiAciklama.Image = ((System.Drawing.Image)(resources.GetObject("lblBransAdiAciklama.Image")));
            this.lblBransAdiAciklama.Location = new System.Drawing.Point(319, 312);
            this.lblBransAdiAciklama.Name = "lblBransAdiAciklama";
            this.lblBransAdiAciklama.Size = new System.Drawing.Size(95, 15);
            this.lblBransAdiAciklama.TabIndex = 60;
            this.lblBransAdiAciklama.Text = "Branş Adı          :";
            // 
            // lblBransAdi1
            // 
            this.lblBransAdi1.AutoSize = true;
            this.lblBransAdi1.BackColor = System.Drawing.SystemColors.Control;
            this.lblBransAdi1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBransAdi1.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblBransAdi1.Image = ((System.Drawing.Image)(resources.GetObject("lblBransAdi1.Image")));
            this.lblBransAdi1.Location = new System.Drawing.Point(411, 312);
            this.lblBransAdi1.Name = "lblBransAdi1";
            this.lblBransAdi1.Size = new System.Drawing.Size(59, 15);
            this.lblBransAdi1.TabIndex = 62;
            this.lblBransAdi1.Text = "Branş Adı";
            // 
            // lblTarih1
            // 
            this.lblTarih1.AutoSize = true;
            this.lblTarih1.BackColor = System.Drawing.SystemColors.Control;
            this.lblTarih1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTarih1.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblTarih1.Image = ((System.Drawing.Image)(resources.GetObject("lblTarih1.Image")));
            this.lblTarih1.Location = new System.Drawing.Point(411, 289);
            this.lblTarih1.Name = "lblTarih1";
            this.lblTarih1.Size = new System.Drawing.Size(114, 15);
            this.lblTarih1.TabIndex = 63;
            this.lblTarih1.Text = "ToLongDateString()";
            // 
            // picBoxBölüm
            // 
            this.picBoxBölüm.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxBölüm.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxBölüm.BackgroundImage")));
            this.picBoxBölüm.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxBölüm.Location = new System.Drawing.Point(313, 401);
            this.picBoxBölüm.Name = "picBoxBölüm";
            this.picBoxBölüm.Size = new System.Drawing.Size(166, 70);
            this.picBoxBölüm.TabIndex = 70;
            this.picBoxBölüm.TabStop = false;
            this.picBoxBölüm.Click += new System.EventHandler(this.picBoxBölüm_Click);
            // 
            // lblBolumİsmi
            // 
            this.lblBolumİsmi.AutoSize = true;
            this.lblBolumİsmi.BackColor = System.Drawing.Color.White;
            this.lblBolumİsmi.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBolumİsmi.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblBolumİsmi.Image = ((System.Drawing.Image)(resources.GetObject("lblBolumİsmi.Image")));
            this.lblBolumİsmi.Location = new System.Drawing.Point(332, 410);
            this.lblBolumİsmi.Name = "lblBolumİsmi";
            this.lblBolumİsmi.Size = new System.Drawing.Size(79, 16);
            this.lblBolumİsmi.TabIndex = 94;
            this.lblBolumİsmi.Text = "Bölüm İsmi";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.MistyRose;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.lblDolu);
            this.panel4.Controls.Add(this.label24);
            this.panel4.Location = new System.Drawing.Point(393, 449);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(52, 19);
            this.panel4.TabIndex = 115;
            // 
            // lblDolu
            // 
            this.lblDolu.AutoSize = true;
            this.lblDolu.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblDolu.ForeColor = System.Drawing.Color.Red;
            this.lblDolu.Location = new System.Drawing.Point(31, 0);
            this.lblDolu.Name = "lblDolu";
            this.lblDolu.Size = new System.Drawing.Size(14, 15);
            this.lblDolu.TabIndex = 114;
            this.lblDolu.Text = "0";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label24.ForeColor = System.Drawing.Color.Red;
            this.label24.Location = new System.Drawing.Point(1, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(35, 15);
            this.label24.TabIndex = 113;
            this.label24.Text = "Dolu:";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.lblBos);
            this.panel3.Controls.Add(this.label21);
            this.panel3.Location = new System.Drawing.Point(341, 449);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(50, 19);
            this.panel3.TabIndex = 114;
            // 
            // lblBos
            // 
            this.lblBos.AutoSize = true;
            this.lblBos.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBos.ForeColor = System.Drawing.Color.Green;
            this.lblBos.Location = new System.Drawing.Point(29, 0);
            this.lblBos.Name = "lblBos";
            this.lblBos.Size = new System.Drawing.Size(14, 15);
            this.lblBos.TabIndex = 114;
            this.lblBos.Text = "0";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label21.ForeColor = System.Drawing.Color.Green;
            this.label21.Location = new System.Drawing.Point(3, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(32, 15);
            this.label21.TabIndex = 113;
            this.label21.Text = "Boş:";
            // 
            // lblBransAdi2
            // 
            this.lblBransAdi2.AutoSize = true;
            this.lblBransAdi2.BackColor = System.Drawing.Color.White;
            this.lblBransAdi2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBransAdi2.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblBransAdi2.Location = new System.Drawing.Point(515, 356);
            this.lblBransAdi2.Name = "lblBransAdi2";
            this.lblBransAdi2.Size = new System.Drawing.Size(62, 15);
            this.lblBransAdi2.TabIndex = 116;
            this.lblBransAdi2.Text = "Branş Adı";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(660, 356);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 15);
            this.label1.TabIndex = 117;
            this.label1.Text = "branşında";
            // 
            // lblNormalAciklama1
            // 
            this.lblNormalAciklama1.AutoSize = true;
            this.lblNormalAciklama1.BackColor = System.Drawing.Color.White;
            this.lblNormalAciklama1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblNormalAciklama1.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblNormalAciklama1.Location = new System.Drawing.Point(720, 356);
            this.lblNormalAciklama1.Name = "lblNormalAciklama1";
            this.lblNormalAciklama1.Size = new System.Drawing.Size(58, 15);
            this.lblNormalAciklama1.TabIndex = 118;
            this.lblNormalAciklama1.Text = "Poliklinik";
            // 
            // lblTarihveSonrasiniAciklama2
            // 
            this.lblTarihveSonrasiniAciklama2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTarihveSonrasiniAciklama2.AutoSize = true;
            this.lblTarihveSonrasiniAciklama2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTarihveSonrasiniAciklama2.ForeColor = System.Drawing.Color.Black;
            this.lblTarihveSonrasiniAciklama2.Location = new System.Drawing.Point(776, 356);
            this.lblTarihveSonrasiniAciklama2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTarihveSonrasiniAciklama2.Name = "lblTarihveSonrasiniAciklama2";
            this.lblTarihveSonrasiniAciklama2.Size = new System.Drawing.Size(229, 15);
            this.lblTarihveSonrasiniAciklama2.TabIndex = 119;
            this.lblTarihveSonrasiniAciklama2.Text = "randevuları aşağıda listelenmiştir. Lütfen";
            // 
            // picBoxGeri
            // 
            this.picBoxGeri.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoxGeri.BackgroundImage")));
            this.picBoxGeri.Location = new System.Drawing.Point(313, 244);
            this.picBoxGeri.Name = "picBoxGeri";
            this.picBoxGeri.Size = new System.Drawing.Size(87, 33);
            this.picBoxGeri.TabIndex = 120;
            this.picBoxGeri.TabStop = false;
            this.picBoxGeri.Click += new System.EventHandler(this.picBoxGeri_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1015, 670);
            this.Controls.Add(this.picBoxGeri);
            this.Controls.Add(this.lblTarihveSonrasiniAciklama2);
            this.Controls.Add(this.lblNormalAciklama1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblBransAdi2);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.lblBolumİsmi);
            this.Controls.Add(this.picBoxBölüm);
            this.Controls.Add(this.lblTarih1);
            this.Controls.Add(this.lblBransAdi1);
            this.Controls.Add(this.lblBransAdiAciklama);
            this.Controls.Add(this.llblTarihAciklama);
            this.Controls.Add(this.lblTarihveSonrasiniAciklama3);
            this.Controls.Add(this.lblTarihveSonrasiniAciklama1);
            this.Controls.Add(this.lblTarih2);
            this.Controls.Add(this.picBoxTarihAciklama);
            this.Controls.Add(this.picBoxBransListesi);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btnRandevularım);
            this.Controls.Add(this.btnCikis);
            this.Controls.Add(this.lblHosgeldinizAciklama);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form4";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form4_FormClosed);
            this.Load += new System.EventHandler(this.Form4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picBoxTarihAciklama)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxBransListesi)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picBoxBölüm)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxGeri)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Button btnRandevularım;
        public System.Windows.Forms.Button btnCikis;
        public System.Windows.Forms.Label lblHosgeldinizAciklama;
        public System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.PictureBox picBoxTarihAciklama;
        public System.Windows.Forms.PictureBox picBoxBransListesi;
        public System.Windows.Forms.Panel panel2;
        public System.Windows.Forms.MonthCalendar monthCalendar_randevuTarihleri;
        public System.Windows.Forms.Label lblTarihveSonrasiniAciklama3;
        public System.Windows.Forms.Label lblTarihveSonrasiniAciklama1;
        public System.Windows.Forms.Label lblTarih2;
        public System.Windows.Forms.Label llblTarihAciklama;
        public System.Windows.Forms.Label lblBransAdiAciklama;
        public System.Windows.Forms.Label lblBransAdi1;
        public System.Windows.Forms.Label lblTarih1;
        public System.Windows.Forms.PictureBox picBoxBölüm;
        public System.Windows.Forms.Label lblBolumİsmi;
        public System.Windows.Forms.Panel panel4;
        public System.Windows.Forms.Label lblDolu;
        public System.Windows.Forms.Label label24;
        public System.Windows.Forms.Panel panel3;
        public System.Windows.Forms.Label lblBos;
        public System.Windows.Forms.Label label21;
        public System.Windows.Forms.Label lblBransAdi2;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label lblNormalAciklama1;
        public System.Windows.Forms.Label lblTarihveSonrasiniAciklama2;
        private System.Windows.Forms.PictureBox picBoxGeri;
    }
}